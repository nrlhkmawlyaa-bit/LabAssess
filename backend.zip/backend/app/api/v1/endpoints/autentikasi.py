
from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    status,
)
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.api.dependencies import (
    get_pengguna_wajib_ganti_password,
)

from app.models.pengguna import User

from app.schemas.autentikasi import (
    LoginRequest,
    LoginSuccessResponse,
)

from app.schemas.ganti_password import (
    GantiPasswordRequest,
    GantiPasswordResponse,
)

from app.services.autentikasi_service import (
    AutentikasiService,
)

from app.services.ganti_password_service import (
    GantiPasswordService,
)


router = APIRouter(
    prefix="/auth",
    tags=["Autentikasi"],
)


@router.post(
    "/login",
    response_model=LoginSuccessResponse,
)
def login(
    data: LoginRequest,
    db: Session = Depends(get_db),
):
    """
    Endpoint login untuk Admin, Asisten Lab,
    dan Mahasiswa.
    """

    layanan = AutentikasiService(db)

    try:
        hasil = layanan.login(
            identitas=data.identitas,
            password=data.password.get_secret_value(),
            role=data.role,
        )

        return hasil

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(error),
        ) from error


@router.post(
    "/ganti-password",
    response_model=GantiPasswordResponse,
)
def ganti_password(
    data: GantiPasswordRequest,
    pengguna: User = Depends(
        get_pengguna_wajib_ganti_password
    ),
    db: Session = Depends(get_db),
):
    """
    Mengganti password sementara menjadi password permanen.

    Endpoint ini hanya bisa digunakan oleh mahasiswa
    yang sudah login menggunakan password sementara.
    """

    layanan = GantiPasswordService(db)

    try:
        return layanan.ganti_password(
            pengguna=pengguna,
            password_baru=data.password_baru.get_secret_value(),
        )

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        ) from error

    except Exception:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Terjadi kesalahan saat mengganti password.",
        )
