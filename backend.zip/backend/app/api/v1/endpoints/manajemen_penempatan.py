
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.dependencies import izinkan_role
from app.database.session import get_db

from app.schemas.penempatan import (
    PenempatanRequest,
    PenggunaPenempatanResponse,
    KelasPenempatanResponse,
)

from app.services.penempatan_service import PenempatanService


# ==========================================
# ROUTER
# ==========================================

router = APIRouter(
    prefix="/admin/penempatan",
    tags=["Manajemen Penempatan"],
)


# ==========================================
# GET: DAFTAR SEMUA PENEMPATAN
# ==========================================

@router.get(
    "/",
    response_model=list[KelasPenempatanResponse],
)
def daftar_penempatan(
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = PenempatanService(db)
    return service.ambil_semua_penempatan()


# ==========================================
# GET: DETAIL PENEMPATAN KELAS
# ==========================================

@router.get(
    "/kelas/{kelas_id}",
    response_model=KelasPenempatanResponse,
)
def detail_penempatan(
    kelas_id: int,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = PenempatanService(db)

    try:
        return service.ambil_detail_penempatan(kelas_id)
    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(error),
        )


# ==========================================
# GET: DAFTAR ASISTEN AKTIF
# ==========================================

@router.get(
    "/asisten",
    response_model=list[PenggunaPenempatanResponse],
)
def daftar_asisten(
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = PenempatanService(db)
    return service.ambil_semua_asisten()


# ==========================================
# GET: DAFTAR MAHASISWA AKTIF
# ==========================================

@router.get(
    "/mahasiswa",
    response_model=list[PenggunaPenempatanResponse],
)
def daftar_mahasiswa(
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = PenempatanService(db)
    return service.ambil_semua_mahasiswa()


# ==========================================
# POST: TEMPATKAN ASISTEN
# ==========================================

@router.post(
    "/kelas/{kelas_id}/asisten",
    response_model=KelasPenempatanResponse,
    status_code=status.HTTP_200_OK,
)
def tempatkan_asisten(
    kelas_id: int,
    data: PenempatanRequest,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = PenempatanService(db)

    try:
        return service.tempatkan_asisten(
            kelas_id,
            data.pengguna_id,
        )
    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        )


# ==========================================
# DELETE: HAPUS PENEMPATAN ASISTEN
# ==========================================

@router.delete(
    "/kelas/{kelas_id}/asisten/{asisten_id}",
)
def hapus_penempatan_asisten(
    kelas_id: int,
    asisten_id: int,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = PenempatanService(db)

    try:
        service.hapus_penempatan_asisten(
            kelas_id,
            asisten_id,
        )

        return {
            "berhasil": True,
            "pesan": "Penempatan asisten berhasil dihapus.",
        }

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        )


# ==========================================
# POST: TEMPATKAN MAHASISWA
# ==========================================

@router.post(
    "/kelas/{kelas_id}/mahasiswa",
    response_model=KelasPenempatanResponse,
    status_code=status.HTTP_200_OK,
)
def tempatkan_mahasiswa(
    kelas_id: int,
    data: PenempatanRequest,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = PenempatanService(db)

    try:
        return service.tempatkan_mahasiswa(
            kelas_id,
            data.pengguna_id,
        )
    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        )


# ==========================================
# DELETE: HAPUS PENEMPATAN MAHASISWA
# ==========================================

@router.delete(
    "/kelas/{kelas_id}/mahasiswa/{mahasiswa_id}",
)
def hapus_penempatan_mahasiswa(
    kelas_id: int,
    mahasiswa_id: int,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = PenempatanService(db)

    try:
        service.hapus_penempatan_mahasiswa(
            kelas_id,
            mahasiswa_id,
        )

        return {
            "berhasil": True,
            "pesan": "Penempatan mahasiswa berhasil dihapus.",
        }

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        )
