
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.dependencies import izinkan_role
from app.database.session import get_db
from app.models.pengguna import User

from app.schemas.dashboard_mahasiswa import (
    DashboardMahasiswaResponse,
)

from app.services.mahasiswa_service import MahasiswaService


router = APIRouter(
    prefix="/mahasiswa",
    tags=["Dashboard Mahasiswa"],
)


@router.get(
    "/dashboard",
    response_model=DashboardMahasiswaResponse,
)
def ambil_dashboard_mahasiswa(
    db: Session = Depends(get_db),
    pengguna: User = Depends(
        izinkan_role("mahasiswa")
    ),
):
    service = MahasiswaService(db)

    return service.ambil_dashboard(pengguna)
