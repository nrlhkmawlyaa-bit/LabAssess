
import os

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.api.dependencies import izinkan_role
from app.database.session import get_db
from app.models.pengguna import User
from app.schemas.dashboard_mahasiswa import ModulMahasiswaResponse
from app.services.modul_mahasiswa_service import ModulMahasiswaService

from app.schemas.kuis import NilaiPraktikumResponse
from app.services.kuis_service import KuisService

router = APIRouter(
    prefix="/mahasiswa",
    tags=["Modul Praktikum Mahasiswa"],
)


# ==========================================
# DAFTAR MODUL PRAKTIKUM
# ==========================================

@router.get(
    "/kelas/{kelas_id}/modul",
    response_model=list[ModulMahasiswaResponse],
)
def ambil_daftar_modul_mahasiswa(
    kelas_id: int,
    db: Session = Depends(get_db),
    mahasiswa: User = Depends(izinkan_role("mahasiswa")),
):
    service = ModulMahasiswaService(db)

    return service.ambil_semua_modul(
        kelas_id=kelas_id,
        mahasiswa=mahasiswa,
    )


# ==========================================
# DETAIL MODUL PRAKTIKUM
# ==========================================

@router.get(
    "/modul/{modul_id}",
    response_model=ModulMahasiswaResponse,
)
def ambil_detail_modul_mahasiswa(
    modul_id: int,
    db: Session = Depends(get_db),
    mahasiswa: User = Depends(izinkan_role("mahasiswa")),
):
    service = ModulMahasiswaService(db)

    return service.ambil_detail_modul(
        modul_id=modul_id,
        mahasiswa=mahasiswa,
    )


# ==========================================
# UNDUH FILE MODUL PRAKTIKUM
# ==========================================

@router.get(
    "/modul/{modul_id}/files/{file_id}/download",
)
def unduh_file_modul_mahasiswa(
    modul_id: int,
    file_id: int,
    db: Session = Depends(get_db),
    mahasiswa: User = Depends(izinkan_role("mahasiswa")),
):
    service = ModulMahasiswaService(db)

    file_modul = service.ambil_file_modul(
        modul_id=modul_id,
        file_id=file_id,
        mahasiswa=mahasiswa,
    )

    lokasi_file = file_modul.storage_path

    if not os.path.isfile(lokasi_file):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="File tidak ditemukan pada penyimpanan server.",
        )

    return FileResponse(
        path=lokasi_file,
        media_type=(
            file_modul.content_type
            or "application/octet-stream"
        ),
        filename=file_modul.original_filename,
    )


# ==========================================
# RINGKASAN NILAI PRAKTIKUM MAHASISWA
# ==========================================

@router.get(
    "/kelas/{kelas_id}/nilai-praktikum",
    response_model=NilaiPraktikumResponse,
)
def ambil_ringkasan_nilai_praktikum_mahasiswa(
    kelas_id: int,
    db: Session = Depends(get_db),
    mahasiswa: User = Depends(izinkan_role("mahasiswa")),
):
    service = KuisService(db)

    return service.ambil_ringkasan_nilai_praktikum(
        kelas_id=kelas_id,
        mahasiswa=mahasiswa,
    )
