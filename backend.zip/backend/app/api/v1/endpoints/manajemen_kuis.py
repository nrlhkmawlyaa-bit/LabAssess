from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    status,
)
from sqlalchemy.orm import Session

from app.api.dependencies import izinkan_role
from app.database.session import get_db
from app.models.pengguna import User

from app.schemas.kuis import (
    KuisCreate,
    KuisUpdate,
    KuisStatusUpdate,
    KuisResponse,
    SoalKuisCreate,
    SoalKuisUpdate,
    OpsiKuisCreate,
    PenilaianEsaiRequest,
)

from app.services.kuis_service import KuisService


# =====================================================
# ROUTER MANAJEMEN KUIS ASISTEN
# =====================================================

router = APIRouter(
    prefix="/asisten/kuis",
    tags=["Manajemen Kuis Asisten"],
)


# =====================================================
# DAFTAR KUIS DALAM KELAS
# =====================================================

@router.get(
    "/kelas/{kelas_id}",
    response_model=list[KuisResponse],
)
def ambil_daftar_kuis_asisten(
    kelas_id: int,
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = KuisService(db)

    return service.ambil_semua_kuis(
        kelas_id=kelas_id,
        pengguna=asisten,
    )


# =====================================================
# MEMBUAT KUIS PRE-TEST / POST-TEST
# =====================================================

@router.post(
    "/kelas/{kelas_id}",
    response_model=KuisResponse,
    status_code=status.HTTP_201_CREATED,
)
def buat_kuis_asisten(
    kelas_id: int,
    data: KuisCreate,
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    if data.class_id != kelas_id:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=(
                "ID kelas pada URL tidak sesuai "
                "dengan data kuis."
            ),
        )

    service = KuisService(db)

    return service.buat_kuis(
        data=data,
        pengguna=asisten,
    )


# =====================================================
# DETAIL KUIS
# =====================================================

@router.get(
    "/{kuis_id}",
    response_model=KuisResponse,
)
def ambil_detail_kuis_asisten(
    kuis_id: int,
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = KuisService(db)

    return service.ambil_detail_kuis(
        kuis_id=kuis_id,
        pengguna=asisten,
    )


# =====================================================
# MEMPERBARUI KONFIGURASI KUIS
# =====================================================

@router.patch(
    "/{kuis_id}",
    response_model=KuisResponse,
)
def perbarui_kuis_asisten(
    kuis_id: int,
    data: KuisUpdate,
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = KuisService(db)

    return service.perbarui_kuis(
        kuis_id=kuis_id,
        data=data,
        pengguna=asisten,
    )


# =====================================================
# MENGUBAH STATUS KUIS
# =====================================================

@router.patch(
    "/{kuis_id}/status",
    response_model=KuisResponse,
)
def ubah_status_kuis_asisten(
    kuis_id: int,
    data: KuisStatusUpdate,
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = KuisService(db)

    return service.ubah_status_kuis(
        kuis_id=kuis_id,
        status_baru=data.status,
        pengguna=asisten,
    )


# =====================================================
# MENGHAPUS KUIS
# =====================================================

@router.delete("/{kuis_id}")
def hapus_kuis_asisten(
    kuis_id: int,
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = KuisService(db)

    return service.hapus_kuis(
        kuis_id=kuis_id,
        pengguna=asisten,
    )


# =====================================================
# DAFTAR SOAL DALAM KUIS
# =====================================================

@router.get("/{kuis_id}/soal")
def ambil_daftar_soal_asisten(
    kuis_id: int,
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = KuisService(db)

    return service.ambil_semua_soal(
        kuis_id=kuis_id,
        pengguna=asisten,
    )


# =====================================================
# MENAMBAHKAN SOAL
# =====================================================

@router.post(
    "/{kuis_id}/soal",
    status_code=status.HTTP_201_CREATED,
)
def tambah_soal_asisten(
    kuis_id: int,
    data: SoalKuisCreate,
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = KuisService(db)

    return service.tambah_soal(
        kuis_id=kuis_id,
        data=data,
        pengguna=asisten,
    )


# =====================================================
# MEMPERBARUI SOAL
# =====================================================

@router.patch("/{kuis_id}/soal/{soal_id}")
def perbarui_soal_asisten(
    kuis_id: int,
    soal_id: int,
    data: SoalKuisUpdate,
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = KuisService(db)

    return service.perbarui_soal(
        kuis_id=kuis_id,
        soal_id=soal_id,
        data=data,
        pengguna=asisten,
    )


# =====================================================
# MEMPERBARUI OPSI JAWABAN
# =====================================================

@router.put("/{kuis_id}/soal/{soal_id}/opsi")
def perbarui_opsi_soal_asisten(
    kuis_id: int,
    soal_id: int,
    options: list[OpsiKuisCreate],
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = KuisService(db)

    return service.perbarui_opsi_soal(
        kuis_id=kuis_id,
        soal_id=soal_id,
        options=options,
        pengguna=asisten,
    )


# =====================================================
# MENGHAPUS SOAL
# =====================================================

@router.delete("/{kuis_id}/soal/{soal_id}")
def hapus_soal_asisten(
    kuis_id: int,
    soal_id: int,
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = KuisService(db)

    return service.hapus_soal(
        kuis_id=kuis_id,
        soal_id=soal_id,
        pengguna=asisten,
    )


# =====================================================
# DAFTAR PENGERJAAN / NILAI MAHASISWA PADA KUIS
# =====================================================

@router.get("/{kuis_id}/pengerjaan")
def ambil_daftar_pengerjaan_asisten(
    kuis_id: int,
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = KuisService(db)

    return service.ambil_daftar_pengerjaan_asisten(
        kuis_id=kuis_id,
        asisten=asisten,
    )


# =====================================================
# DETAIL PENGERJAAN MAHASISWA
# =====================================================

@router.get("/{kuis_id}/pengerjaan/{pengerjaan_id}")
def ambil_detail_pengerjaan_asisten(
    kuis_id: int,
    pengerjaan_id: int,
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = KuisService(db)

    return service.ambil_detail_pengerjaan_asisten(
        kuis_id=kuis_id,
        pengerjaan_id=pengerjaan_id,
        asisten=asisten,
    )


# =====================================================
# RESET RIWAYAT PENGERJAAN SATU MAHASISWA
# =====================================================

@router.delete(
    "/{kuis_id}/pengerjaan/mahasiswa/{mahasiswa_id}"
)
def reset_pengerjaan_mahasiswa_asisten(
    kuis_id: int,
    mahasiswa_id: int,
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = KuisService(db)

    return service.reset_pengerjaan_mahasiswa(
        kuis_id=kuis_id,
        mahasiswa_id=mahasiswa_id,
        asisten=asisten,
    )


# =====================================================
# MEMBERIKAN PENILAIAN JAWABAN ESAI
# =====================================================

@router.patch(
    "/{kuis_id}/pengerjaan/{pengerjaan_id}/soal/{soal_id}/nilai"
)
def nilai_jawaban_esai_asisten(
    kuis_id: int,
    pengerjaan_id: int,
    soal_id: int,
    data: PenilaianEsaiRequest,
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = KuisService(db)

    return service.nilai_esai(
        kuis_id=kuis_id,
        pengerjaan_id=pengerjaan_id,
        jawaban_id=soal_id,
        data=data,
        asisten=asisten,
    )


# =====================================================
# PUBLIKASI NILAI KUIS
# =====================================================

@router.patch(
    "/{kuis_id}/pengerjaan/{pengerjaan_id}/publikasikan-nilai"
)
def publikasikan_nilai_kuis_asisten(
    kuis_id: int,
    pengerjaan_id: int,
    db: Session = Depends(get_db),
    asisten: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = KuisService(db)

    return service.publikasikan_nilai(
        kuis_id=kuis_id,
        pengerjaan_id=pengerjaan_id,
        asisten=asisten,
    )
