
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.dependencies import izinkan_role
from app.database.session import get_db

from app.schemas.periode_akademik import (
    PeriodeAkademikCreateRequest,
    PeriodeAkademikUpdateRequest,
    PeriodeAkademikResponse,
)

from app.services.periode_akademik_service import (
    PeriodeAkademikService,
)


# ==========================================
# ROUTER
# ==========================================

router = APIRouter(
    prefix="/admin/periode-akademik",
    tags=["Manajemen Periode Akademik"],
)


# ==========================================
# GET: DAFTAR PERIODE AKADEMIK
# ==========================================

@router.get(
    "/",
    response_model=list[PeriodeAkademikResponse],
)
def daftar_periode_akademik(
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = PeriodeAkademikService(db)

    return service.ambil_semua()


# ==========================================
# GET: DETAIL PERIODE AKADEMIK
# ==========================================

@router.get(
    "/{periode_id}",
    response_model=PeriodeAkademikResponse,
)
def detail_periode_akademik(
    periode_id: int,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = PeriodeAkademikService(db)

    try:
        return service.ambil_berdasarkan_id(periode_id)

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(error),
        )


# ==========================================
# POST: TAMBAH PERIODE AKADEMIK
# ==========================================

@router.post(
    "/",
    response_model=PeriodeAkademikResponse,
    status_code=status.HTTP_201_CREATED,
)
def tambah_periode_akademik(
    data: PeriodeAkademikCreateRequest,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = PeriodeAkademikService(db)

    try:
        return service.tambah(data.model_dump())

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        )


# ==========================================
# PATCH: UBAH PERIODE AKADEMIK
# ==========================================

@router.patch(
    "/{periode_id}",
    response_model=PeriodeAkademikResponse,
)
def ubah_periode_akademik(
    periode_id: int,
    data: PeriodeAkademikUpdateRequest,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = PeriodeAkademikService(db)

    try:
        return service.ubah(
            periode_id,
            data.model_dump(exclude_unset=True),
        )

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        )


# ==========================================
# DELETE: HAPUS PERIODE AKADEMIK
# ==========================================

@router.delete(
    "/{periode_id}",
)
def hapus_periode_akademik(
    periode_id: int,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = PeriodeAkademikService(db)

    try:
        return service.hapus(periode_id)

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        )
