
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.api.dependencies import izinkan_role
from app.database.session import get_db

from app.models.pengguna import User

from app.schemas.modul_praktikum import (
    ModulPraktikumCreate,
    ModulPraktikumUpdate,
    ModulPraktikumResponse,
)

from app.services.modul_praktikum_service import (
    ModulPraktikumService,
)


router = APIRouter(
    prefix="/asisten/modul-praktikum",
    tags=["Manajemen Modul Praktikum"],
)


# =========================================================
# 1. AMBIL SEMUA MODUL DALAM KELAS
# =========================================================

@router.get(
    "/kelas/{kelas_id}",
    response_model=list[ModulPraktikumResponse],
)
def ambil_semua_modul(
    kelas_id: int,
    db: Session = Depends(get_db),
    pengguna: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = ModulPraktikumService(db)

    return service.ambil_semua_modul(
        kelas_id=kelas_id,
        pengguna=pengguna,
    )


# =========================================================
# 2. BUAT MODUL PRAKTIKUM
# =========================================================

@router.post(
    "/kelas/{kelas_id}",
    response_model=ModulPraktikumResponse,
    status_code=status.HTTP_201_CREATED,
)
def buat_modul(
    kelas_id: int,
    data: ModulPraktikumCreate,
    db: Session = Depends(get_db),
    pengguna: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = ModulPraktikumService(db)

    return service.buat_modul(
        kelas_id=kelas_id,
        data=data,
        pengguna=pengguna,
    )


# =========================================================
# 3. AMBIL DETAIL MODUL
# =========================================================

@router.get(
    "/{modul_id}",
    response_model=ModulPraktikumResponse,
)
def ambil_detail_modul(
    modul_id: int,
    db: Session = Depends(get_db),
    pengguna: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = ModulPraktikumService(db)

    return service.ambil_detail_modul(
        modul_id=modul_id,
        pengguna=pengguna,
    )


# =========================================================
# 4. PERBARUI MODUL
# =========================================================

@router.patch(
    "/{modul_id}",
    response_model=ModulPraktikumResponse,
)
def perbarui_modul(
    modul_id: int,
    data: ModulPraktikumUpdate,
    db: Session = Depends(get_db),
    pengguna: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = ModulPraktikumService(db)

    return service.perbarui_modul(
        modul_id=modul_id,
        data=data,
        pengguna=pengguna,
    )


# =========================================================
# 5. PUBLIKASIKAN MODUL
# =========================================================

@router.patch(
    "/{modul_id}/publikasikan",
    response_model=ModulPraktikumResponse,
)
def publikasikan_modul(
    modul_id: int,
    db: Session = Depends(get_db),
    pengguna: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = ModulPraktikumService(db)

    return service.publikasikan_modul(
        modul_id=modul_id,
        pengguna=pengguna,
    )


# =========================================================
# 6. TARIK PUBLIKASI MODUL
# =========================================================

@router.patch(
    "/{modul_id}/tarik-publikasi",
    response_model=ModulPraktikumResponse,
)
def tarik_publikasi_modul(
    modul_id: int,
    db: Session = Depends(get_db),
    pengguna: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = ModulPraktikumService(db)

    return service.tarik_publikasi_modul(
        modul_id=modul_id,
        pengguna=pengguna,
    )


# =========================================================
# 7. HAPUS MODUL
# =========================================================

@router.delete(
    "/{modul_id}",
    status_code=status.HTTP_200_OK,
)
def hapus_modul(
    modul_id: int,
    db: Session = Depends(get_db),
    pengguna: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = ModulPraktikumService(db)

    return service.hapus_modul(
        modul_id=modul_id,
        pengguna=pengguna,
    )
