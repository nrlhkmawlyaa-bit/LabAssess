
from pathlib import Path

from fastapi import (
    APIRouter,
    Depends,
    File,
    UploadFile,
    status,
)
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.api.dependencies import izinkan_role
from app.database.session import get_db
from app.models.pengguna import User

from app.schemas.file_modul_praktikum import (
    FileModulPraktikumResponse,
)

from app.services.file_modul_praktikum_service import (
    FileModulPraktikumService,
)


router = APIRouter(
    prefix="/asisten/modul-praktikum",
    tags=["Lampiran Modul Praktikum"],
)


# =========================================================
# 1. UPLOAD SATU FILE
# =========================================================

@router.post(
    "/{modul_id}/files",
    response_model=list[FileModulPraktikumResponse],
    status_code=status.HTTP_201_CREATED,
    summary="Unggah File Modul",
)
async def unggah_file_modul(
    modul_id: int,
    file: UploadFile = File(
        ...,
        description="Pilih satu file untuk diunggah.",
    ),
    db: Session = Depends(get_db),
    pengguna: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = FileModulPraktikumService(db)

    return await service.unggah_file(
        modul_id=modul_id,
        daftar_file=[file],
        pengguna=pengguna,
    )


# =========================================================
# 2. AMBIL DAFTAR FILE
# =========================================================

@router.get(
    "/{modul_id}/files",
    response_model=list[FileModulPraktikumResponse],
    summary="Ambil Daftar File",
)
def ambil_daftar_file(
    modul_id: int,
    db: Session = Depends(get_db),
    pengguna: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = FileModulPraktikumService(db)

    return service.ambil_daftar_file(
        modul_id=modul_id,
        pengguna=pengguna,
    )


# =========================================================
# 3. DOWNLOAD FILE
# =========================================================

@router.get(
    "/{modul_id}/files/{file_id}/download",
    summary="Unduh File",
)
def unduh_file(
    modul_id: int,
    file_id: int,
    db: Session = Depends(get_db),
    pengguna: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = FileModulPraktikumService(db)

    file = service.ambil_detail_file(
        modul_id=modul_id,
        file_id=file_id,
        pengguna=pengguna,
    )

    return FileResponse(
        path=Path(file.storage_path),
        filename=file.original_filename,
        media_type="application/octet-stream",
        content_disposition_type="attachment",
    )


# =========================================================
# 4. HAPUS FILE
# =========================================================

@router.delete(
    "/{modul_id}/files/{file_id}",
    status_code=status.HTTP_200_OK,
    summary="Hapus File",
)
def hapus_file(
    modul_id: int,
    file_id: int,
    db: Session = Depends(get_db),
    pengguna: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = FileModulPraktikumService(db)

    return service.hapus_file(
        modul_id=modul_id,
        file_id=file_id,
        pengguna=pengguna,
    )
