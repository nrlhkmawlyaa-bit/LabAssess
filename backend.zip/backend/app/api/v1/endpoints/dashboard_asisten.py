
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.dependencies import izinkan_role
from app.database.session import get_db

from app.models.pengguna import User

from app.schemas.dashboard_asisten import (
    DashboardAsistenResponse,
)

from app.schemas.detail_kelas_asisten import (
    DetailKelasAsistenResponse,
)

from app.services.dashboard_asisten_service import (
    DashboardAsistenService,
)


router = APIRouter(
    prefix="/asisten",
    tags=["Dashboard Asisten"],
)


# =========================================================
# 1. DASHBOARD ASISTEN
# =========================================================

@router.get(
    "/dashboard",
    response_model=DashboardAsistenResponse,
)
def ambil_dashboard_asisten(
    db: Session = Depends(get_db),
    pengguna: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = DashboardAsistenService(db)

    return service.ambil_ringkasan(pengguna)


# =========================================================
# 2. DETAIL KELAS ASISTEN
# =========================================================

@router.get(
    "/kelas/{kelas_id}",
    response_model=DetailKelasAsistenResponse,
)
def ambil_detail_kelas_asisten(
    kelas_id: int,
    db: Session = Depends(get_db),
    pengguna: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    service = DashboardAsistenService(db)

    return service.ambil_detail_kelas(
        kelas_id=kelas_id,
        pengguna=pengguna,
    )
