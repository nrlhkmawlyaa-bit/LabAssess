
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.dependencies import izinkan_role
from app.database.session import get_db

from app.schemas.kelas_perkuliahan import (
    KelasPerkuliahanCreateRequest,
    KelasPerkuliahanUpdateRequest,
    KelasPerkuliahanResponse,
)

from app.services.kelas_perkuliahan_service import (
    KelasPerkuliahanService,
)


# ==========================================
# ROUTER
# ==========================================

router = APIRouter(
    prefix="/admin/kelas-perkuliahan",
    tags=["Manajemen Kelas Perkuliahan"],
)


# ==========================================
# GET: DAFTAR KELAS PERKULIAHAN
# ==========================================

@router.get(
    "/",
    response_model=list[KelasPerkuliahanResponse],
)
def daftar_kelas_perkuliahan(
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = KelasPerkuliahanService(db)

    return service.ambil_semua()


# ==========================================
# GET: DETAIL KELAS PERKULIAHAN
# ==========================================

@router.get(
    "/{kelas_id}",
    response_model=KelasPerkuliahanResponse,
)
def detail_kelas_perkuliahan(
    kelas_id: int,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = KelasPerkuliahanService(db)

    try:
        return service.ambil_berdasarkan_id(kelas_id)

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(error),
        )


# ==========================================
# POST: TAMBAH KELAS PERKULIAHAN
# ==========================================

@router.post(
    "/",
    response_model=KelasPerkuliahanResponse,
    status_code=status.HTTP_201_CREATED,
)
def tambah_kelas_perkuliahan(
    data: KelasPerkuliahanCreateRequest,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = KelasPerkuliahanService(db)

    try:
        return service.tambah(data.model_dump())

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        )


# ==========================================
# PATCH: UBAH KELAS PERKULIAHAN
# ==========================================

@router.patch(
    "/{kelas_id}",
    response_model=KelasPerkuliahanResponse,
)
def ubah_kelas_perkuliahan(
    kelas_id: int,
    data: KelasPerkuliahanUpdateRequest,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = KelasPerkuliahanService(db)

    try:
        return service.ubah(
            kelas_id,
            data.model_dump(exclude_unset=True),
        )

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        )


# ==========================================
# DELETE: HAPUS KELAS PERKULIAHAN
# ==========================================

@router.delete("/{kelas_id}")
def hapus_kelas_perkuliahan(
    kelas_id: int,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    service = KelasPerkuliahanService(db)

    try:
        return service.hapus(kelas_id)

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        )
