
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.dependencies import izinkan_role
from app.database.session import get_db
from app.models.pengguna import User
from app.schemas.kuis import (
    KuisMahasiswaResponse,
    PengerjaanKuisMahasiswaResponse,
    JawabanKuisSave,
)
from app.services.kuis_service import KuisService


# =====================================================
# ROUTER PENGERJAAN KUIS MAHASISWA
# =====================================================

router = APIRouter(
    prefix="/mahasiswa/kuis",
    tags=["Pengerjaan Kuis Mahasiswa"],
)


# =====================================================
# RIWAYAT NILAI MAHASISWA
# =====================================================

@router.get("/riwayat-nilai")
def ambil_riwayat_nilai_mahasiswa(
    db: Session = Depends(get_db),
    mahasiswa: User = Depends(
        izinkan_role("mahasiswa")
    ),
):
    service = KuisService(db)

    return service.ambil_riwayat_nilai_mahasiswa(
        mahasiswa=mahasiswa,
    )


# =====================================================
# DAFTAR KUIS MAHASISWA
# =====================================================

@router.get(
    "/kelas/{kelas_id}",
    response_model=list[KuisMahasiswaResponse],
)
def ambil_daftar_kuis_mahasiswa(
    kelas_id: int,
    db: Session = Depends(get_db),
    mahasiswa: User = Depends(
        izinkan_role("mahasiswa")
    ),
):
    service = KuisService(db)

    return service.ambil_kuis_mahasiswa(
        kelas_id=kelas_id,
        pengguna=mahasiswa,
    )


# =====================================================
# DETAIL KUIS MAHASISWA
# =====================================================

@router.get(
    "/{kuis_id}",
    response_model=KuisMahasiswaResponse,
)
def ambil_detail_kuis_mahasiswa(
    kuis_id: int,
    db: Session = Depends(get_db),
    mahasiswa: User = Depends(
        izinkan_role("mahasiswa")
    ),
):
    service = KuisService(db)

    return service.ambil_detail_kuis_mahasiswa(
        kuis_id=kuis_id,
        pengguna=mahasiswa,
    )


# =====================================================
# MEMULAI / MELANJUTKAN PENGERJAAN KUIS
# =====================================================

@router.post(
    "/{kuis_id}/mulai",
    response_model=PengerjaanKuisMahasiswaResponse,
)
def mulai_kuis_mahasiswa(
    kuis_id: int,
    db: Session = Depends(get_db),
    mahasiswa: User = Depends(
        izinkan_role("mahasiswa")
    ),
):
    service = KuisService(db)

    return service.mulai_kuis(
        kuis_id=kuis_id,
        pengguna=mahasiswa,
    )


# =====================================================
# MENYIMPAN JAWABAN MAHASISWA
# =====================================================

@router.put(
    "/pengerjaan/{pengerjaan_id}/jawaban",
)
def simpan_jawaban_mahasiswa(
    pengerjaan_id: int,
    data: JawabanKuisSave,
    db: Session = Depends(get_db),
    mahasiswa: User = Depends(
        izinkan_role("mahasiswa")
    ),
):
    service = KuisService(db)

    return service.simpan_jawaban(
        pengerjaan_id=pengerjaan_id,
        data=data,
        pengguna=mahasiswa,
    )


# =====================================================
# MENGUMPULKAN KUIS MAHASISWA
# =====================================================

@router.post(
    "/pengerjaan/{pengerjaan_id}/kumpulkan",
)
def kumpulkan_kuis_mahasiswa(
    pengerjaan_id: int,
    db: Session = Depends(get_db),
    mahasiswa: User = Depends(
        izinkan_role("mahasiswa")
    ),
):
    service = KuisService(db)

    return service.kumpulkan_kuis(
        pengerjaan_id=pengerjaan_id,
        pengguna=mahasiswa,
    )
