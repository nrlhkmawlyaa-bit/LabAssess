
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.schemas.registrasi import (
    RegistrasiMahasiswaRequest,
    RegistrasiMahasiswaResponse,
)
from app.services.registrasi_service import (
    RegistrasiService,
)


router = APIRouter(
    prefix="/auth",
    tags=["Registrasi"],
)


@router.post(
    "/register",
    response_model=RegistrasiMahasiswaResponse,
    status_code=status.HTTP_201_CREATED,
)
def registrasi_mahasiswa(
    data: RegistrasiMahasiswaRequest,
    db: Session = Depends(get_db),
):
    layanan = RegistrasiService(db)

    try:
        return layanan.registrasi_mahasiswa(
            nama_lengkap=data.nama_lengkap,
            nim=data.nim,
            program_studi_id=data.program_studi_id,
            password=data.password,
        )

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        ) from error

    except IntegrityError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="NIM sudah terdaftar.",
        ) from error
