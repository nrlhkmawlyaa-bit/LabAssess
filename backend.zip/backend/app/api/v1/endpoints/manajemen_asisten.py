
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.api.dependencies import izinkan_role

from app.schemas.asisten import (
    BuatAsistenRequest,
    AsistenResponse,
)

from app.services.manajemen_asisten_service import (
    ManajemenAsistenService,
)


router = APIRouter(
    prefix="/admin/asisten",
    tags=["Manajemen Asisten"],
)


@router.post(
    "/",
    response_model=AsistenResponse,
    status_code=status.HTTP_201_CREATED,
)
def buat_akun_asisten(
    data: BuatAsistenRequest,
    db: Session = Depends(get_db),
    admin=Depends(
        izinkan_role("admin_developer")
    ),
):
    layanan = ManajemenAsistenService(db)

    try:
        return layanan.buat_akun_asisten(
            nama_lengkap=data.nama_lengkap,
            username=data.username,
            password=data.password,
        )

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        ) from error

    except IntegrityError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Username sudah digunakan.",
        ) from error
