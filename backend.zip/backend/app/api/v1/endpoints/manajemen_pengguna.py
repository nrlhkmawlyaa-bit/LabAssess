
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.api.dependencies import izinkan_role

from app.schemas.manajemen_pengguna import DaftarPenggunaResponse
from app.schemas.reset_password import ResetPasswordResponse
from app.schemas.ubah_pengguna import (
    EditInformasiPenggunaRequest,
    UbahStatusPenggunaRequest,
)

from app.services.manajemen_pengguna_service import (
    ManajemenPenggunaService,
)
from app.services.reset_password_service import ResetPasswordService


router = APIRouter(
    prefix="/admin/pengguna",
    tags=["Manajemen Pengguna"],
)


# =========================================================
# 1. DAFTAR PENGGUNA
# =========================================================

@router.get("/", response_model=DaftarPenggunaResponse)
def daftar_pengguna(
    role: Literal["mahasiswa", "asisten_lab"] | None = None,
    program_studi_id: int | None = Query(default=None, gt=0),
    status_aktif: bool | None = None,
    kata_kunci: str | None = Query(default=None, max_length=150),
    halaman: int = Query(default=1, ge=1),
    batas: int = Query(default=10, ge=1, le=100),
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    layanan = ManajemenPenggunaService(db)

    return layanan.ambil_daftar_pengguna(
        role=role,
        program_studi_id=program_studi_id,
        status_aktif=status_aktif,
        kata_kunci=kata_kunci,
        halaman=halaman,
        batas=batas,
    )


# =========================================================
# 2. DETAIL PENGGUNA
# =========================================================

@router.get("/{id_pengguna}")
def detail_pengguna(
    id_pengguna: int,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    layanan = ManajemenPenggunaService(db)

    try:
        return layanan.ambil_detail_pengguna(id_pengguna)

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(error),
        )


# =========================================================
# 3. EDIT INFORMASI PENGGUNA
# =========================================================

@router.patch("/{id_pengguna}")
def edit_pengguna(
    id_pengguna: int,
    data: EditInformasiPenggunaRequest,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    layanan = ManajemenPenggunaService(db)

    try:
        return layanan.edit_informasi_pengguna(
            id_pengguna=id_pengguna,
            data=data.model_dump(exclude_unset=True),
        )

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        )


# =========================================================
# 4. AKTIFKAN / NONAKTIFKAN PENGGUNA
# =========================================================

@router.patch("/{id_pengguna}/status")
def ubah_status_pengguna(
    id_pengguna: int,
    data: UbahStatusPenggunaRequest,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    layanan = ManajemenPenggunaService(db)

    try:
        return layanan.ubah_status_pengguna(
            id_pengguna=id_pengguna,
            aktif=data.aktif,
        )

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(error),
        )


# =========================================================
# 5. RESET PASSWORD
# =========================================================

@router.post(
    "/{id_pengguna}/reset-password",
    response_model=ResetPasswordResponse,
    status_code=status.HTTP_200_OK,
)
def reset_password_pengguna(
    id_pengguna: int,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    layanan = ResetPasswordService(db)

    try:
        return layanan.reset_password_pengguna(
            id_pengguna=id_pengguna
        )

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        )

    except Exception:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Terjadi kesalahan saat mereset password.",
        )
