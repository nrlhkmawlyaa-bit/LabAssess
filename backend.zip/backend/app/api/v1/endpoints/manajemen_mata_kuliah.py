
from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Query,
    status,
)
from sqlalchemy.orm import Session

from app.api.dependencies import izinkan_role
from app.database.session import get_db

from app.schemas.mata_kuliah import (
    MataKuliahCreateRequest,
    MataKuliahUpdateRequest,
    MataKuliahResponse,
)

from app.services.mata_kuliah_service import (
    MataKuliahService,
)


router = APIRouter(
    prefix="/admin/mata-kuliah",
    tags=["Manajemen Mata Kuliah"],
)


@router.get(
    "/",
    response_model=list[MataKuliahResponse],
)
def daftar_mata_kuliah(
    kata_kunci: str | None = Query(
        default=None,
        max_length=150,
    ),
    program_studi_id: int | None = Query(
        default=None,
        gt=0,
    ),
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    layanan = MataKuliahService(db)

    return layanan.ambil_daftar_mata_kuliah(
        kata_kunci=kata_kunci,
        program_studi_id=program_studi_id,
    )


@router.get(
    "/{id_mata_kuliah}",
    response_model=MataKuliahResponse,
)
def detail_mata_kuliah(
    id_mata_kuliah: int,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    layanan = MataKuliahService(db)

    try:
        return layanan.ambil_detail_mata_kuliah(
            id_mata_kuliah
        )

    except LookupError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(error),
        )


@router.post(
    "/",
    response_model=MataKuliahResponse,
    status_code=status.HTTP_201_CREATED,
)
def tambah_mata_kuliah(
    data: MataKuliahCreateRequest,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    layanan = MataKuliahService(db)

    try:
        return layanan.tambah_mata_kuliah(
            data.model_dump()
        )

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        )


@router.patch(
    "/{id_mata_kuliah}",
    response_model=MataKuliahResponse,
)
def ubah_mata_kuliah(
    id_mata_kuliah: int,
    data: MataKuliahUpdateRequest,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    layanan = MataKuliahService(db)

    try:
        return layanan.ubah_mata_kuliah(
            id_mata_kuliah=id_mata_kuliah,
            data=data.model_dump(exclude_unset=True),
        )

    except LookupError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(error),
        )

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        )


@router.delete("/{id_mata_kuliah}")
def hapus_mata_kuliah(
    id_mata_kuliah: int,
    db: Session = Depends(get_db),
    admin=Depends(izinkan_role("admin_developer")),
):
    layanan = MataKuliahService(db)

    try:
        return layanan.hapus_mata_kuliah(
            id_mata_kuliah
        )

    except LookupError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(error),
        )

    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(error),
        )
