
from fastapi import APIRouter, Depends

from app.api.dependencies import (
    get_pengguna_aktif,
    izinkan_role,
)
from app.models.pengguna import User


router = APIRouter(
    prefix="/pengujian-akses",
    tags=["Pengujian Akses"],
)


@router.get("/profil")
def lihat_profil(
    pengguna: User = Depends(get_pengguna_aktif),
):
    return {
        "pesan": "Token berhasil diverifikasi.",
        "nama": pengguna.full_name,
        "role": pengguna.role,
    }


@router.get("/admin")
def akses_admin(
    pengguna: User = Depends(
        izinkan_role("admin_developer")
    ),
):
    return {
        "pesan": "Akses Admin berhasil.",
        "nama": pengguna.full_name,
    }


@router.get("/asisten")
def akses_asisten(
    pengguna: User = Depends(
        izinkan_role("asisten_lab")
    ),
):
    return {
        "pesan": "Akses Asisten Lab berhasil.",
        "nama": pengguna.full_name,
    }


@router.get("/mahasiswa")
def akses_mahasiswa(
    pengguna: User = Depends(
        izinkan_role("mahasiswa")
    ),
):
    return {
        "pesan": "Akses Mahasiswa berhasil.",
        "nama": pengguna.full_name,
    }
