from datetime import datetime
from urllib.parse import quote

from fastapi import APIRouter, Depends, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.api.dependencies import izinkan_role
from app.database.session import get_db
from app.models.pengguna import User
from app.services.rekap_nilai_service import RekapNilaiService
from app.services.rekap_nilai_excel_service import RekapNilaiExcelService


router = APIRouter(
    prefix="/asisten/rekap-nilai",
    tags=["Rekap Nilai Asisten"],
)


@router.get("/program-studi")
def ambil_program_studi_rekap(
    db: Session = Depends(get_db),
    asisten: User = Depends(izinkan_role("asisten_lab")),
):
    """Daftar prodi yang terdapat pada kelas yang ditugaskan ke asisten."""
    service = RekapNilaiService(db)
    return service.ambil_daftar_program_studi(asisten=asisten)


@router.get("/per-kuis")
def ambil_rekap_per_kuis(
    program_studi_id: int | None = Query(default=None, gt=0),
    db: Session = Depends(get_db),
    asisten: User = Depends(izinkan_role("asisten_lab")),
):
    """Rekap nilai Pre-Test dan Post-Test secara terpisah."""
    service = RekapNilaiService(db)
    return service.ambil_rekap_per_kuis(
        asisten=asisten,
        program_studi_id=program_studi_id,
    )


@router.get("/gabungan")
def ambil_rekap_gabungan(
    program_studi_id: int | None = Query(default=None, gt=0),
    db: Session = Depends(get_db),
    asisten: User = Depends(izinkan_role("asisten_lab")),
):
    """Rekap gabungan Pre-Test dan Post-Test per mahasiswa dan kelas."""
    service = RekapNilaiService(db)
    return service.ambil_rekap_gabungan(
        asisten=asisten,
        program_studi_id=program_studi_id,
    )


@router.get("/export/per-kuis")
def ekspor_rekap_per_kuis(
    program_studi_id: int | None = Query(default=None, gt=0),
    db: Session = Depends(get_db),
    asisten: User = Depends(izinkan_role("asisten_lab")),
):
    """Mengunduh rekap Pre-Test dan Post-Test dalam format Excel."""
    rekap_service = RekapNilaiService(db)
    export_service = RekapNilaiExcelService()

    rekap = rekap_service.ambil_rekap_per_kuis(
        asisten=asisten,
        program_studi_id=program_studi_id,
    )
    file_excel = export_service.buat_rekap_per_kuis(rekap)

    nama_file = (
        f"rekap_nilai_per_kuis_{datetime.now():%Y%m%d_%H%M%S}.xlsx"
    )

    return StreamingResponse(
        file_excel,
        media_type=(
            "application/vnd.openxmlformats-officedocument."
            "spreadsheetml.sheet"
        ),
        headers={
            "Content-Disposition": (
                f"attachment; filename*=UTF-8''{quote(nama_file)}"
            )
        },
    )


@router.get("/export/gabungan")
def ekspor_rekap_gabungan(
    program_studi_id: int | None = Query(default=None, gt=0),
    db: Session = Depends(get_db),
    asisten: User = Depends(izinkan_role("asisten_lab")),
):
    """Mengunduh rekap nilai gabungan dalam format Excel."""
    rekap_service = RekapNilaiService(db)
    export_service = RekapNilaiExcelService()

    rekap = rekap_service.ambil_rekap_gabungan(
        asisten=asisten,
        program_studi_id=program_studi_id,
    )
    file_excel = export_service.buat_rekap_gabungan(rekap)

    nama_file = (
        f"rekap_nilai_gabungan_{datetime.now():%Y%m%d_%H%M%S}.xlsx"
    )

    return StreamingResponse(
        file_excel,
        media_type=(
            "application/vnd.openxmlformats-officedocument."
            "spreadsheetml.sheet"
        ),
        headers={
            "Content-Disposition": (
                f"attachment; filename*=UTF-8''{quote(nama_file)}"
            )
        },
    )
