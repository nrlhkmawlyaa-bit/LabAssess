from datetime import datetime, timezone

from fastapi import Depends, HTTPException, status
from fastapi.security import (
    HTTPBearer,
    HTTPAuthorizationCredentials,
)
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.models.pengguna import User
from app.core.token import verifikasi_access_token


security = HTTPBearer(auto_error=False)


def get_pengguna_terautentikasi(
    credentials: HTTPAuthorizationCredentials | None = Depends(security),
    db: Session = Depends(get_db),
) -> User:
    """
    Memverifikasi JWT dan mengambil pengguna dari database.
    """

    unauthorized = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Token tidak valid atau sudah kedaluwarsa.",
        headers={"WWW-Authenticate": "Bearer"},
    )

    if credentials is None:
        raise unauthorized

    payload = verifikasi_access_token(
        credentials.credentials
    )

    if payload is None:
        raise unauthorized

    subject = payload.get("sub")
    role_token = payload.get("role")

    if not subject or not role_token:
        raise unauthorized

    try:
        id_pengguna = int(subject)
    except (ValueError, TypeError):
        raise unauthorized

    pengguna = db.scalar(
        select(User).where(
            User.id == id_pengguna
        )
    )

    if pengguna is None:
        raise unauthorized

    if not pengguna.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Akun pengguna dinonaktifkan.",
        )

    if pengguna.role != role_token:
        raise unauthorized

    return pengguna


def get_pengguna_aktif(
    pengguna: User = Depends(
        get_pengguna_terautentikasi
    ),
) -> User:
    """
    Memeriksa pengguna untuk mengakses fitur normal.

    Pengguna yang wajib mengganti password tidak boleh
    mengakses dashboard atau fitur lainnya.
    """

    if pengguna.must_change_password:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "kode": "PASSWORD_CHANGE_REQUIRED",
                "pesan": (
                    "Silakan ganti password sementara "
                    "sebelum melanjutkan."
                ),
            },
        )

    return pengguna


def get_pengguna_wajib_ganti_password(
    pengguna: User = Depends(
        get_pengguna_terautentikasi
    ),
) -> User:
    """
    Khusus untuk endpoint penggantian password sementara.

    Berlaku untuk mahasiswa dan asisten laboratorium.
    """

    role_diizinkan = (
        "mahasiswa",
        "asisten_lab",
    )

    if pengguna.role not in role_diizinkan:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                "Fitur ini hanya tersedia untuk "
                "mahasiswa dan asisten laboratorium."
            ),
        )

    if not pengguna.must_change_password:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Akun tidak sedang diwajibkan "
                "mengganti password."
            ),
        )

    waktu_kedaluwarsa = (
        pengguna.temporary_password_expires_at
    )

    if waktu_kedaluwarsa is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                "Password sementara tidak memiliki "
                "batas waktu yang valid. Hubungi Admin."
            ),
        )

    # MySQL dapat mengembalikan datetime tanpa timezone.
    if waktu_kedaluwarsa.tzinfo is None:
        waktu_kedaluwarsa = waktu_kedaluwarsa.replace(
            tzinfo=timezone.utc
        )

    if datetime.now(timezone.utc) >= waktu_kedaluwarsa:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                "Password sementara sudah kedaluwarsa. "
                "Silakan hubungi Admin untuk reset ulang."
            ),
        )

    return pengguna


def izinkan_role(*role_diizinkan: str):
    """
    Membatasi endpoint berdasarkan role pengguna.
    """

    def pemeriksaan_role(
        pengguna: User = Depends(
            get_pengguna_aktif
        ),
    ) -> User:

        if pengguna.role not in role_diizinkan:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=(
                    "Kamu tidak memiliki izin "
                    "mengakses fitur ini."
                ),
            )

        return pengguna

    return pemeriksaan_role