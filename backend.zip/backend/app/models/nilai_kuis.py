
from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    String,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from app.models.pengerjaan_kuis import QuizAttempt


class QuizGrade(Base):
    """
    Model rekap nilai Pre-Test dan Post-Test.

    Nilai akhir tes dikonversi ke skala 0-100.

    Nilai akhir praktikum mahasiswa dihitung
    dari rata-rata nilai Pre-Test dan Post-Test.
    """

    __tablename__ = "quiz_grades"

    __table_args__ = (
        UniqueConstraint(
            "attempt_id",
            name="uq_quiz_grade_attempt",
        ),
        CheckConstraint(
            "grading_status IN ('pending_review', 'graded', 'published')",
            name="ck_quiz_grade_valid_status",
        ),
        CheckConstraint(
            "total_possible_points > 0",
            name="ck_quiz_grade_positive_total",
        ),
    )

    # Primary Key
    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        index=True,
    )

    # Relasi ke percobaan mahasiswa
    attempt_id: Mapped[int] = mapped_column(
        ForeignKey(
            "quiz_attempts.id",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )

    # Total bobot seluruh soal
    total_possible_points: Mapped[Decimal] = mapped_column(
        Numeric(10, 2),
        nullable=False,
    )

    # Total poin yang diperoleh mahasiswa
    earned_points: Mapped[Decimal | None] = mapped_column(
        Numeric(10, 2),
        nullable=True,
    )

    # Nilai akhir tes dalam skala 0-100
    final_score: Mapped[Decimal | None] = mapped_column(
        Numeric(5, 2),
        nullable=True,
    )

    # Status pemeriksaan dan publikasi
    grading_status: Mapped[str] = mapped_column(
        String(30),
        default="pending_review",
        nullable=False,
        index=True,
    )

    # Waktu publikasi nilai
    published_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    # Waktu pembuatan
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    # Waktu pembaruan
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    # Relasi ke percobaan
    attempt: Mapped[QuizAttempt] = relationship(
        "QuizAttempt",
        back_populates="grade",
    )
