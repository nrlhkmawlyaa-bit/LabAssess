
from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import CheckConstraint, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base

if TYPE_CHECKING:
    from app.models.program_studi import StudyProgram
    from app.models.kelas_perkuliahan import CourseClass


class Course(Base):
    """Model data mata kuliah LabAssess."""

    __tablename__ = "courses"

    __table_args__ = (
        CheckConstraint(
            "credits > 0",
            name="ck_courses_positive_credits",
        ),
    )

    id: Mapped[int] = mapped_column(
        primary_key=True,
        index=True,
    )

    code: Mapped[str] = mapped_column(
        String(30),
        unique=True,
        nullable=False,
    )

    name: Mapped[str] = mapped_column(
        String(150),
        nullable=False,
    )

    credits: Mapped[int] = mapped_column(
        nullable=False,
    )

    study_programs: Mapped[list[StudyProgram]] = relationship(
        "StudyProgram",
        secondary="course_study_programs",
        back_populates="courses",
    )

    course_classes: Mapped[list[CourseClass]] = relationship(
        "CourseClass",
        back_populates="course",
    )
