
from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base


if TYPE_CHECKING:
    from app.models.kelas_perkuliahan import CourseClass
    from app.models.modul_praktikum import PracticumModule
    from app.models.pengguna import User
    from app.models.soal_kuis import QuizQuestion
    from app.models.pengerjaan_kuis import QuizAttempt


class Quiz(Base):
    """
    Model utama Pre-Test dan Post-Test LabAssess.

    Kuis dapat dikaitkan dengan satu modul praktikum.
    module_id bersifat nullable agar kuis lama tetap tersimpan
    sebagai evaluasi yang belum terhubung ke modul.

    Setiap modul memiliki maksimal satu Pre-Test dan satu Post-Test.
    Setiap kuis hanya dapat dikerjakan
    satu kali oleh setiap mahasiswa.
    """

    __tablename__ = "quizzes"

    __table_args__ = (
        UniqueConstraint(
            "module_id",
            "quiz_type",
            name="uq_quiz_module_type",
        ),
        CheckConstraint(
            "quiz_type IN ('pre_test', 'post_test')",
            name="ck_quiz_valid_type",
        ),
        CheckConstraint(
            "duration_minutes > 0",
            name="ck_quiz_positive_duration",
        ),
        CheckConstraint(
            "status IN ('draft', 'published', 'closed')",
            name="ck_quiz_valid_status",
        ),
        CheckConstraint(
            "end_at > start_at",
            name="ck_quiz_valid_schedule",
        ),
    )

    # Primary Key
    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        index=True,
    )

    # Relasi ke kelas perkuliahan
    class_id: Mapped[int] = mapped_column(
        ForeignKey(
            "course_classes.id",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )

    # Relasi opsional ke modul praktikum.
    # Nullable dipertahankan untuk data kuis lama yang belum dipetakan.
    module_id: Mapped[int | None] = mapped_column(
        ForeignKey(
            "practicum_modules.id",
            ondelete="SET NULL",
        ),
        nullable=True,
        index=True,
    )

    # Asisten pembuat kuis
    created_by: Mapped[int] = mapped_column(
        ForeignKey(
            "users.id",
            ondelete="RESTRICT",
        ),
        nullable=False,
        index=True,
    )

    # Jenis tes: pre_test atau post_test
    quiz_type: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
    )

    # Identitas kuis
    title: Mapped[str] = mapped_column(
        String(150),
        nullable=False,
    )

    description: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    # Jadwal pelaksanaan
    start_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
    )

    end_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
    )

    # Durasi pengerjaan dalam menit
    duration_minutes: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
    )

    # Pengaturan pengacakan
    shuffle_questions: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
        nullable=False,
    )

    shuffle_options: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
        nullable=False,
    )

    # Status kuis
    status: Mapped[str] = mapped_column(
        String(20),
        default="draft",
        nullable=False,
        index=True,
    )

    # Waktu pembuatan
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    # Waktu pembaruan
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    # Relasi ke kelas
    course_class: Mapped[CourseClass] = relationship(
        "CourseClass",
        back_populates="quizzes",
    )

    # Relasi ke modul praktikum; kuis lama dapat bernilai None.
    practicum_module: Mapped[PracticumModule | None] = relationship(
        "PracticumModule",
        back_populates="quizzes",
    )

    # Relasi ke asisten pembuat
    creator: Mapped[User] = relationship(
        "User",
        back_populates="created_quizzes",
        foreign_keys=[created_by],
    )

    # Relasi ke soal
    questions: Mapped[list[QuizQuestion]] = relationship(
        "QuizQuestion",
        back_populates="quiz",
        cascade="all, delete-orphan",
        order_by="QuizQuestion.question_order",
    )

    # Relasi ke riwayat pengerjaan
    attempts: Mapped[list[QuizAttempt]] = relationship(
        "QuizAttempt",
        back_populates="quiz",
    )
