
from app.models.relasi_akademik import (
    course_study_programs,
    class_assistants,
    class_students,
)

# MODEL AKADEMIK
from app.models.program_studi import StudyProgram
from app.models.pengguna import User
from app.models.mata_kuliah import Course
from app.models.periode_akademik import AcademicPeriod
from app.models.kelas_perkuliahan import CourseClass

# MODEL MODUL PRAKTIKUM
from app.models.modul_praktikum import PracticumModule
from app.models.file_modul_praktikum import PracticumModuleFile

# MODEL KUIS
from app.models.kuis import Quiz
from app.models.soal_kuis import QuizQuestion
from app.models.opsi_kuis import QuizOption
from app.models.pengerjaan_kuis import QuizAttempt
from app.models.jawaban_kuis import QuizAnswer
from app.models.nilai_kuis import QuizGrade


__all__ = [
    # Akademik
    "StudyProgram",
    "User",
    "Course",
    "AcademicPeriod",
    "CourseClass",

    # Modul Praktikum
    "PracticumModule",
    "PracticumModuleFile",

    # Kuis
    "Quiz",
    "QuizQuestion",
    "QuizOption",
    "QuizAttempt",
    "QuizAnswer",
    "QuizGrade",

    # Tabel Relasi Akademik
    "course_study_programs",
    "class_assistants",
    "class_students",
]
