
from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import CheckConstraint, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base

if TYPE_CHECKING:
    from app.models.kelas_perkuliahan import CourseClass


class AcademicPeriod(Base):
    """Model periode tahun akademik dan semester."""

    __tablename__ = "academic_periods"

    __table_args__ = (
        UniqueConstraint(
            "academic_year",
            "semester",
            name="uq_academic_period_year_semester",
        ),
        CheckConstraint(
            "semester IN ('Ganjil', 'Genap')",
            name="ck_academic_period_valid_semester",
        ),
    )

    id: Mapped[int] = mapped_column(
        primary_key=True,
        index=True,
    )

    academic_year: Mapped[str] = mapped_column(
        String(9),
        nullable=False,
    )

    semester: Mapped[str] = mapped_column(
        String(10),
        nullable=False,
    )

    course_classes: Mapped[list[CourseClass]] = relationship(
        "CourseClass",
        back_populates="academic_period",
    )
