
from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base


class PracticumModuleFile(Base):
    """
    Model untuk menyimpan metadata file lampiran
    yang dimiliki oleh modul praktikum.

    Satu modul dapat memiliki banyak lampiran.
    File fisik disimpan pada storage server.
    """

    __tablename__ = "practicum_module_files"

    # Primary Key
    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        index=True,
    )

    # Relasi ke modul praktikum
    module_id: Mapped[int] = mapped_column(
        ForeignKey(
            "practicum_modules.id",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )

    # Nama file asli yang diunggah pengguna
    original_filename: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
    )

    # Nama file unik pada penyimpanan server
    stored_filename: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        unique=True,
    )

    # Lokasi file pada penyimpanan server
    storage_path: Mapped[str] = mapped_column(
        Text,
        nullable=False,
    )

    # MIME type file
    content_type: Mapped[str | None] = mapped_column(
        String(150),
        nullable=True,
    )

    # Ukuran file dalam byte
    file_size: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
    )

    # Waktu upload
    uploaded_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    # Relasi kembali ke modul praktikum
    practicum_module = relationship(
        "PracticumModule",
        back_populates="files",
    )
