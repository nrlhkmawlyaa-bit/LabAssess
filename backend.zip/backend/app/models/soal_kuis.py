
from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING

from sqlalchemy import (
    CheckConstraint,
    ForeignKey,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base


if TYPE_CHECKING:
    from app.models.kuis import Quiz
    from app.models.opsi_kuis import QuizOption
    from app.models.jawaban_kuis import QuizAnswer


class QuizQuestion(Base):
    """
    Model soal untuk Pre-Test dan Post-Test.

    Jenis soal:
    - multiple_choice
    - essay

    Setiap soal memiliki bobot nilai sendiri.
    """

    __tablename__ = "quiz_questions"

    __table_args__ = (
        UniqueConstraint(
            "quiz_id",
            "question_order",
            name="uq_quiz_question_order",
        ),
        CheckConstraint(
            "question_type IN ('multiple_choice', 'essay')",
            name="ck_quiz_question_valid_type",
        ),
        CheckConstraint(
            "points > 0",
            name="ck_quiz_question_positive_points",
        ),
        CheckConstraint(
            "question_order > 0",
            name="ck_quiz_question_positive_order",
        ),
    )

    # Primary Key
    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        index=True,
    )

    # Relasi ke kuis
    quiz_id: Mapped[int] = mapped_column(
        ForeignKey(
            "quizzes.id",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )

    # Isi pertanyaan
    question_text: Mapped[str] = mapped_column(
        Text,
        nullable=False,
    )

    # Jenis soal
    question_type: Mapped[str] = mapped_column(
        String(30),
        nullable=False,
    )

    # Urutan soal
    question_order: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
    )

    # Bobot soal
    points: Mapped[Decimal] = mapped_column(
        Numeric(10, 2),
        nullable=False,
    )

    # Relasi ke kuis
    quiz: Mapped[Quiz] = relationship(
        "Quiz",
        back_populates="questions",
    )

    # Relasi ke pilihan jawaban
    options: Mapped[list[QuizOption]] = relationship(
        "QuizOption",
        back_populates="question",
        cascade="all, delete-orphan",
        order_by="QuizOption.option_order",
    )

    # Relasi ke jawaban mahasiswa
    answers: Mapped[list[QuizAnswer]] = relationship(
        "QuizAnswer",
        back_populates="question",
    )
