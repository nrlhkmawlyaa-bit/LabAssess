
from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base

if TYPE_CHECKING:
    from app.models.pengguna import User
    from app.models.mata_kuliah import Course


class StudyProgram(Base):
    """Model untuk menyimpan data program studi."""

    __tablename__ = "study_programs"

    id: Mapped[int] = mapped_column(
        primary_key=True,
        index=True,
    )

    code: Mapped[str] = mapped_column(
        String(10),
        unique=True,
        nullable=False,
    )

    name: Mapped[str] = mapped_column(
        String(100),
        unique=True,
        nullable=False,
    )

    users: Mapped[list[User]] = relationship(
        "User",
        back_populates="study_program",
    )

    courses: Mapped[list[Course]] = relationship(
        "Course",
        secondary="course_study_programs",
        back_populates="study_programs",
    )
