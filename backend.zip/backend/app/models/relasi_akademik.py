from sqlalchemy import Column, ForeignKey, Table
from app.database.session import Base

course_study_programs = Table(
    "course_study_programs",
    Base.metadata,
    Column(
        "course_id",
        ForeignKey("courses.id", ondelete="CASCADE"),
        primary_key=True,
    ),
    Column(
        "study_program_id",
        ForeignKey("study_programs.id", ondelete="CASCADE"),
        primary_key=True,
    ),
)


class_assistants = Table(
    "class_assistants",
    Base.metadata,
    Column(
        "class_id",
        ForeignKey("course_classes.id", ondelete="CASCADE"),
        primary_key=True,
    ),
    Column(
        "assistant_id",
        ForeignKey("users.id", ondelete="CASCADE"),
        primary_key=True,
    ),
)


class_students = Table(
    "class_students",
    Base.metadata,
    Column(
        "class_id",
        ForeignKey("course_classes.id", ondelete="CASCADE"),
        primary_key=True,
    ),
    Column(
        "student_id",
        ForeignKey("users.id", ondelete="CASCADE"),
        primary_key=True,
    ),
)
