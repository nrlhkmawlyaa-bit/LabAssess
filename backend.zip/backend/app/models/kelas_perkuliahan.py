
from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import (
    Boolean,
    ForeignKey,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base


if TYPE_CHECKING:
    from app.models.mata_kuliah import Course
    from app.models.periode_akademik import AcademicPeriod
    from app.models.pengguna import User
    from app.models.modul_praktikum import PracticumModule
    from app.models.kuis import Quiz


class CourseClass(Base):
    """
    Model kelas mata kuliah pada periode akademik tertentu.

    Satu kelas dapat memiliki:
    - Satu mata kuliah.
    - Satu periode akademik.
    - Beberapa asisten laboratorium.
    - Beberapa mahasiswa.
    - Beberapa modul praktikum.
    - Banyak evaluasi yang dikelompokkan berdasarkan modul praktikum.
    """

    __tablename__ = "course_classes"

    __table_args__ = (
        UniqueConstraint(
            "course_id",
            "academic_period_id",
            "class_code",
            name="uq_course_class_period_section",
        ),
    )

    # PRIMARY KEY
    id: Mapped[int] = mapped_column(
        primary_key=True,
        index=True,
    )

    # FOREIGN KEYS
    course_id: Mapped[int] = mapped_column(
        ForeignKey("courses.id"),
        nullable=False,
    )

    academic_period_id: Mapped[int] = mapped_column(
        ForeignKey("academic_periods.id"),
        nullable=False,
    )

    # DATA KELAS
    class_code: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
        nullable=False,
    )

    # RELASI MATA KULIAH
    course: Mapped[Course] = relationship(
        "Course",
        back_populates="course_classes",
    )

    # RELASI PERIODE AKADEMIK
    academic_period: Mapped[AcademicPeriod] = relationship(
        "AcademicPeriod",
        back_populates="course_classes",
    )

    # RELASI ASISTEN LABORATORIUM
    assistants: Mapped[list[User]] = relationship(
        "User",
        secondary="class_assistants",
        back_populates="assigned_classes",
    )

    # RELASI MAHASISWA
    students: Mapped[list[User]] = relationship(
        "User",
        secondary="class_students",
        back_populates="enrolled_classes",
    )

    # RELASI MODUL PRAKTIKUM
    practicum_modules: Mapped[list[PracticumModule]] = relationship(
        "PracticumModule",
        back_populates="course_class",
        cascade="all, delete-orphan",
    )

    # RELASI PRE-TEST DAN POST-TEST
    quizzes: Mapped[list[Quiz]] = relationship(
        "Quiz",
        back_populates="course_class",
        cascade="all, delete-orphan",
    )
