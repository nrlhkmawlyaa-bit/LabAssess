
from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base

if TYPE_CHECKING:
    from app.models.kelas_perkuliahan import CourseClass
    from app.models.file_modul_praktikum import PracticumModuleFile
    from app.models.kuis import Quiz


class PracticumModule(Base):
    """
    Model modul praktikum yang dimiliki oleh satu kelas.
    Satu modul dapat mempunyai banyak file lampiran dan maksimal
    satu Pre-Test serta satu Post-Test.
    """

    __tablename__ = "practicum_modules"

    __table_args__ = (
        UniqueConstraint(
            "class_id",
            "module_number",
            name="uq_practicum_module_class_number",
        ),
    )

    # Primary Key
    id: Mapped[int] = mapped_column(
        primary_key=True,
        index=True,
    )

    # Relasi ke kelas perkuliahan
    class_id: Mapped[int] = mapped_column(
        ForeignKey(
            "course_classes.id",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )

    # Nomor urutan modul
    module_number: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
    )

    # Judul modul
    title: Mapped[str] = mapped_column(
        String(150),
        nullable=False,
    )

    # Deskripsi modul
    description: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    # Status publikasi
    is_published: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
        nullable=False,
    )

    # Waktu pembuatan
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    # Waktu pembaruan
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    # Relasi ke kelas
    course_class: Mapped["CourseClass"] = relationship(
        "CourseClass",
        back_populates="practicum_modules",
    )

    # Relasi ke kuis modul. Tidak menggunakan delete cascade agar
    # penghapusan modul tidak menghapus riwayat evaluasi mahasiswa.
    quizzes: Mapped[list["Quiz"]] = relationship(
        "Quiz",
        back_populates="practicum_module",
        passive_deletes=True,
    )

    # Relasi ke file lampiran
    files: Mapped[list["PracticumModuleFile"]] = relationship(
        "PracticumModuleFile",
        back_populates="practicum_module",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
