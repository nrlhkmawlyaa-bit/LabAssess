
from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import TYPE_CHECKING

from sqlalchemy import (
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base


if TYPE_CHECKING:
    from app.models.pengerjaan_kuis import QuizAttempt
    from app.models.soal_kuis import QuizQuestion
    from app.models.opsi_kuis import QuizOption
    from app.models.pengguna import User


class QuizAnswer(Base):
    """
    Model jawaban mahasiswa.

    Mendukung:
    - Pilihan ganda.
    - Esai.

    Jawaban pilihan ganda dikoreksi otomatis.
    Jawaban esai diperiksa secara manual oleh asisten.
    """

    __tablename__ = "quiz_answers"

    __table_args__ = (
        UniqueConstraint(
            "attempt_id",
            "question_id",
            name="uq_quiz_answer_attempt_question",
        ),
    )

    # Primary Key
    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        index=True,
    )

    # Relasi ke percobaan mahasiswa
    attempt_id: Mapped[int] = mapped_column(
        ForeignKey(
            "quiz_attempts.id",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )

    # Relasi ke soal
    question_id: Mapped[int] = mapped_column(
        ForeignKey(
            "quiz_questions.id",
            ondelete="RESTRICT",
        ),
        nullable=False,
        index=True,
    )

    # Jawaban pilihan ganda
    selected_option_id: Mapped[int | None] = mapped_column(
        ForeignKey(
            "quiz_options.id",
            ondelete="RESTRICT",
        ),
        nullable=True,
    )

    # Jawaban esai
    essay_answer: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    # Nilai yang diberikan untuk soal ini
    awarded_points: Mapped[Decimal | None] = mapped_column(
        Numeric(10, 2),
        nullable=True,
    )

    # Asisten yang memeriksa jawaban esai
    graded_by: Mapped[int | None] = mapped_column(
        ForeignKey(
            "users.id",
            ondelete="SET NULL",
        ),
        nullable=True,
    )

    # Waktu pemeriksaan
    graded_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    # Catatan pemeriksaan asisten
    feedback: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    # Waktu jawaban terakhir disimpan
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    # Relasi ke percobaan
    attempt: Mapped[QuizAttempt] = relationship(
        "QuizAttempt",
        back_populates="answers",
    )

    # Relasi ke soal
    question: Mapped[QuizQuestion] = relationship(
        "QuizQuestion",
        back_populates="answers",
    )

    # Relasi ke opsi yang dipilih
    selected_option: Mapped[QuizOption | None] = relationship(
        "QuizOption",
    )

    # Relasi ke asisten pemeriksa
    grader: Mapped[User | None] = relationship(
        "User",
        foreign_keys=[graded_by],
    )
