
from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    ForeignKey,
    Integer,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base


if TYPE_CHECKING:
    from app.models.soal_kuis import QuizQuestion


class QuizOption(Base):
    """
    Model pilihan jawaban untuk soal pilihan ganda.

    Setiap opsi memiliki:
    - Teks pilihan.
    - Penanda apakah jawaban benar.
    - Urutan pilihan.
    """

    __tablename__ = "quiz_options"

    __table_args__ = (
        UniqueConstraint(
            "question_id",
            "option_order",
            name="uq_quiz_option_order",
        ),
        CheckConstraint(
            "option_order > 0",
            name="ck_quiz_option_positive_order",
        ),
    )

    # Primary Key
    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        index=True,
    )

    # Relasi ke soal
    question_id: Mapped[int] = mapped_column(
        ForeignKey(
            "quiz_questions.id",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )

    # Teks pilihan jawaban
    option_text: Mapped[str] = mapped_column(
        Text,
        nullable=False,
    )

    # Penanda kunci jawaban
    is_correct: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
        nullable=False,
    )

    # Urutan asli pilihan
    option_order: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
    )

    # Relasi ke soal
    question: Mapped[QuizQuestion] = relationship(
        "QuizQuestion",
        back_populates="options",
    )
