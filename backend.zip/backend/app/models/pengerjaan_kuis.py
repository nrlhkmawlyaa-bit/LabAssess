
from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    ForeignKey,
    Integer,
    JSON,
    String,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base


if TYPE_CHECKING:
    from app.models.kuis import Quiz
    from app.models.pengguna import User
    from app.models.jawaban_kuis import QuizAnswer
    from app.models.nilai_kuis import QuizGrade


class QuizAttempt(Base):
    """
    Model riwayat pengerjaan Pre-Test dan Post-Test.

    Setiap mahasiswa hanya boleh mempunyai
    satu percobaan untuk setiap kuis.

    Urutan soal dan opsi disimpan agar tidak
    berubah ketika mahasiswa membuka kembali
    halaman pengerjaan.
    """

    __tablename__ = "quiz_attempts"

    __table_args__ = (
        UniqueConstraint(
            "quiz_id",
            "student_id",
            name="uq_quiz_attempt_student",
        ),
        CheckConstraint(
            "status IN ('in_progress', 'submitted')",
            name="ck_quiz_attempt_valid_status",
        ),
    )

    # Primary Key
    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        index=True,
    )

    # Relasi ke kuis
    quiz_id: Mapped[int] = mapped_column(
        ForeignKey(
            "quizzes.id",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )

    # Relasi ke mahasiswa
    student_id: Mapped[int] = mapped_column(
        ForeignKey(
            "users.id",
            ondelete="RESTRICT",
        ),
        nullable=False,
        index=True,
    )

    # Waktu mulai pengerjaan
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
    )

    # Batas waktu pengerjaan
    deadline_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
    )

    # Waktu pengumpulan
    submitted_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    # Status pengerjaan
    status: Mapped[str] = mapped_column(
        String(20),
        default="in_progress",
        nullable=False,
        index=True,
    )

    # Snapshot urutan soal saat mahasiswa memulai
    question_order_snapshot: Mapped[list[int]] = mapped_column(
        JSON,
        nullable=False,
    )

    # Snapshot urutan pilihan jawaban setiap soal
    option_order_snapshot: Mapped[dict[str, list[int]]] = mapped_column(
        JSON,
        nullable=False,
    )

    # Waktu pembuatan data
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    # Relasi ke kuis
    quiz: Mapped[Quiz] = relationship(
        "Quiz",
        back_populates="attempts",
    )

    # Relasi ke mahasiswa
    student: Mapped[User] = relationship(
        "User",
        foreign_keys=[student_id],
    )

    # Relasi ke jawaban
    answers: Mapped[list[QuizAnswer]] = relationship(
        "QuizAnswer",
        back_populates="attempt",
        cascade="all, delete-orphan",
    )

    # Relasi ke nilai
    grade: Mapped[QuizGrade | None] = relationship(
        "QuizGrade",
        back_populates="attempt",
        uselist=False,
        cascade="all, delete-orphan",
    )
