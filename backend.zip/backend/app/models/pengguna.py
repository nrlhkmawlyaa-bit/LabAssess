
from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    String,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base


if TYPE_CHECKING:
    from app.models.program_studi import StudyProgram
    from app.models.kelas_perkuliahan import CourseClass
    from app.models.kuis import Quiz


class User(Base):
    """
    Model utama untuk seluruh pengguna LabAssess.

    Jenis pengguna:
    - admin_developer
    - asisten_lab
    - mahasiswa
    """

    __tablename__ = "users"

    __table_args__ = (
        CheckConstraint(
            """
            (
                role = 'mahasiswa'
                AND nim IS NOT NULL
                AND username IS NULL
                AND study_program_id IS NOT NULL
            )
            OR
            (
                role IN ('admin_developer', 'asisten_lab')
                AND username IS NOT NULL
                AND nim IS NULL
            )
            """,
            name="ck_users_role_identifier",
        ),
        CheckConstraint(
            "role IN ('admin_developer', 'asisten_lab', 'mahasiswa')",
            name="ck_users_valid_role",
        ),
    )

    # IDENTITAS PENGGUNA
    id: Mapped[int] = mapped_column(
        primary_key=True,
        index=True,
    )

    full_name: Mapped[str] = mapped_column(
        String(150),
        nullable=False,
    )

    # IDENTITAS LOGIN ADMIN DAN ASISTEN
    username: Mapped[str | None] = mapped_column(
        String(50),
        unique=True,
        nullable=True,
    )

    # IDENTITAS LOGIN MAHASISWA
    nim: Mapped[str | None] = mapped_column(
        String(30),
        unique=True,
        nullable=True,
    )

    # PASSWORD
    password_hash: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
    )

    # ROLE PENGGUNA
    role: Mapped[str] = mapped_column(
        String(30),
        nullable=False,
    )

    # RELASI PROGRAM STUDI
    study_program_id: Mapped[int | None] = mapped_column(
        ForeignKey("study_programs.id"),
        nullable=True,
    )

    # STATUS AKUN
    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
        nullable=False,
    )

    # WAJIB GANTI PASSWORD
    must_change_password: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
        server_default="0",
        nullable=False,
    )

    # BATAS PENGGUNAAN PASSWORD SEMENTARA
    temporary_password_expires_at: Mapped[datetime | None] = (
        mapped_column(
            DateTime(timezone=True),
            nullable=True,
        )
    )

    # WAKTU PEMBUATAN AKUN
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    # RELASI DENGAN PROGRAM STUDI
    study_program: Mapped[StudyProgram | None] = relationship(
        "StudyProgram",
        back_populates="users",
    )

    # KELAS YANG DITANGANI SEBAGAI ASISTEN
    assigned_classes: Mapped[list[CourseClass]] = relationship(
        "CourseClass",
        secondary="class_assistants",
        back_populates="assistants",
    )

    # KELAS YANG DIIKUTI SEBAGAI MAHASISWA
    enrolled_classes: Mapped[list[CourseClass]] = relationship(
        "CourseClass",
        secondary="class_students",
        back_populates="students",
    )

    # KUIS YANG DIBUAT OLEH ASISTEN
    created_quizzes: Mapped[list[Quiz]] = relationship(
        "Quiz",
        back_populates="creator",
        foreign_keys="Quiz.created_by",
    )
