
from pwdlib import PasswordHash


class PengelolaPassword:
    """
    Mengelola proses hashing dan verifikasi password.

    Encapsulation:
    Proses hashing dan verifikasi disimpan dalam
    satu class agar dapat digunakan kembali.
    """

    def __init__(self):
        self._password_hasher = PasswordHash.recommended()

    def buat_hash(self, password: str) -> str:
        """
        Mengubah password menjadi hash Argon2.

        Password asli tidak disimpan ke database.
        """

        if not password:
            raise ValueError("Password tidak boleh kosong.")

        return self._password_hasher.hash(password)

    def verifikasi(
        self,
        password_asli: str,
        password_hash: str,
    ) -> bool:
        """
        Memeriksa apakah password cocok dengan hash.
        """

        if not password_asli or not password_hash:
            return False

        return self._password_hasher.verify(
            password_asli,
            password_hash,
        )


# Instance yang digunakan bersama oleh layanan aplikasi
pengelola_password = PengelolaPassword()
