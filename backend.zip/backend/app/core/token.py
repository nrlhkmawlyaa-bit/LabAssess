
from datetime import datetime, timedelta, timezone

from jose import JWTError, jwt

from app.core.config import settings


def buat_access_token(
    id_pengguna: int,
    role: str,
) -> str:
    """
    Membuat JWT untuk pengguna yang berhasil login.
    """

    waktu_sekarang = datetime.now(timezone.utc)

    waktu_kedaluwarsa = waktu_sekarang + timedelta(
        minutes=settings.access_token_expire_minutes
    )

    payload = {
        "sub": str(id_pengguna),
        "role": role,
        "iat": waktu_sekarang,
        "exp": waktu_kedaluwarsa,
    }

    token = jwt.encode(
        payload,
        settings.jwt_secret_key,
        algorithm=settings.jwt_algorithm,
    )

    return token


def verifikasi_access_token(token: str) -> dict | None:
    """
    Memverifikasi JWT dan mengembalikan payload
    jika token masih valid.
    """

    try:
        payload = jwt.decode(
            token,
            settings.jwt_secret_key,
            algorithms=[settings.jwt_algorithm],
        )

        return payload

    except JWTError:
        return None
