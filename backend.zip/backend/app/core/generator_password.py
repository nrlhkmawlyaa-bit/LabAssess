
import secrets
import string


class GeneratorPasswordSementara:
    """
    Menghasilkan password sementara secara acak
    untuk kebutuhan reset password mahasiswa.
    """

    AWALAN = "LA"
    JUMLAH_KARAKTER = 8
    PEMISAH = "-"

    # Menghindari karakter yang mudah tertukar:
    # I, O, 0, dan 1.
    KARAKTER = string.ascii_uppercase.replace(
        "I", ""
    ).replace(
        "O", ""
    ) + "23456789"

    @classmethod
    def buat_kode(cls) -> str:
        """
        Membuat kode dengan format LA-XXXX-XXXX.
        """

        karakter_acak = "".join(
            secrets.choice(cls.KARAKTER)
            for _ in range(cls.JUMLAH_KARAKTER)
        )

        bagian_pertama = karakter_acak[:4]
        bagian_kedua = karakter_acak[4:]

        return (
            f"{cls.AWALAN}{cls.PEMISAH}"
            f"{bagian_pertama}{cls.PEMISAH}"
            f"{bagian_kedua}"
        )
