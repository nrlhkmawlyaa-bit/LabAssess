
from app.core.keamanan import pengelola_password


def uji_password():
    password_asli = "LabAssess123!"

    # Membuat hash password
    password_hash = pengelola_password.buat_hash(
        password_asli
    )

    # Memeriksa password yang benar
    hasil_benar = pengelola_password.verifikasi(
        password_asli,
        password_hash,
    )

    # Memeriksa password yang salah
    hasil_salah = pengelola_password.verifikasi(
        "PasswordSalah123",
        password_hash,
    )

    print("HASH PASSWORD:")
    print(password_hash)

    print("\nHASIL PENGUJIAN:")
    print(f"Password benar: {hasil_benar}")
    print(f"Password salah: {hasil_salah}")


if __name__ == "__main__":
    uji_password()
