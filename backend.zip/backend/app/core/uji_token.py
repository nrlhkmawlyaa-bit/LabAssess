
from app.core.token import (
    buat_access_token,
    verifikasi_access_token,
)


token = buat_access_token(
    id_pengguna=1,
    role="admin_developer",
)

print("Token berhasil dibuat:", bool(token))

payload = verifikasi_access_token(token)

print("Token valid:", payload is not None)
print("ID pengguna:", payload.get("sub") if payload else None)
print("Role:", payload.get("role") if payload else None)

token_palsu = verifikasi_access_token("token-tidak-valid")

print("Token palsu ditolak:", token_palsu is None)
