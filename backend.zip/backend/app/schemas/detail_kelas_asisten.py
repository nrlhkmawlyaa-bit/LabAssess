
from pydantic import BaseModel


class MahasiswaDetailKelasResponse(BaseModel):
    id: int
    nama_lengkap: str
    nim: str | None = None
    program_studi: str | None = None


class DetailKelasAsistenResponse(BaseModel):
    id: int
    kode_kelas: str
    kode_mata_kuliah: str
    nama_mata_kuliah: str
    sks: int
    tahun_akademik: str
    semester: str
    is_active: bool
    total_mahasiswa: int
    daftar_mahasiswa: list[MahasiswaDetailKelasResponse]
