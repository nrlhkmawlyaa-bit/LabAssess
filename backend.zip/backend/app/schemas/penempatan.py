
from pydantic import BaseModel, ConfigDict, Field


# ==========================================
# REQUEST PENEMPATAN
# ==========================================

class PenempatanRequest(BaseModel):
    pengguna_id: int = Field(gt=0)


# ==========================================
# RESPONSE PENGGUNA
# ==========================================

class PenggunaPenempatanResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    nama: str
    nim: str | None = None
    role: str
    program_studi_id: int | None = None


# ==========================================
# RESPONSE KELAS DAN PENEMPATAN
# ==========================================

class KelasPenempatanResponse(BaseModel):
    id: int
    course_id: int
    academic_period_id: int
    class_code: str
    is_active: bool

    asisten: list[PenggunaPenempatanResponse] = []
    mahasiswa: list[PenggunaPenempatanResponse] = []
