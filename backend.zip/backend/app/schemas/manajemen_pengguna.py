
from datetime import datetime
from pydantic import BaseModel


class PenggunaAdminItem(BaseModel):
    id: int
    nama_lengkap: str
    username: str | None
    nim: str | None
    role: str
    program_studi_id: int | None
    program_studi: str | None
    aktif: bool
    dibuat_pada: datetime


class DaftarPenggunaResponse(BaseModel):
    total: int
    halaman: int
    batas: int
    data: list[PenggunaAdminItem]
