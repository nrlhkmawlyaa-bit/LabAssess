
from pydantic import BaseModel


class KelasDashboardAsistenResponse(BaseModel):
    id: int
    kode_kelas: str
    kode_mata_kuliah: str
    nama_mata_kuliah: str
    tahun_akademik: str
    semester: str
    is_active: bool
    jumlah_mahasiswa: int


class DashboardAsistenResponse(BaseModel):
    nama_asisten: str
    total_kelas: int
    total_kelas_aktif: int
    total_mahasiswa: int
    daftar_kelas: list[KelasDashboardAsistenResponse]
