
from pydantic import BaseModel, ConfigDict, Field


# ==========================================
# REQUEST: TAMBAH KELAS PERKULIAHAN
# ==========================================

class KelasPerkuliahanCreateRequest(BaseModel):
    course_id: int = Field(..., gt=0)
    academic_period_id: int = Field(..., gt=0)

    class_code: str = Field(
        ...,
        min_length=1,
        max_length=20,
    )


# ==========================================
# REQUEST: UBAH KELAS PERKULIAHAN
# ==========================================

class KelasPerkuliahanUpdateRequest(BaseModel):
    course_id: int | None = Field(default=None, gt=0)
    academic_period_id: int | None = Field(default=None, gt=0)

    class_code: str | None = Field(
        default=None,
        min_length=1,
        max_length=20,
    )

    is_active: bool | None = None


# ==========================================
# RESPONSE: KELAS PERKULIAHAN
# ==========================================

class KelasPerkuliahanResponse(BaseModel):
    id: int
    course_id: int
    academic_period_id: int
    class_code: str
    is_active: bool

    model_config = ConfigDict(from_attributes=True)
