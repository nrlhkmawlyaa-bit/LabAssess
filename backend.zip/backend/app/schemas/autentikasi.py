
from typing import Literal

from pydantic import (
    BaseModel,
    Field,
    SecretStr,
    field_validator,
)


class LoginRequest(BaseModel):
    """
    Data yang diterima ketika pengguna melakukan login.
    """

    role: Literal[
        "admin_developer",
        "asisten_lab",
        "mahasiswa",
    ]

    identitas: str = Field(
        min_length=1,
        max_length=50,
    )

    password: SecretStr = Field(
        min_length=1,
    )

    @field_validator("identitas")
    @classmethod
    def validasi_identitas(cls, nilai: str) -> str:
        nilai = nilai.strip()

        if not nilai:
            raise ValueError("Identitas login wajib diisi.")

        return nilai


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class PenggunaLoginResponse(BaseModel):
    """
    Informasi pengguna yang aman dikirim ke frontend.
    """

    id: int
    nama_lengkap: str
    role: str
    aktif: bool
    wajib_ganti_password: bool = False


class LoginSuccessResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    pengguna: PenggunaLoginResponse
