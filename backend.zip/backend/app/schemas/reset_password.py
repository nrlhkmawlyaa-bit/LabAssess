
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class ResetPasswordResponse(BaseModel):
    """
    Respons ketika Admin berhasil mereset password mahasiswa.
    """

    model_config = ConfigDict(from_attributes=True)

    pesan: str
    id_pengguna: int
    nama_lengkap: str
    nim: str
    password_sementara: str
    berlaku_sampai: datetime
