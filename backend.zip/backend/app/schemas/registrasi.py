
from pydantic import BaseModel, Field, model_validator


class RegistrasiMahasiswaRequest(BaseModel):
    nama_lengkap: str = Field(
        min_length=2,
        max_length=150,
    )

    nim: str = Field(
        min_length=1,
        max_length=30,
    )

    program_studi_id: int = Field(
        gt=0,
    )

    password: str = Field(
        min_length=8,
    )

    konfirmasi_password: str = Field(
        min_length=8,
    )

    @model_validator(mode="after")
    def validasi_registrasi(self):
        self.nama_lengkap = self.nama_lengkap.strip()
        self.nim = self.nim.strip()

        if not self.nama_lengkap:
            raise ValueError("Nama lengkap wajib diisi.")

        if not self.nim:
            raise ValueError("NIM wajib diisi.")

        if self.password != self.konfirmasi_password:
            raise ValueError(
                "Konfirmasi password tidak cocok."
            )

        if len(self.password.encode("utf-8")) > 72:
            raise ValueError(
                "Password maksimal 72 byte."
            )

        return self


class RegistrasiMahasiswaResponse(BaseModel):
    pesan: str
    id: int
    nama_lengkap: str
    nim: str
    program_studi: str
    role: str
    aktif: bool
