
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ModulPraktikumCreate(BaseModel):
    """
    Schema untuk membuat modul praktikum.
    """

    module_number: int = Field(
        gt=0,
        description="Nomor urutan modul",
    )

    title: str = Field(
        min_length=3,
        max_length=150,
        description="Judul modul praktikum",
    )

    description: str | None = Field(
        default=None,
        description="Deskripsi modul praktikum",
    )


class ModulPraktikumUpdate(BaseModel):
    """
    Schema untuk memperbarui modul praktikum.
    """

    module_number: int | None = Field(
        default=None,
        gt=0,
    )

    title: str | None = Field(
        default=None,
        min_length=3,
        max_length=150,
    )

    description: str | None = None

    is_published: bool | None = None


class ModulPraktikumResponse(BaseModel):
    """
    Schema respons data modul praktikum.
    """

    model_config = ConfigDict(from_attributes=True)

    id: int
    class_id: int
    module_number: int
    title: str
    description: str | None
    is_published: bool
    created_at: datetime
    updated_at: datetime
