
from pydantic import BaseModel, Field, SecretStr, model_validator


class GantiPasswordRequest(BaseModel):
    password_baru: SecretStr = Field(
        min_length=8,
        max_length=128,
    )

    konfirmasi_password: SecretStr = Field(
        min_length=8,
        max_length=128,
    )

    @model_validator(mode="after")
    def validasi_konfirmasi(self):
        password = self.password_baru.get_secret_value()
        konfirmasi = self.konfirmasi_password.get_secret_value()

        if password != konfirmasi:
            raise ValueError(
                "Konfirmasi password tidak sesuai."
            )

        return self


class GantiPasswordResponse(BaseModel):
    pesan: str
    berhasil: bool
