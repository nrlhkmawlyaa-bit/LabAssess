
from pydantic import BaseModel, ConfigDict, Field


# ==========================================
# REQUEST: TAMBAH PERIODE AKADEMIK
# ==========================================

class PeriodeAkademikCreateRequest(BaseModel):
    academic_year: str = Field(
        ...,
        min_length=9,
        max_length=9,
        examples=["2026/2027"],
    )

    semester: str = Field(
        ...,
        pattern="^(Ganjil|Genap)$",
        examples=["Ganjil"],
    )


# ==========================================
# REQUEST: UBAH PERIODE AKADEMIK
# ==========================================

class PeriodeAkademikUpdateRequest(BaseModel):
    academic_year: str | None = Field(
        default=None,
        min_length=9,
        max_length=9,
        examples=["2026/2027"],
    )

    semester: str | None = Field(
        default=None,
        pattern="^(Ganjil|Genap)$",
        examples=["Genap"],
    )


# ==========================================
# RESPONSE: PERIODE AKADEMIK
# ==========================================

class PeriodeAkademikResponse(BaseModel):
    id: int
    academic_year: str
    semester: str

    model_config = ConfigDict(from_attributes=True)
