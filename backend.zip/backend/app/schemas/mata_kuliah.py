
from pydantic import BaseModel, Field, ConfigDict


class MataKuliahCreateRequest(BaseModel):
    kode: str = Field(min_length=2, max_length=30)
    nama: str = Field(min_length=2, max_length=150)
    sks: int = Field(gt=0, le=8)
    program_studi_ids: list[int] = Field(min_length=1)


class MataKuliahUpdateRequest(BaseModel):
    kode: str | None = Field(default=None, min_length=2, max_length=30)
    nama: str | None = Field(default=None, min_length=2, max_length=150)
    sks: int | None = Field(default=None, gt=0, le=8)
    program_studi_ids: list[int] | None = Field(
        default=None,
        min_length=1,
    )


class ProgramStudiMataKuliahResponse(BaseModel):
    id: int
    kode: str
    nama: str

    model_config = ConfigDict(from_attributes=True)


class MataKuliahResponse(BaseModel):
    id: int
    kode: str
    nama: str
    sks: int
    program_studi: list[ProgramStudiMataKuliahResponse]

    model_config = ConfigDict(from_attributes=True)
