
from pydantic import BaseModel, Field, field_validator


class BuatAsistenRequest(BaseModel):
    nama_lengkap: str = Field(min_length=2, max_length=150)
    username: str = Field(min_length=3, max_length=50)
    password: str = Field(min_length=8)

    @field_validator("nama_lengkap", "username")
    @classmethod
    def bersihkan_teks(cls, nilai: str) -> str:
        nilai = nilai.strip()

        if not nilai:
            raise ValueError("Data wajib diisi.")

        return nilai

    @field_validator("password")
    @classmethod
    def validasi_password(cls, nilai: str) -> str:
        if len(nilai.encode("utf-8")) > 72:
            raise ValueError("Password maksimal 72 byte.")

        return nilai


class AsistenResponse(BaseModel):
    id: int
    nama_lengkap: str
    username: str
    role: str
    aktif: bool
