
from pydantic import BaseModel, Field, model_validator


class EditInformasiPenggunaRequest(BaseModel):
    """
    Schema untuk mengedit informasi akun mahasiswa atau asisten lab.
    Semua field bersifat opsional agar admin dapat mengubah sebagian data.
    """

    nama_lengkap: str | None = Field(default=None, min_length=1)
    username: str | None = Field(default=None, min_length=1)
    nim: str | None = Field(default=None, min_length=1)
    program_studi_id: int | None = Field(default=None, gt=0)

    @model_validator(mode="after")
    def validasi_data_edit(self):
        if not any(
            nilai is not None
            for nilai in (
                self.nama_lengkap,
                self.username,
                self.nim,
                self.program_studi_id,
            )
        ):
            raise ValueError(
                "Minimal satu informasi akun harus diisi."
            )

        return self


class UbahStatusPenggunaRequest(BaseModel):
    """
    Schema untuk mengaktifkan atau menonaktifkan akun.
    """

    aktif: bool
