
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class MataKuliahMahasiswaResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    code: str
    name: str
    credits: int


class PeriodeMahasiswaResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    academic_year: str
    semester: str


class AsistenMahasiswaResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    full_name: str


class KelasMahasiswaResponse(BaseModel):
    id: int
    class_code: str
    is_active: bool
    mata_kuliah: MataKuliahMahasiswaResponse
    periode_akademik: PeriodeMahasiswaResponse
    asisten: list[AsistenMahasiswaResponse] = []


class DashboardMahasiswaResponse(BaseModel):
    nama_mahasiswa: str
    total_kelas: int
    daftar_kelas: list[KelasMahasiswaResponse]


class FileModulMahasiswaResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    module_id: int
    original_filename: str
    content_type: str | None
    file_size: int
    uploaded_at: datetime


class ModulMahasiswaResponse(BaseModel):
    id: int
    class_id: int
    module_number: int
    title: str
    description: str | None
    created_at: datetime
    updated_at: datetime
    files: list[FileModulMahasiswaResponse] = []
