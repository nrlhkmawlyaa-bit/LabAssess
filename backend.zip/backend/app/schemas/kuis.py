
from datetime import datetime
from decimal import Decimal
from typing import Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    model_validator,
)


# =========================================================
# TIPE DATA KUIS
# =========================================================

JenisKuis = Literal["pre_test", "post_test"]

StatusKuis = Literal[
    "draft",
    "published",
    "closed",
]

JenisSoal = Literal[
    "multiple_choice",
    "essay",
]


# =========================================================
# SCHEMA OPSI JAWABAN
# =========================================================

class OpsiKuisCreate(BaseModel):
    """
    Schema untuk membuat opsi jawaban.
    Digunakan oleh asisten laboratorium.
    """

    option_text: str = Field(
        min_length=1,
        description="Isi opsi jawaban",
    )

    is_correct: bool = Field(
        description="Penanda jawaban yang benar",
    )

    option_order: int = Field(
        gt=0,
        description="Urutan opsi jawaban",
    )


class OpsiKuisResponse(BaseModel):
    """
    Schema opsi jawaban untuk asisten.
    """

    model_config = ConfigDict(from_attributes=True)

    id: int
    question_id: int
    option_text: str
    is_correct: bool
    option_order: int


class OpsiKuisMahasiswaResponse(BaseModel):
    """
    Schema opsi jawaban untuk mahasiswa.

    Tidak menyertakan is_correct agar kunci jawaban
    tidak dapat dilihat mahasiswa.
    """

    model_config = ConfigDict(from_attributes=True)

    id: int
    option_text: str
    option_order: int


# =========================================================
# SCHEMA SOAL KUIS
# =========================================================

class SoalKuisCreate(BaseModel):
    """
    Schema untuk membuat soal Pre-Test atau Post-Test.
    """

    question_text: str = Field(
        min_length=1,
        description="Isi pertanyaan",
    )

    question_type: JenisSoal

    question_order: int = Field(
        gt=0,
        description="Urutan soal",
    )

    points: Decimal = Field(
        gt=0,
        max_digits=10,
        decimal_places=2,
        description="Bobot nilai soal",
    )

    options: list[OpsiKuisCreate] = Field(
        default_factory=list,
        description="Daftar opsi untuk soal pilihan ganda",
    )

    @model_validator(mode="after")
    def validasi_jenis_soal(self):
        if self.question_type == "multiple_choice":
            if len(self.options) < 2:
                raise ValueError(
                    "Soal pilihan ganda minimal memiliki "
                    "dua opsi jawaban."
                )

            jumlah_benar = sum(
                1 for opsi in self.options
                if opsi.is_correct
            )

            if jumlah_benar != 1:
                raise ValueError(
                    "Soal pilihan ganda harus memiliki "
                    "tepat satu jawaban benar."
                )

        elif self.question_type == "essay":
            if self.options:
                raise ValueError(
                    "Soal esai tidak boleh memiliki opsi jawaban."
                )

        return self


class SoalKuisUpdate(BaseModel):
    """
    Schema untuk memperbarui soal kuis.
    """

    question_text: str | None = Field(
        default=None,
        min_length=1,
    )

    question_type: JenisSoal | None = None

    question_order: int | None = Field(
        default=None,
        gt=0,
    )

    points: Decimal | None = Field(
        default=None,
        gt=0,
        max_digits=10,
        decimal_places=2,
    )


class SoalKuisResponse(BaseModel):
    """
    Schema respons soal untuk asisten.
    """

    model_config = ConfigDict(from_attributes=True)

    id: int
    quiz_id: int
    question_text: str
    question_type: str
    question_order: int
    points: Decimal
    options: list[OpsiKuisResponse] = Field(
        default_factory=list,
    )


class SoalKuisMahasiswaResponse(BaseModel):
    """
    Schema soal yang ditampilkan kepada mahasiswa.

    Tidak menampilkan bobot dan kunci jawaban.
    """

    id: int
    question_text: str
    question_type: str
    question_order: int
    options: list[OpsiKuisMahasiswaResponse] = Field(
        default_factory=list,
    )


# =========================================================
# SCHEMA PEMBUATAN KUIS
# =========================================================

class KuisCreate(BaseModel):
    """
    Schema untuk membuat Pre-Test atau Post-Test.
    """

    class_id: int = Field(
        gt=0,
        description="ID kelas perkuliahan",
    )

    # Opsional untuk menjaga kompatibilitas kuis lama/legacy.
    # Kuis baru yang dibuat dari halaman modul mengirim module_id.
    module_id: int | None = Field(
        default=None,
        gt=0,
        description="ID modul praktikum (opsional untuk evaluasi lama)",
    )

    quiz_type: JenisKuis

    title: str = Field(
        min_length=3,
        max_length=150,
        description="Judul kuis",
    )

    description: str | None = None

    start_at: datetime

    end_at: datetime

    duration_minutes: int = Field(
        gt=0,
        description="Durasi pengerjaan dalam menit",
    )

    shuffle_questions: bool = True

    shuffle_options: bool = True

    @model_validator(mode="after")
    def validasi_jadwal(self):
        if self.end_at <= self.start_at:
            raise ValueError(
                "Waktu selesai harus lebih besar "
                "daripada waktu mulai."
            )

        return self


class KuisUpdate(BaseModel):
    """
    Schema untuk memperbarui konfigurasi kuis.
    """

    title: str | None = Field(
        default=None,
        min_length=3,
        max_length=150,
    )

    description: str | None = None

    start_at: datetime | None = None

    end_at: datetime | None = None

    duration_minutes: int | None = Field(
        default=None,
        gt=0,
    )

    shuffle_questions: bool | None = None

    shuffle_options: bool | None = None

    status: StatusKuis | None = None


class KuisStatusUpdate(BaseModel):
    """
    Schema untuk mengubah status publikasi kuis.
    """

    status: StatusKuis


class KuisResponse(BaseModel):
    """
    Schema respons detail kuis untuk asisten.
    """

    model_config = ConfigDict(from_attributes=True)

    id: int
    class_id: int
    module_id: int | None = None
    created_by: int
    quiz_type: str
    title: str
    description: str | None
    start_at: datetime
    end_at: datetime
    duration_minutes: int
    shuffle_questions: bool
    shuffle_options: bool
    status: str
    created_at: datetime
    updated_at: datetime


class KuisMahasiswaResponse(BaseModel):
    """
    Schema informasi kuis untuk mahasiswa.
    Tidak menampilkan konfigurasi internal maupun kunci jawaban.
    """

    id: int
    class_id: int
    module_id: int | None = None
    quiz_type: str
    title: str
    description: str | None
    start_at: datetime
    end_at: datetime
    duration_minutes: int
    status: str


# =========================================================
# SCHEMA DAFTAR KUIS
# =========================================================

class DaftarKuisResponse(BaseModel):
    """
    Schema daftar Pre-Test dan Post-Test.
    """

    total: int
    data: list[KuisResponse]


# =========================================================
# SCHEMA MEMULAI PENGERJAAN KUIS
# =========================================================

class MulaiKuisRequest(BaseModel):
    """
    Request untuk memulai pengerjaan kuis.
    """

    quiz_id: int = Field(
        gt=0,
    )


class PengerjaanKuisResponse(BaseModel):
    """
    Respons pengerjaan kuis kepada mahasiswa.
    """

    id: int
    quiz_id: int
    started_at: datetime
    deadline_at: datetime
    submitted_at: datetime | None
    status: str


class PengerjaanKuisMahasiswaResponse(BaseModel):
    """
    Data kuis yang dapat dikerjakan mahasiswa.
    """

    attempt_id: int
    quiz_id: int
    title: str
    quiz_type: str
    duration_minutes: int
    started_at: datetime
    deadline_at: datetime
    status: str

    questions: list[SoalKuisMahasiswaResponse] = Field(
        default_factory=list,
    )


# =========================================================
# SCHEMA PENYIMPANAN JAWABAN
# =========================================================

class JawabanKuisSave(BaseModel):
    """
    Schema untuk menyimpan atau memperbarui jawaban mahasiswa.
    """

    question_id: int = Field(
        gt=0,
    )

    selected_option_id: int | None = Field(
        default=None,
        gt=0,
    )

    essay_answer: str | None = None

    @model_validator(mode="after")
    def validasi_jawaban(self):
        if (
            self.selected_option_id is not None
            and self.essay_answer is not None
        ):
            raise ValueError(
                "Jawaban tidak boleh berisi pilihan ganda "
                "dan esai sekaligus."
            )

        return self


class JawabanKuisResponse(BaseModel):
    """
    Schema respons jawaban mahasiswa.
    """

    model_config = ConfigDict(from_attributes=True)

    id: int
    attempt_id: int
    question_id: int
    selected_option_id: int | None
    essay_answer: str | None
    awarded_points: Decimal | None
    graded_by: int | None
    graded_at: datetime | None
    feedback: str | None
    updated_at: datetime


# =========================================================
# SCHEMA PENGUMPULAN KUIS
# =========================================================

class KumpulkanKuisRequest(BaseModel):
    """
    Request untuk mengumpulkan hasil pengerjaan kuis.
    """

    attempt_id: int = Field(
        gt=0,
    )


class KumpulkanKuisResponse(BaseModel):
    """
    Respons setelah mahasiswa mengumpulkan kuis.
    """

    attempt_id: int
    submitted_at: datetime
    status: str
    message: str


# =========================================================
# SCHEMA PENILAIAN ESAI
# =========================================================

class PenilaianEsaiRequest(BaseModel):
    """
    Schema penilaian jawaban esai oleh asisten.
    """

    awarded_points: Decimal = Field(
        ge=0,
        max_digits=10,
        decimal_places=2,
    )

    feedback: str | None = None


class PenilaianEsaiResponse(BaseModel):
    """
    Respons hasil penilaian esai.
    """

    answer_id: int
    awarded_points: Decimal
    feedback: str | None
    graded_by: int
    graded_at: datetime


# =========================================================
# SCHEMA NILAI KUIS
# =========================================================

class NilaiKuisResponse(BaseModel):
    """
    Schema respons nilai Pre-Test atau Post-Test.
    """

    model_config = ConfigDict(from_attributes=True)

    id: int
    attempt_id: int
    total_possible_points: Decimal
    earned_points: Decimal | None
    final_score: Decimal | None
    grading_status: str
    published_at: datetime | None
    created_at: datetime
    updated_at: datetime


# =========================================================
# SCHEMA RINGKASAN NILAI PRAKTIKUM
# =========================================================

class NilaiPraktikumResponse(BaseModel):
    """
    Schema ringkasan nilai akhir praktikum.

    Nilai akhir dihitung dari rata-rata Pre-Test
    dan Post-Test setelah keduanya selesai dinilai.
    """

    class_id: int
    student_id: int

    pre_test_score: Decimal | None
    post_test_score: Decimal | None

    final_score: Decimal | None

    is_complete: bool

    grading_status: Literal[
        "incomplete",
        "pending_review",
        "completed",
    ]
