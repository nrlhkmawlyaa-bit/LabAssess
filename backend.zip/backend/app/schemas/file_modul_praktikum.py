from datetime import datetime

from pydantic import BaseModel, ConfigDict


class FileModulPraktikumResponse(BaseModel):
    """
    Schema respons informasi lampiran modul praktikum.
    """

    model_config = ConfigDict(from_attributes=True)

    id: int
    module_id: int
    original_filename: str
    content_type: str | None
    file_size: int
    uploaded_at: datetime