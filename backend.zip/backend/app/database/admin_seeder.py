
import getpass

from sqlalchemy import select

from app.database.session import SessionLocal
from app.models.pengguna import User
from app.core.keamanan import pengelola_password


def jalankan_admin_seeder():
    print("=== PEMBUATAN ADMIN LABASSESS ===")

    nama_lengkap = input("Nama lengkap Admin: ").strip()
    username = input("Username Admin: ").strip()
    password = getpass.getpass("Password Admin: ")
    konfirmasi = getpass.getpass("Konfirmasi password: ")

    if not nama_lengkap or not username or not password:
        print("Semua data wajib diisi.")
        return

    if password != konfirmasi:
        print("Konfirmasi password tidak cocok.")
        return

    if len(password.encode("utf-8")) > 72:
        print("Password maksimal 72 byte.")
        return

    db = SessionLocal()

    try:
        admin_ada = db.scalar(
            select(User).where(
                User.role == "admin_developer"
            )
        )

        if admin_ada:
            print("Akun Admin sudah tersedia.")
            return

        username_ada = db.scalar(
            select(User).where(
                User.username == username
            )
        )

        if username_ada:
            print("Username sudah digunakan.")
            return

        admin = User(
            full_name=nama_lengkap,
            username=username,
            nim=None,
            password_hash=(
                pengelola_password.buat_hash(password)
            ),
            role="admin_developer",
            study_program_id=None,
            is_active=True,
        )

        db.add(admin)
        db.commit()

        print("\nAkun Admin berhasil dibuat!")
        print(f"Nama     : {admin.full_name}")
        print(f"Username : {admin.username}")
        print(f"Role     : {admin.role}")

    except Exception:
        db.rollback()
        raise

    finally:
        db.close()


if __name__ == "__main__":
    jalankan_admin_seeder()
