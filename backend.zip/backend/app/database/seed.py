
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.session import SessionLocal
from app.models import StudyProgram


class ProgramStudiSeeder:
    """
    Class untuk mengelola data awal program studi.

    OOP:
    - Encapsulation: proses seeding dikelola dalam class.
    - Composition: menggunakan Session SQLAlchemy
      untuk berinteraksi dengan database.
    """

    DATA_PROGRAM_STUDI = [
        {
            "code": "TI",
            "name": "Teknik Informatika",
        },
        {
            "code": "SI",
            "name": "Sistem Informasi",
        },
        {
            "code": "BD",
            "name": "Bisnis Digital",
        },
        {
            "code": "TE",
            "name": "Teknik Elektro",
        },
        {
            "code": "TL",
            "name": "Teknik Lingkungan",
        },
        {
            "code": "TIND",
            "name": "Teknik Industri",
        },
    ]

    def __init__(self, session: Session):
        self._session = session

    def jalankan(self) -> int:
        """
        Memasukkan program studi yang belum tersedia.

        Program studi yang sudah ada tidak akan
        dimasukkan kembali.
        """

        jumlah_ditambahkan = 0

        for data in self.DATA_PROGRAM_STUDI:
            program = self._session.scalar(
                select(StudyProgram).where(
                    StudyProgram.code == data["code"]
                )
            )

            if program is not None:
                print(
                    f"[SKIP] {data['name']} sudah tersedia."
                )
                continue

            program_baru = StudyProgram(
                code=data["code"],
                name=data["name"],
            )

            self._session.add(program_baru)
            jumlah_ditambahkan += 1

            print(
                f"[TAMBAH] {data['name']} berhasil disiapkan."
            )

        return jumlah_ditambahkan


def jalankan_seeder() -> None:
    """Mengelola koneksi dan transaksi database."""

    with SessionLocal() as session:
        try:
            with session.begin():
                seeder = ProgramStudiSeeder(session)
                jumlah = seeder.jalankan()

            print("\n================================")
            print("SEEDING PROGRAM STUDI SELESAI")
            print(f"Jumlah data baru: {jumlah}")
            print("================================")

        except Exception as error:
            print(f"\nSeeding gagal: {error}")
            raise


if __name__ == "__main__":
    jalankan_seeder()
