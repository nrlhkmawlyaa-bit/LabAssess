
import re

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models.periode_akademik import AcademicPeriod
from app.repositories.periode_akademik_repository import (
    PeriodeAkademikRepository,
)


class PeriodeAkademikService:
    """
    Service untuk mengelola aturan bisnis periode akademik.
    """

    SEMESTER_VALID = {"Ganjil", "Genap"}

    def __init__(self, db: Session):
        self._db = db
        self._repository = PeriodeAkademikRepository(db)

    # ==========================================
    # VALIDASI TAHUN AKADEMIK
    # ==========================================

    def _validasi_tahun_akademik(
        self,
        academic_year: str,
    ) -> None:

        if not re.fullmatch(r"\d{4}/\d{4}", academic_year):
            raise ValueError(
                "Format tahun akademik harus YYYY/YYYY."
            )

        tahun_awal, tahun_akhir = map(
            int,
            academic_year.split("/"),
        )

        if tahun_akhir != tahun_awal + 1:
            raise ValueError(
                "Tahun akademik harus berurutan, "
                "contoh: 2026/2027."
            )

    # ==========================================
    # VALIDASI SEMESTER
    # ==========================================

    def _validasi_semester(self, semester: str) -> None:

        if semester not in self.SEMESTER_VALID:
            raise ValueError(
                "Semester hanya boleh Ganjil atau Genap."
            )

    # ==========================================
    # FORMAT RESPONSE
    # ==========================================

    def _format_response(
        self,
        periode: AcademicPeriod,
    ) -> dict:

        return {
            "id": periode.id,
            "academic_year": periode.academic_year,
            "semester": periode.semester,
        }

    # ==========================================
    # AMBIL SELURUH PERIODE
    # ==========================================

    def ambil_semua(self) -> list[dict]:

        periode_list = self._repository.ambil_semua()

        return [
            self._format_response(periode)
            for periode in periode_list
        ]

    # ==========================================
    # AMBIL PERIODE BERDASARKAN ID
    # ==========================================

    def ambil_berdasarkan_id(
        self,
        periode_id: int,
    ) -> dict:

        periode = self._repository.ambil_berdasarkan_id(
            periode_id
        )

        if not periode:
            raise ValueError(
                "Periode akademik tidak ditemukan."
            )

        return self._format_response(periode)

    # ==========================================
    # TAMBAH PERIODE AKADEMIK
    # ==========================================

    def tambah(self, data: dict) -> dict:

        academic_year = data["academic_year"].strip()
        semester = data["semester"].strip()

        self._validasi_tahun_akademik(academic_year)
        self._validasi_semester(semester)

        periode_ada = (
            self._repository.ambil_berdasarkan_tahun_dan_semester(
                academic_year,
                semester,
            )
        )

        if periode_ada:
            raise ValueError(
                "Periode akademik tersebut sudah terdaftar."
            )

        periode = AcademicPeriod(
            academic_year=academic_year,
            semester=semester,
        )

        try:
            self._repository.tambah(periode)
            self._db.commit()
            self._db.refresh(periode)

            return self._format_response(periode)

        except IntegrityError:
            self._db.rollback()
            raise ValueError(
                "Periode akademik gagal ditambahkan "
                "karena data sudah terdaftar."
            )

        except Exception:
            self._db.rollback()
            raise

    # ==========================================
    # UBAH PERIODE AKADEMIK
    # ==========================================

    def ubah(
        self,
        periode_id: int,
        data: dict,
    ) -> dict:

        periode = self._repository.ambil_berdasarkan_id(
            periode_id
        )

        if not periode:
            raise ValueError(
                "Periode akademik tidak ditemukan."
            )

        academic_year = data.get(
            "academic_year",
            periode.academic_year,
        )

        semester = data.get(
            "semester",
            periode.semester,
        )

        if academic_year is None or semester is None:
            raise ValueError(
                "Tahun akademik dan semester tidak boleh kosong."
            )

        academic_year = academic_year.strip()
        semester = semester.strip()

        self._validasi_tahun_akademik(academic_year)
        self._validasi_semester(semester)

        periode_duplikat = (
            self._repository.ambil_berdasarkan_tahun_dan_semester(
                academic_year,
                semester,
            )
        )

        if periode_duplikat and periode_duplikat.id != periode_id:
            raise ValueError(
                "Periode akademik tersebut sudah terdaftar."
            )

        periode.academic_year = academic_year
        periode.semester = semester

        try:
            self._db.commit()
            self._db.refresh(periode)

            return self._format_response(periode)

        except IntegrityError:
            self._db.rollback()
            raise ValueError(
                "Perubahan periode akademik gagal."
            )

        except Exception:
            self._db.rollback()
            raise

    # ==========================================
    # HAPUS PERIODE AKADEMIK
    # ==========================================

    def hapus(self, periode_id: int) -> dict:

        periode = self._repository.ambil_berdasarkan_id(
            periode_id
        )

        if not periode:
            raise ValueError(
                "Periode akademik tidak ditemukan."
            )

        if periode.course_classes:
            raise ValueError(
                "Periode akademik tidak dapat dihapus "
                "karena masih digunakan oleh kelas perkuliahan."
            )

        try:
            self._repository.hapus(periode)
            self._db.commit()

            return {
                "berhasil": True,
                "pesan": "Periode akademik berhasil dihapus.",
            }

        except IntegrityError:
            self._db.rollback()
            raise ValueError(
                "Periode akademik tidak dapat dihapus "
                "karena masih memiliki relasi data."
            )

        except Exception:
            self._db.rollback()
            raise
