from __future__ import annotations

from collections import defaultdict
from statistics import mean

from fastapi import HTTPException, status

from app.models.pengguna import User
from app.repositories.rekap_nilai_repository import RekapNilaiRepository


class RekapNilaiService:
    """Logika bisnis rekap nilai kuis untuk asisten laboratorium."""

    def __init__(self, db):
        self._repository = RekapNilaiRepository(db)

    @staticmethod
    def _validasi_asisten(asisten: User) -> None:
        if asisten.role != "asisten_lab":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Fitur ini hanya untuk asisten laboratorium.",
            )

        if not asisten.is_active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Akun asisten tidak aktif.",
            )

    def ambil_daftar_program_studi(self, asisten: User) -> list[dict]:
        """Mengambil pilihan prodi yang ada pada kelas asisten."""
        self._validasi_asisten(asisten)

        return self._repository.ambil_daftar_program_studi(
            asisten_id=asisten.id,
        )

    def ambil_rekap_per_kuis(
        self,
        asisten: User,
        program_studi_id: int | None = None,
    ) -> dict:
        """Mengambil baris rekap per kuis beserta ringkasan statistik."""
        self._validasi_asisten(asisten)

        if program_studi_id is not None and program_studi_id <= 0:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="ID program studi tidak valid.",
            )

        data = self._repository.ambil_rekap_nilai(
            asisten_id=asisten.id,
            program_studi_id=program_studi_id,
        )

        nilai_publikasi = [
            baris["nilai"]
            for baris in data
            if baris["nilai"] is not None
        ]

        total_mahasiswa = len({
            (baris["kelas_id"], baris["mahasiswa_id"])
            for baris in data
        })

        return {
            "filter": {
                "program_studi_id": program_studi_id,
            },
            "total_data": len(data),
            "total_mahasiswa": total_mahasiswa,
            "ringkasan": {
                "jumlah_nilai_dipublikasikan": len(nilai_publikasi),
                "rata_rata": (
                    round(mean(nilai_publikasi), 2)
                    if nilai_publikasi else None
                ),
                "nilai_tertinggi": (
                    max(nilai_publikasi)
                    if nilai_publikasi else None
                ),
                "nilai_terendah": (
                    min(nilai_publikasi)
                    if nilai_publikasi else None
                ),
            },
            "data": data,
        }

    def ambil_rekap_gabungan(
        self,
        asisten: User,
        program_studi_id: int | None = None,
    ) -> dict:
        """Menggabungkan nilai Pre-Test dan Post-Test per mahasiswa dan kelas.

        Nilai gabungan dihitung sebagai rata-rata kedua nilai dan hanya
        tersedia jika Pre-Test serta Post-Test sudah dipublikasikan.
        """
        rekap = self.ambil_rekap_per_kuis(
            asisten=asisten,
            program_studi_id=program_studi_id,
        )

        kelompok = defaultdict(dict)
        identitas = {}

        for baris in rekap["data"]:
            kunci = (baris["kelas_id"], baris["mahasiswa_id"])

            identitas[kunci] = {
                "kelas_id": baris["kelas_id"],
                "kode_kelas": baris["kode_kelas"],
                "mata_kuliah": baris["mata_kuliah"],
                "mahasiswa_id": baris["mahasiswa_id"],
                "nim": baris["nim"],
                "nama_mahasiswa": baris["nama_mahasiswa"],
                "program_studi_id": baris["program_studi_id"],
                "kode_prodi": baris["kode_prodi"],
                "program_studi": baris["program_studi"],
            }

            jenis = (baris.get("jenis_kuis") or "").strip().lower()

            if jenis in {"pre_test", "pretest"}:
                kelompok[kunci]["pre_test"] = baris["nilai"]

            elif jenis in {"post_test", "posttest"}:
                kelompok[kunci]["post_test"] = baris["nilai"]

        hasil = []

        for kunci, data_nilai in kelompok.items():
            pre_test = data_nilai.get("pre_test")
            post_test = data_nilai.get("post_test")

            lengkap = (
                pre_test is not None
                and post_test is not None
            )

            nilai_gabungan = (
                round((pre_test + post_test) / 2, 2)
                if lengkap else None
            )

            hasil.append({
                **identitas[kunci],
                "nilai_pre_test": pre_test,
                "nilai_post_test": post_test,
                "nilai_gabungan": nilai_gabungan,
                "status_gabungan": (
                    "lengkap" if lengkap else "belum_lengkap"
                ),
            })

        hasil.sort(
            key=lambda item: (
                item["program_studi"],
                item["nama_mahasiswa"],
                item["kode_kelas"],
            )
        )

        nilai_gabungan = [
            item["nilai_gabungan"]
            for item in hasil
            if item["nilai_gabungan"] is not None
        ]

        return {
            "filter": {
                "program_studi_id": program_studi_id,
            },
            "total_mahasiswa": len(hasil),
            "ringkasan": {
                "jumlah_gabungan_lengkap": len(nilai_gabungan),
                "rata_rata": (
                    round(mean(nilai_gabungan), 2)
                    if nilai_gabungan else None
                ),
                "nilai_tertinggi": (
                    max(nilai_gabungan)
                    if nilai_gabungan else None
                ),
                "nilai_terendah": (
                    min(nilai_gabungan)
                    if nilai_gabungan else None
                ),
            },
            "data": hasil,
        }