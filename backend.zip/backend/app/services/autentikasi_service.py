
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.core.keamanan import pengelola_password
from app.core.token import buat_access_token
from app.domain.pengguna_factory import PenggunaFactory
from app.repositories.pengguna_repository import PenggunaRepository


class AutentikasiService:
    """
    Menangani seluruh proses autentikasi pengguna.
    """

    ROLE_VALID = (
        "admin_developer",
        "asisten_lab",
        "mahasiswa",
    )

    def __init__(self, db: Session):
        self._pengguna_repository = PenggunaRepository(db)

    def login(
        self,
        identitas: str,
        password: str,
        role: str,
    ) -> dict:
        """
        Memverifikasi identitas dan password,
        kemudian menghasilkan access token.
        """

        if role not in self.ROLE_VALID:
            raise ValueError("Role pengguna tidak valid.")

        pengguna = (
            self._pengguna_repository.cari_berdasarkan_identitas(
                identitas=identitas,
                role=role,
            )
        )

        if pengguna is None:
            raise ValueError("Identitas atau password salah.")

        if not pengelola_password.verifikasi(
            password,
            pengguna.password_hash,
        ):
            raise ValueError("Identitas atau password salah.")

        if not pengguna.is_active:
            raise ValueError("Akun pengguna sedang dinonaktifkan.")

        # Periksa masa berlaku password sementara.
        if pengguna.must_change_password:
            waktu_kedaluwarsa = (
                pengguna.temporary_password_expires_at
            )

            if waktu_kedaluwarsa is None:
                raise ValueError(
                    "Password sementara tidak valid. Hubungi Admin."
                )

            if waktu_kedaluwarsa.tzinfo is None:
                waktu_kedaluwarsa = waktu_kedaluwarsa.replace(
                    tzinfo=timezone.utc
                )

            if datetime.now(timezone.utc) >= waktu_kedaluwarsa:
                raise ValueError(
                    "Password sementara sudah kedaluwarsa. Hubungi Admin untuk reset ulang."
                )

        objek_domain = PenggunaFactory.buat_dari_model(pengguna)

        token = buat_access_token(
            id_pengguna=objek_domain.id_pengguna,
            role=objek_domain.peran,
        )

        return {
            "access_token": token,
            "token_type": "bearer",
            "pengguna": {
                "id": objek_domain.id_pengguna,
                "nama_lengkap": objek_domain.nama_lengkap,
                "role": objek_domain.peran,
                "aktif": objek_domain.aktif,
                "wajib_ganti_password": pengguna.must_change_password,
            },
        }
