from __future__ import annotations

from io import BytesIO
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


class RekapNilaiExcelService:
    """Membuat file Excel untuk laporan rekap nilai asisten laboratorium."""

    WARNA_BURGUNDY = "482A38"
    WARNA_WINE = "824E65"
    WARNA_DUSTY_ROSE = "C99EAD"
    WARNA_ROSE_MIST = "F8F4F6"
    WARNA_BORDER = "E8E4E8"
    WARNA_TEXT = "38323A"
    WARNA_WHITE = "FFFFFF"

    def buat_rekap_per_kuis(self, rekap: dict[str, Any]) -> BytesIO:
        """Membuat Excel dengan data Pre-Test dan Post-Test terpisah."""

        headers = [
            "No.",
            "NIM",
            "Nama Mahasiswa",
            "Program Studi",
            "Kode Prodi",
            "Kode Kelas",
            "Mata Kuliah",
            "Judul Kuis",
            "Jenis Kuis",
            "Status Pengerjaan",
            "Status Penilaian",
            "Nilai",
            "Tanggal Pengumpulan",
            "Tanggal Publikasi",
        ]

        rows = []

        for nomor, item in enumerate(rekap.get("data", []), start=1):
            rows.append([
                nomor,
                item.get("nim"),
                item.get("nama_mahasiswa"),
                item.get("program_studi"),
                item.get("kode_prodi"),
                item.get("kode_kelas"),
                item.get("mata_kuliah"),
                item.get("judul_kuis"),
                item.get("jenis_kuis"),
                item.get("status_pengerjaan"),
                item.get("status_penilaian"),
                item.get("nilai"),
                item.get("tanggal_pengumpulan"),
                item.get("tanggal_publikasi"),
            ])

        return self._buat_file(
            judul="REKAP NILAI PER KUIS",
            nama_sheet="Rekap Per Kuis",
            headers=headers,
            rows=rows,
            ringkasan=[
                ("Total Data", rekap.get("total_data", 0)),
                ("Total Mahasiswa", rekap.get("total_mahasiswa", 0)),
                (
                    "Nilai Dipublikasikan",
                    rekap.get("ringkasan", {}).get(
                        "jumlah_nilai_dipublikasikan", 0
                    ),
                ),
                (
                    "Rata-rata",
                    rekap.get("ringkasan", {}).get("rata_rata"),
                ),
                (
                    "Nilai Tertinggi",
                    rekap.get("ringkasan", {}).get("nilai_tertinggi"),
                ),
                (
                    "Nilai Terendah",
                    rekap.get("ringkasan", {}).get("nilai_terendah"),
                ),
            ],
        )

    def buat_rekap_gabungan(self, rekap: dict[str, Any]) -> BytesIO:
        """Membuat Excel dengan nilai Pre-Test, Post-Test, dan gabungan."""

        headers = [
            "No.",
            "NIM",
            "Nama Mahasiswa",
            "Program Studi",
            "Kode Prodi",
            "Kode Kelas",
            "Mata Kuliah",
            "Nilai Pre-Test",
            "Nilai Post-Test",
            "Nilai Gabungan",
            "Status Gabungan",
        ]

        rows = []

        for nomor, item in enumerate(rekap.get("data", []), start=1):
            rows.append([
                nomor,
                item.get("nim"),
                item.get("nama_mahasiswa"),
                item.get("program_studi"),
                item.get("kode_prodi"),
                item.get("kode_kelas"),
                item.get("mata_kuliah"),
                item.get("nilai_pre_test"),
                item.get("nilai_post_test"),
                item.get("nilai_gabungan"),
                item.get("status_gabungan"),
            ])

        return self._buat_file(
            judul="REKAP NILAI GABUNGAN",
            nama_sheet="Rekap Gabungan",
            headers=headers,
            rows=rows,
            ringkasan=[
                ("Total Mahasiswa", rekap.get("total_mahasiswa", 0)),
                (
                    "Gabungan Lengkap",
                    rekap.get("ringkasan", {}).get(
                        "jumlah_gabungan_lengkap", 0
                    ),
                ),
                (
                    "Rata-rata",
                    rekap.get("ringkasan", {}).get("rata_rata"),
                ),
                (
                    "Nilai Tertinggi",
                    rekap.get("ringkasan", {}).get("nilai_tertinggi"),
                ),
                (
                    "Nilai Terendah",
                    rekap.get("ringkasan", {}).get("nilai_terendah"),
                ),
            ],
        )

    def _buat_file(
        self,
        judul: str,
        nama_sheet: str,
        headers: list[str],
        rows: list[list[Any]],
        ringkasan: list[tuple[str, Any]],
    ) -> BytesIO:
        workbook = Workbook()
        worksheet = workbook.active
        worksheet.title = nama_sheet

        jumlah_kolom = len(headers)

        worksheet.merge_cells(
            start_row=1,
            start_column=1,
            end_row=1,
            end_column=jumlah_kolom,
        )

        judul_cell = worksheet.cell(
            row=1,
            column=1,
            value=judul,
        )

        judul_cell.font = Font(
            name="Aptos Display",
            size=16,
            bold=True,
            color=self.WARNA_WHITE,
        )

        judul_cell.fill = PatternFill(
            "solid",
            fgColor=self.WARNA_BURGUNDY,
        )

        judul_cell.alignment = Alignment(
            horizontal="center",
            vertical="center",
        )

        worksheet.row_dimensions[1].height = 30

        worksheet.merge_cells(
            start_row=2,
            start_column=1,
            end_row=2,
            end_column=jumlah_kolom,
        )

        subtitle = worksheet.cell(
            row=2,
            column=1,
            value="LabAssess | Laboratory Assessment System",
        )

        subtitle.font = Font(
            name="Aptos",
            size=10,
            italic=True,
            color=self.WARNA_WINE,
        )

        subtitle.alignment = Alignment(horizontal="center")

        baris_ringkasan = 4

        worksheet.cell(
            row=baris_ringkasan,
            column=1,
            value="RINGKASAN",
        ).font = Font(
            bold=True,
            color=self.WARNA_BURGUNDY,
            size=11,
        )

        for indeks, (label, nilai) in enumerate(ringkasan, start=5):
            worksheet.cell(
                row=indeks,
                column=1,
                value=label,
            )

            worksheet.cell(
                row=indeks,
                column=2,
                value=nilai,
            )

            worksheet.cell(
                row=indeks,
                column=1,
            ).font = Font(
                bold=True,
                color=self.WARNA_TEXT,
            )

        baris_header = max(12, len(ringkasan) + 6)

        garis = Side(
            style="thin",
            color=self.WARNA_BORDER,
        )

        for kolom, header in enumerate(headers, start=1):
            cell = worksheet.cell(
                row=baris_header,
                column=kolom,
                value=header,
            )

            cell.font = Font(
                bold=True,
                color=self.WARNA_WHITE,
            )

            cell.fill = PatternFill(
                "solid",
                fgColor=self.WARNA_WINE,
            )

            cell.alignment = Alignment(
                horizontal="center",
                vertical="center",
                wrap_text=True,
            )

            cell.border = Border(
                top=garis,
                bottom=garis,
                left=garis,
                right=garis,
            )

        for nomor_baris, data_baris in enumerate(
            rows,
            start=baris_header + 1,
        ):
            for nomor_kolom, nilai in enumerate(data_baris, start=1):
                cell = worksheet.cell(
                    row=nomor_baris,
                    column=nomor_kolom,
                    value=nilai,
                )

                cell.font = Font(
                    name="Aptos",
                    size=10,
                    color=self.WARNA_TEXT,
                )

                cell.alignment = Alignment(
                    vertical="center",
                    wrap_text=True,
                )

                cell.border = Border(
                    bottom=garis,
                    left=garis,
                    right=garis,
                )

                if nomor_baris % 2 == 0:
                    cell.fill = PatternFill(
                        "solid",
                        fgColor=self.WARNA_ROSE_MIST,
                    )

        worksheet.freeze_panes = f"A{baris_header + 1}"

        worksheet.auto_filter.ref = (
            f"A{baris_header}:"
            f"{get_column_letter(jumlah_kolom)}"
            f"{baris_header + len(rows)}"
        )

        for kolom in range(1, jumlah_kolom + 1):
            nilai_header = str(headers[kolom - 1])

            panjang_data = max(
                (
                    len(str(row[kolom - 1]))
                    for row in rows
                    if row[kolom - 1] is not None
                ),
                default=0,
            )

            panjang = max(
                len(nilai_header) + 3,
                min(panjang_data + 2, 32),
            )

            worksheet.column_dimensions[
                get_column_letter(kolom)
            ].width = min(max(panjang, 12), 34)

        worksheet.sheet_view.showGridLines = False

        worksheet.row_dimensions[baris_header].height = 32

        output = BytesIO()

        workbook.save(output)

        output.seek(0)

        return output