
from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.models.pengguna import User
from app.models.kelas_perkuliahan import CourseClass
from app.repositories.penempatan_repository import PenempatanRepository
from app.schemas.penempatan import (
    PenggunaPenempatanResponse,
    KelasPenempatanResponse,
)


class PenempatanService:
    """
    Service untuk mengelola penempatan asisten dan mahasiswa
    pada kelas perkuliahan.
    """

    def __init__(self, db: Session):
        self._db = db
        self._repository = PenempatanRepository(db)

    # ==========================================
    # FORMAT DATA
    # ==========================================

    def _format_pengguna(
        self,
        pengguna: User,
    ) -> PenggunaPenempatanResponse:
        return PenggunaPenempatanResponse(
            id=pengguna.id,
            nama=pengguna.full_name,
            nim=pengguna.nim,
            role=pengguna.role,
            program_studi_id=pengguna.study_program_id,
        )

    def _format_kelas(
        self,
        kelas: CourseClass,
    ) -> KelasPenempatanResponse:
        return KelasPenempatanResponse(
            id=kelas.id,
            course_id=kelas.course_id,
            academic_period_id=kelas.academic_period_id,
            class_code=kelas.class_code,
            is_active=kelas.is_active,
            asisten=[
                self._format_pengguna(asisten)
                for asisten in kelas.assistants
            ],
            mahasiswa=[
                self._format_pengguna(mahasiswa)
                for mahasiswa in kelas.students
            ],
        )

    # ==========================================
    # VALIDASI
    # ==========================================

    def _ambil_kelas(
        self,
        kelas_id: int,
    ) -> CourseClass:
        kelas = self._repository.ambil_kelas_berdasarkan_id(
            kelas_id
        )

        if not kelas:
            raise HTTPException(
                status_code=404,
                detail="Kelas perkuliahan tidak ditemukan.",
            )

        return kelas

    def _ambil_kelas_aktif(
        self,
        kelas_id: int,
    ) -> CourseClass:
        kelas = self._ambil_kelas(kelas_id)

        if not kelas.is_active:
            raise HTTPException(
                status_code=400,
                detail="Kelas perkuliahan tidak aktif.",
            )

        return kelas

    def _ambil_pengguna_valid(
        self,
        pengguna_id: int,
        role: str,
    ) -> User:
        pengguna = (
            self._repository.ambil_pengguna_berdasarkan_id(
                pengguna_id
            )
        )

        if not pengguna:
            raise HTTPException(
                status_code=404,
                detail="Pengguna tidak ditemukan.",
            )

        if not pengguna.is_active:
            raise HTTPException(
                status_code=400,
                detail="Pengguna tidak aktif.",
            )

        if pengguna.role != role:
            raise HTTPException(
                status_code=400,
                detail=f"Pengguna harus memiliki role {role}.",
            )

        return pengguna

    # ==========================================
    # DAFTAR PENEMPATAN
    # ==========================================

    def ambil_semua_penempatan(self):
        kelas_list = self._repository.ambil_semua_kelas()

        return [
            self._format_kelas(kelas)
            for kelas in kelas_list
        ]

    def ambil_detail_penempatan(self, kelas_id: int):
        kelas = self._ambil_kelas(kelas_id)
        return self._format_kelas(kelas)

    def ambil_semua_asisten(self):
        daftar = self._repository.ambil_semua_asisten()

        return [
            self._format_pengguna(asisten)
            for asisten in daftar
        ]

    def ambil_semua_mahasiswa(self):
        daftar = self._repository.ambil_semua_mahasiswa()

        return [
            self._format_pengguna(mahasiswa)
            for mahasiswa in daftar
        ]

    # ==========================================
    # TEMPATKAN ASISTEN
    # ==========================================

    def tempatkan_asisten(
        self,
        kelas_id: int,
        pengguna_id: int,
    ):
        kelas = self._ambil_kelas_aktif(kelas_id)

        asisten = self._ambil_pengguna_valid(
            pengguna_id,
            "asisten_lab",
        )

        if any(
            item.id == asisten.id
            for item in kelas.assistants
        ):
            raise HTTPException(
                status_code=400,
                detail="Asisten tersebut sudah ditempatkan di kelas ini.",
            )

        try:
            self._repository.tambah_asisten_ke_kelas(
                kelas,
                asisten,
            )

            self._repository.simpan()

            return self.ambil_detail_penempatan(kelas_id)

        except Exception:
            self._repository.batalkan()
            raise

    # ==========================================
    # HAPUS PENEMPATAN ASISTEN
    # ==========================================

    def hapus_penempatan_asisten(
        self,
        kelas_id: int,
        asisten_id: int,
    ):
        kelas = self._ambil_kelas(kelas_id)

        asisten = self._ambil_pengguna_valid(
            asisten_id,
            "asisten_lab",
        )

        if not any(
            item.id == asisten.id
            for item in kelas.assistants
        ):
            raise HTTPException(
                status_code=404,
                detail="Asisten tidak terdaftar di kelas ini.",
            )

        try:
            self._repository.hapus_asisten_dari_kelas(
                kelas,
                asisten,
            )

            self._repository.simpan()

        except Exception:
            self._repository.batalkan()
            raise

    # ==========================================
    # TEMPATKAN MAHASISWA
    # ==========================================

    def tempatkan_mahasiswa(
        self,
        kelas_id: int,
        pengguna_id: int,
    ):
        kelas = self._ambil_kelas_aktif(kelas_id)

        mahasiswa = self._ambil_pengguna_valid(
            pengguna_id,
            "mahasiswa",
        )

        if any(
            item.id == mahasiswa.id
            for item in kelas.students
        ):
            raise HTTPException(
                status_code=400,
                detail="Mahasiswa tersebut sudah terdaftar di kelas ini.",
            )

        program_studi_kelas = {
            program.id
            for program in kelas.course.study_programs
        }

        if mahasiswa.study_program_id not in program_studi_kelas:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Program studi mahasiswa tidak sesuai "
                    "dengan mata kuliah."
                ),
            )

        try:
            self._repository.tambah_mahasiswa_ke_kelas(
                kelas,
                mahasiswa,
            )

            self._repository.simpan()

            return self.ambil_detail_penempatan(kelas_id)

        except Exception:
            self._repository.batalkan()
            raise

    # ==========================================
    # HAPUS PENEMPATAN MAHASISWA
    # ==========================================

    def hapus_penempatan_mahasiswa(
        self,
        kelas_id: int,
        mahasiswa_id: int,
    ):
        kelas = self._ambil_kelas(kelas_id)

        mahasiswa = self._ambil_pengguna_valid(
            mahasiswa_id,
            "mahasiswa",
        )

        terdaftar = any(
            item.id == mahasiswa.id
            for item in kelas.students
        )

        if not terdaftar:
            raise HTTPException(
                status_code=404,
                detail="Mahasiswa tidak terdaftar di kelas ini.",
            )

        try:
            self._repository.hapus_mahasiswa_dari_kelas(
                kelas,
                mahasiswa,
            )

            self._repository.simpan()

            self._db.expire_all()

            kelas_terbaru = (
                self._repository.ambil_kelas_berdasarkan_id(
                    kelas_id
                )
            )

            if any(
                item.id == mahasiswa_id
                for item in kelas_terbaru.students
            ):
                raise RuntimeError(
                    "Relasi mahasiswa masih tersimpan di database."
                )

        except Exception:
            self._repository.batalkan()
            raise
