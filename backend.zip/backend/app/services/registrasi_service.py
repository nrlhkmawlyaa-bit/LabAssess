
from sqlalchemy.orm import Session

from app.models.pengguna import User
from app.core.keamanan import pengelola_password
from app.repositories.registrasi_repository import (
    RegistrasiRepository,
)


class RegistrasiService:

    def __init__(self, db: Session):
        self._db = db
        self._repository = RegistrasiRepository(db)

    def registrasi_mahasiswa(
        self,
        nama_lengkap: str,
        nim: str,
        program_studi_id: int,
        password: str,
    ) -> dict:

        # Memeriksa NIM yang sudah terdaftar
        mahasiswa_ada = (
            self._repository.cari_mahasiswa_berdasarkan_nim(
                nim
            )
        )

        if mahasiswa_ada:
            raise ValueError(
                "NIM sudah terdaftar."
            )

        # Memeriksa program studi
        program_studi = (
            self._repository.cari_program_studi(
                program_studi_id
            )
        )

        if program_studi is None:
            raise ValueError(
                "Program studi tidak ditemukan."
            )

        # Membuat hash password Argon2
        password_hash = (
            pengelola_password.buat_hash(password)
        )

        # Membuat akun mahasiswa
        mahasiswa = User(
            full_name=nama_lengkap,
            username=None,
            nim=nim,
            password_hash=password_hash,
            role="mahasiswa",
            study_program_id=program_studi.id,
            is_active=True,
        )

        try:
            self._db.add(mahasiswa)
            self._db.commit()
            self._db.refresh(mahasiswa)

        except Exception:
            self._db.rollback()
            raise

        return {
            "pesan": "Registrasi berhasil. Akun mahasiswa sudah aktif.",
            "id": mahasiswa.id,
            "nama_lengkap": mahasiswa.full_name,
            "nim": mahasiswa.nim,
            "program_studi": program_studi.name,
            "role": mahasiswa.role,
            "aktif": mahasiswa.is_active,
        }
