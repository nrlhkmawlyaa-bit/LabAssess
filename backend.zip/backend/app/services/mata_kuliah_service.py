
from app.models.mata_kuliah import Course
from app.repositories.mata_kuliah_repository import (
    MataKuliahRepository,
)


class MataKuliahService:
    """Service untuk logika bisnis manajemen mata kuliah."""

    def __init__(self, db):
        self._db = db
        self._repository = MataKuliahRepository(db)

    def _format_mata_kuliah(self, mata_kuliah: Course) -> dict:
        return {
            "id": mata_kuliah.id,
            "kode": mata_kuliah.code,
            "nama": mata_kuliah.name,
            "sks": mata_kuliah.credits,
            "program_studi": [
                {
                    "id": prodi.id,
                    "kode": prodi.code,
                    "nama": prodi.name,
                }
                for prodi in mata_kuliah.study_programs
            ],
        }

    def _validasi_program_studi(
        self,
        daftar_id: list[int],
    ):
        if not daftar_id:
            raise ValueError(
                "Pilih minimal satu program studi."
            )

        if any(id_prodi <= 0 for id_prodi in daftar_id):
            raise ValueError(
                "ID program studi harus lebih besar dari nol."
            )

        if len(daftar_id) != len(set(daftar_id)):
            raise ValueError(
                "Program studi tidak boleh dipilih berulang."
            )

        program_studi = self._repository.daftar_program_studi(
            daftar_id
        )

        if len(program_studi) != len(daftar_id):
            raise ValueError(
                "Satu atau lebih program studi tidak ditemukan."
            )

        return program_studi

    def ambil_daftar_mata_kuliah(
        self,
        kata_kunci: str | None = None,
        program_studi_id: int | None = None,
    ):
        daftar = self._repository.daftar_mata_kuliah(
            kata_kunci=kata_kunci,
            program_studi_id=program_studi_id,
        )

        return [
            self._format_mata_kuliah(item)
            for item in daftar
        ]

    def ambil_detail_mata_kuliah(
        self,
        id_mata_kuliah: int,
    ):
        mata_kuliah = self._repository.ambil_berdasarkan_id(
            id_mata_kuliah
        )

        if mata_kuliah is None:
            raise LookupError(
                "Mata kuliah tidak ditemukan."
            )

        return self._format_mata_kuliah(mata_kuliah)

    def tambah_mata_kuliah(self, data: dict):
        kode = data["kode"].strip()
        nama = data["nama"].strip()

        if not kode or not nama:
            raise ValueError(
                "Kode dan nama mata kuliah wajib diisi."
            )

        if self._repository.ambil_berdasarkan_kode(kode):
            raise ValueError(
                "Kode mata kuliah sudah digunakan."
            )

        program_studi = self._validasi_program_studi(
            data["program_studi_ids"]
        )

        mata_kuliah = Course(
            code=kode,
            name=nama,
            credits=data["sks"],
            study_programs=program_studi,
        )

        try:
            self._repository.tambah(mata_kuliah)
            self._db.commit()
            self._db.refresh(mata_kuliah)

            return self.ambil_detail_mata_kuliah(
                mata_kuliah.id
            )

        except Exception:
            self._db.rollback()
            raise

    def ubah_mata_kuliah(
        self,
        id_mata_kuliah: int,
        data: dict,
    ):
        mata_kuliah = self._repository.ambil_berdasarkan_id(
            id_mata_kuliah
        )

        if mata_kuliah is None:
            raise LookupError(
                "Mata kuliah tidak ditemukan."
            )

        kode = data.get("kode")
        nama = data.get("nama")
        sks = data.get("sks")
        daftar_id = data.get("program_studi_ids")

        if kode is not None:
            kode = kode.strip()

            if not kode:
                raise ValueError(
                    "Kode mata kuliah tidak boleh kosong."
                )

            if self._repository.ambil_berdasarkan_kode(
                kode,
                kecuali_id=id_mata_kuliah,
            ):
                raise ValueError(
                    "Kode mata kuliah sudah digunakan."
                )

            mata_kuliah.code = kode

        if nama is not None:
            nama = nama.strip()

            if not nama:
                raise ValueError(
                    "Nama mata kuliah tidak boleh kosong."
                )

            mata_kuliah.name = nama

        if sks is not None:
            mata_kuliah.credits = sks

        if daftar_id is not None:
            mata_kuliah.study_programs = (
                self._validasi_program_studi(daftar_id)
            )

        try:
            self._db.commit()
            self._db.refresh(mata_kuliah)

            return self.ambil_detail_mata_kuliah(
                id_mata_kuliah
            )

        except Exception:
            self._db.rollback()
            raise

    def hapus_mata_kuliah(
        self,
        id_mata_kuliah: int,
    ):
        mata_kuliah = self._repository.ambil_berdasarkan_id(
            id_mata_kuliah
        )

        if mata_kuliah is None:
            raise LookupError(
                "Mata kuliah tidak ditemukan."
            )

        if self._repository.jumlah_kelas(id_mata_kuliah) > 0:
            raise ValueError(
                "Mata kuliah tidak dapat dihapus karena "
                "sudah memiliki kelas perkuliahan."
            )

        try:
            self._repository.hapus(mata_kuliah)
            self._db.commit()

            return {
                "berhasil": True,
                "pesan": "Mata kuliah berhasil dihapus.",
            }

        except Exception:
            self._db.rollback()
            raise
