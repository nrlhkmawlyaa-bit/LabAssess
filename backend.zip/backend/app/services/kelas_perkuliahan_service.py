
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models.kelas_perkuliahan import CourseClass
from app.models.mata_kuliah import Course
from app.models.periode_akademik import AcademicPeriod

from app.repositories.kelas_perkuliahan_repository import (
    KelasPerkuliahanRepository,
)


class KelasPerkuliahanService:
    """
    Service untuk mengelola aturan bisnis kelas perkuliahan.
    """

    def __init__(self, db: Session):
        self._db = db
        self._repository = KelasPerkuliahanRepository(db)

    # ==========================================
    # FORMAT RESPONSE
    # ==========================================

    def _format_response(self, kelas: CourseClass) -> dict:
        return {
            "id": kelas.id,
            "course_id": kelas.course_id,
            "academic_period_id": kelas.academic_period_id,
            "class_code": kelas.class_code,
            "is_active": kelas.is_active,
        }

    # ==========================================
    # VALIDASI MATA KULIAH
    # ==========================================

    def _validasi_mata_kuliah(self, course_id: int) -> None:
        course = self._db.get(Course, course_id)

        if not course:
            raise ValueError("Mata kuliah tidak ditemukan.")

    # ==========================================
    # VALIDASI PERIODE AKADEMIK
    # ==========================================

    def _validasi_periode(self, academic_period_id: int) -> None:
        periode = self._db.get(AcademicPeriod, academic_period_id)

        if not periode:
            raise ValueError("Periode akademik tidak ditemukan.")

    # ==========================================
    # VALIDASI KODE KELAS
    # ==========================================

    def _validasi_kode_kelas(self, class_code: str) -> str:
        if not class_code or not class_code.strip():
            raise ValueError("Kode kelas tidak boleh kosong.")

        return class_code.strip()

    # ==========================================
    # AMBIL SEMUA KELAS
    # ==========================================

    def ambil_semua(self) -> list[dict]:
        daftar_kelas = self._repository.ambil_semua()

        return [
            self._format_response(kelas)
            for kelas in daftar_kelas
        ]

    # ==========================================
    # AMBIL DETAIL KELAS
    # ==========================================

    def ambil_berdasarkan_id(self, kelas_id: int) -> dict:
        kelas = self._repository.ambil_berdasarkan_id(kelas_id)

        if not kelas:
            raise ValueError("Kelas perkuliahan tidak ditemukan.")

        return self._format_response(kelas)

    # ==========================================
    # TAMBAH KELAS
    # ==========================================

    def tambah(self, data: dict) -> dict:
        course_id = data["course_id"]
        academic_period_id = data["academic_period_id"]
        class_code = self._validasi_kode_kelas(data["class_code"])

        self._validasi_mata_kuliah(course_id)
        self._validasi_periode(academic_period_id)

        kelas_duplikat = self._repository.ambil_berdasarkan_kode(
            course_id,
            academic_period_id,
            class_code,
        )

        if kelas_duplikat:
            raise ValueError(
                "Kode kelas tersebut sudah terdaftar "
                "pada mata kuliah dan periode akademik ini."
            )

        kelas = CourseClass(
            course_id=course_id,
            academic_period_id=academic_period_id,
            class_code=class_code,
            is_active=True,
        )

        try:
            self._repository.tambah(kelas)
            self._db.commit()
            self._db.refresh(kelas)

            return self._format_response(kelas)

        except IntegrityError:
            self._db.rollback()
            raise ValueError(
                "Kelas gagal ditambahkan karena data "
                "memiliki konflik atau sudah terdaftar."
            )

        except Exception:
            self._db.rollback()
            raise

    # ==========================================
    # UBAH KELAS
    # ==========================================

    def ubah(self, kelas_id: int, data: dict) -> dict:
        kelas = self._repository.ambil_berdasarkan_id(kelas_id)

        if not kelas:
            raise ValueError("Kelas perkuliahan tidak ditemukan.")

        course_id = data.get("course_id", kelas.course_id)
        academic_period_id = data.get(
            "academic_period_id",
            kelas.academic_period_id,
        )
        class_code = data.get("class_code", kelas.class_code)

        if course_id is None or academic_period_id is None:
            raise ValueError(
                "Mata kuliah dan periode akademik wajib diisi."
            )

        if class_code is None:
            raise ValueError("Kode kelas tidak boleh kosong.")

        class_code = self._validasi_kode_kelas(class_code)

        self._validasi_mata_kuliah(course_id)
        self._validasi_periode(academic_period_id)

        kelas_duplikat = self._repository.ambil_berdasarkan_kode(
            course_id,
            academic_period_id,
            class_code,
        )

        if kelas_duplikat and kelas_duplikat.id != kelas_id:
            raise ValueError(
                "Kode kelas tersebut sudah digunakan "
                "pada mata kuliah dan periode akademik ini."
            )

        try:
            kelas.course_id = course_id
            kelas.academic_period_id = academic_period_id
            kelas.class_code = class_code

            if "is_active" in data:
                if data["is_active"] is None:
                    raise ValueError(
                        "Status aktif tidak boleh kosong."
                    )
                kelas.is_active = data["is_active"]

            self._db.commit()
            self._db.refresh(kelas)

            return self._format_response(kelas)

        except IntegrityError:
            self._db.rollback()
            raise ValueError("Perubahan kelas gagal disimpan.")

        except Exception:
            self._db.rollback()
            raise

    # ==========================================
    # HAPUS KELAS
    # ==========================================

    def hapus(self, kelas_id: int) -> dict:
        kelas = self._repository.ambil_berdasarkan_id(kelas_id)

        if not kelas:
            raise ValueError("Kelas perkuliahan tidak ditemukan.")

        if kelas.assistants or kelas.students:
            raise ValueError(
                "Kelas tidak dapat dihapus karena masih memiliki "
                "asisten atau mahasiswa yang terdaftar."
            )

        try:
            self._repository.hapus(kelas)
            self._db.commit()

            return {
                "berhasil": True,
                "pesan": "Kelas perkuliahan berhasil dihapus.",
            }

        except IntegrityError:
            self._db.rollback()
            raise ValueError(
                "Kelas tidak dapat dihapus karena masih "
                "memiliki relasi data."
            )

        except Exception:
            self._db.rollback()
            raise
