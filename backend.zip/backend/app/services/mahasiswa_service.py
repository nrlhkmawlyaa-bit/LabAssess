
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.pengguna import User
from app.repositories.mahasiswa_repository import MahasiswaRepository


class MahasiswaService:
    """
    Service untuk mengelola dashboard dan aktivitas mahasiswa.
    """

    def __init__(self, db: Session):
        self._repository = MahasiswaRepository(db)

    def _validasi_mahasiswa(self, mahasiswa: User) -> None:
        if mahasiswa.role != "mahasiswa":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Akses hanya diperbolehkan untuk mahasiswa.",
            )

        if not mahasiswa.is_active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Akun mahasiswa tidak aktif.",
            )

    def ambil_dashboard(self, mahasiswa: User) -> dict:
        """
        Mengambil ringkasan dashboard dan kelas mahasiswa.
        """

        self._validasi_mahasiswa(mahasiswa)

        daftar_kelas = self._repository.ambil_semua_kelas(
            mahasiswa_id=mahasiswa.id
        )

        hasil_kelas = []

        for kelas in daftar_kelas:
            hasil_kelas.append({
                "id": kelas.id,
                "class_code": kelas.class_code,
                "is_active": kelas.is_active,

                "mata_kuliah": {
                    "id": kelas.course.id,
                    "code": kelas.course.code,
                    "name": kelas.course.name,
                    "credits": kelas.course.credits,
                },

                "periode_akademik": {
                    "id": kelas.academic_period.id,
                    "academic_year": kelas.academic_period.academic_year,
                    "semester": kelas.academic_period.semester,
                },

                "asisten": [
                    {
                        "id": asisten.id,
                        "full_name": asisten.full_name,
                    }
                    for asisten in kelas.assistants
                ],
            })

        return {
            "nama_mahasiswa": mahasiswa.full_name,
            "total_kelas": len(hasil_kelas),
            "daftar_kelas": hasil_kelas,
        }
