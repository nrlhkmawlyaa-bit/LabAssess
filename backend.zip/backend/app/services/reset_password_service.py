from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.pengguna import User
from app.core.keamanan import pengelola_password
from app.core.generator_password import GeneratorPasswordSementara


class ResetPasswordService:
    """
    Menangani reset password mahasiswa dan asisten
    oleh Admin.
    """

    MASA_BERLAKU_MENIT = 1440

    def __init__(self, db: Session):
        self._db = db

    def reset_password_pengguna(
        self,
        id_pengguna: int,
    ) -> dict:
        """
        Membuat password sementara untuk mahasiswa
        maupun asisten laboratorium.

        Password sementara hanya ditampilkan sekali
        melalui respons endpoint.
        """

        pengguna = self._db.scalar(
            select(User).where(
                User.id == id_pengguna,
                User.role.in_(
                    ("mahasiswa", "asisten_lab")
                ),
            )
        )

        if pengguna is None:
            raise ValueError(
                "Akun mahasiswa atau asisten tidak ditemukan."
            )

        if not pengguna.is_active:
            raise ValueError(
                "Akun sedang dinonaktifkan. Aktifkan akun terlebih dahulu."
            )

        password_sementara = (
            GeneratorPasswordSementara.buat_kode()
        )

        waktu_sekarang = datetime.now(timezone.utc)

        berlaku_sampai = (
            waktu_sekarang
            + timedelta(minutes=self.MASA_BERLAKU_MENIT)
        )

        try:
            pengguna.password_hash = (
                pengelola_password.buat_hash(
                    password_sementara
                )
            )

            pengguna.must_change_password = True

            pengguna.temporary_password_expires_at = (
                berlaku_sampai
            )

            self._db.commit()
            self._db.refresh(pengguna)

        except Exception:
            self._db.rollback()
            raise

        return {
            "pesan": (
                "Password berhasil direset. "
                "Berikan password sementara kepada pengguna."
            ),
            "id_pengguna": pengguna.id,
            "nama_lengkap": pengguna.full_name,
            "username": pengguna.username,
            "nim": pengguna.nim,
            "role": pengguna.role,
            "password_sementara": password_sementara,
            "berlaku_sampai": berlaku_sampai,
        }