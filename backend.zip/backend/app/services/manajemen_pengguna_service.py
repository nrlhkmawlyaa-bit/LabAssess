
from app.repositories.manajemen_pengguna_repository import (
    ManajemenPenggunaRepository,
)


class ManajemenPenggunaService:
    """
    Service untuk menangani logika bisnis manajemen pengguna.

    Menghubungkan endpoint API dengan repository database.
    """

    def __init__(self, db):
        self._repository = ManajemenPenggunaRepository(db)

    def _format_pengguna(self, pengguna):
        """
        Mengubah objek User menjadi data yang siap dikirim API.
        """

        return {
            "id": pengguna.id,
            "nama_lengkap": pengguna.full_name,
            "username": pengguna.username,
            "nim": pengguna.nim,
            "role": pengguna.role,
            "program_studi_id": pengguna.study_program_id,
            "program_studi": (
                pengguna.study_program.name
                if pengguna.study_program
                else None
            ),
            "aktif": pengguna.is_active,
            "dibuat_pada": pengguna.created_at,
        }

    def ambil_daftar_pengguna(
        self,
        role=None,
        program_studi_id=None,
        status_aktif=None,
        kata_kunci=None,
        halaman=1,
        batas=10,
    ):
        """
        Mengambil daftar pengguna dengan filter dan pagination.
        """

        total, daftar = self._repository.daftar_pengguna(
            role=role,
            program_studi_id=program_studi_id,
            status_aktif=status_aktif,
            kata_kunci=kata_kunci,
            halaman=halaman,
            batas=batas,
        )

        data_pengguna = [
            self._format_pengguna(pengguna)
            for pengguna in daftar
        ]

        return {
            "total": total,
            "halaman": halaman,
            "batas": batas,
            "data": data_pengguna,
        }

    def ambil_detail_pengguna(self, id_pengguna: int):
        """
        Mengambil detail akun berdasarkan ID.
        """

        pengguna = self._repository.ambil_pengguna_berdasarkan_id(
            id_pengguna
        )

        if pengguna is None:
            raise ValueError("Akun pengguna tidak ditemukan.")

        return self._format_pengguna(pengguna)

    def edit_informasi_pengguna(
        self,
        id_pengguna: int,
        data: dict,
    ):
        """
        Mengubah informasi akun mahasiswa atau asisten laboratorium.
        Role dan password tidak diubah melalui fitur ini.
        """

        db = self._repository._db

        pengguna = self._repository.ambil_pengguna_berdasarkan_id(
            id_pengguna
        )

        if pengguna is None:
            raise ValueError("Akun pengguna tidak ditemukan.")

        nama_lengkap = data.get("nama_lengkap")

        if nama_lengkap is not None:
            nama_lengkap = nama_lengkap.strip()

            if not nama_lengkap:
                raise ValueError("Nama lengkap tidak boleh kosong.")

            pengguna.full_name = nama_lengkap

        if pengguna.role == "mahasiswa":

            nim = data.get("nim")
            program_studi_id = data.get("program_studi_id")

            if nim is not None:
                nim = nim.strip()

                if not nim:
                    raise ValueError("NIM tidak boleh kosong.")

                if self._repository.nim_sudah_digunakan(
                    nim,
                    kecuali_id=id_pengguna,
                ):
                    raise ValueError("NIM sudah digunakan oleh akun lain.")

                pengguna.nim = nim

            if program_studi_id is not None:
                if not self._repository.program_studi_tersedia(
                    program_studi_id
                ):
                    raise ValueError("Program studi tidak ditemukan.")

                pengguna.study_program_id = program_studi_id

        elif pengguna.role == "asisten_lab":

            username = data.get("username")

            if username is not None:
                username = username.strip()

                if not username:
                    raise ValueError("Username tidak boleh kosong.")

                if self._repository.username_sudah_digunakan(
                    username,
                    kecuali_id=id_pengguna,
                ):
                    raise ValueError(
                        "Username sudah digunakan oleh akun lain."
                    )

                pengguna.username = username

        try:
            db.commit()
            db.refresh(pengguna)

        except Exception:
            db.rollback()
            raise

        return self.ambil_detail_pengguna(id_pengguna)

    def ubah_status_pengguna(
        self,
        id_pengguna: int,
        aktif: bool,
    ):
        """
        Mengaktifkan atau menonaktifkan akun pengguna.
        Akun tidak dihapus permanen.
        """

        db = self._repository._db

        pengguna = self._repository.ambil_pengguna_berdasarkan_id(
            id_pengguna
        )

        if pengguna is None:
            raise ValueError("Akun pengguna tidak ditemukan.")

        pengguna.is_active = aktif

        try:
            db.commit()
            db.refresh(pengguna)

        except Exception:
            db.rollback()
            raise

        return {
            "pesan": (
                "Akun berhasil diaktifkan."
                if aktif
                else "Akun berhasil dinonaktifkan."
            ),
            "berhasil": True,
            "pengguna": self.ambil_detail_pengguna(id_pengguna),
        }
