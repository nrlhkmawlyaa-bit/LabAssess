
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.pengguna import User
from app.core.keamanan import pengelola_password


class ManajemenAsistenService:

    def __init__(self, db: Session):
        self._db = db

    def buat_akun_asisten(
        self,
        nama_lengkap: str,
        username: str,
        password: str,
    ) -> dict:

        username_ada = self._db.scalar(
            select(User).where(
                User.username == username
            )
        )

        if username_ada:
            raise ValueError("Username sudah digunakan.")

        asisten = User(
            full_name=nama_lengkap,
            username=username,
            nim=None,
            password_hash=pengelola_password.buat_hash(
                password
            ),
            role="asisten_lab",
            study_program_id=None,
            is_active=True,
        )

        try:
            self._db.add(asisten)
            self._db.commit()
            self._db.refresh(asisten)

        except Exception:
            self._db.rollback()
            raise

        return {
            "id": asisten.id,
            "nama_lengkap": asisten.full_name,
            "username": asisten.username,
            "role": asisten.role,
            "aktif": asisten.is_active,
        }
