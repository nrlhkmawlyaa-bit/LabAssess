
from fastapi import HTTPException, status

from app.domain.asisten_lab import AsistenLabUser
from app.models.pengguna import User
from app.models.modul_praktikum import PracticumModule

from app.repositories.modul_praktikum_repository import (
    ModulPraktikumRepository,
)

from app.schemas.modul_praktikum import (
    ModulPraktikumCreate,
    ModulPraktikumUpdate,
)


class ModulPraktikumService:
    """
    Service untuk mengelola modul praktikum.

    Asisten hanya dapat mengelola modul pada kelas
    yang ditugaskan oleh Administrator.
    """

    def __init__(self, db):
        self._repository = ModulPraktikumRepository(db)

    # =====================================================
    # VALIDASI ASISTEN
    # =====================================================

    def _validasi_asisten(self, pengguna: User) -> None:
        if pengguna.role != "asisten_lab":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Fitur ini hanya untuk asisten laboratorium.",
            )

        domain_asisten = AsistenLabUser(
            id_pengguna=pengguna.id,
            nama_lengkap=pengguna.full_name,
            aktif=pengguna.is_active,
        )

        if not domain_asisten.dapat_masuk():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Akun asisten tidak aktif.",
            )

    # =====================================================
    # VALIDASI KEPEMILIKAN KELAS
    # =====================================================

    def _validasi_kelas(
        self,
        kelas_id: int,
        pengguna: User,
    ) -> None:

        kelas = self._repository.cek_kelas_asisten(
            kelas_id=kelas_id,
            asisten_id=pengguna.id,
        )

        if kelas is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=(
                    "Kelas tidak ditemukan atau bukan "
                    "merupakan kelas yang ditugaskan kepadamu."
                ),
            )

    # =====================================================
    # AMBIL SEMUA MODUL
    # =====================================================

    def ambil_semua_modul(
        self,
        kelas_id: int,
        pengguna: User,
    ):

        self._validasi_asisten(pengguna)
        self._validasi_kelas(kelas_id, pengguna)

        return self._repository.ambil_semua_modul(
            kelas_id=kelas_id,
            asisten_id=pengguna.id,
        )

    # =====================================================
    # AMBIL DETAIL MODUL
    # =====================================================

    def ambil_detail_modul(
        self,
        modul_id: int,
        pengguna: User,
    ):

        self._validasi_asisten(pengguna)

        modul = self._repository.ambil_modul_berdasarkan_id(
            modul_id=modul_id,
            asisten_id=pengguna.id,
        )

        if modul is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Modul tidak ditemukan.",
            )

        return modul

    # =====================================================
    # BUAT MODUL
    # =====================================================

    def buat_modul(
        self,
        kelas_id: int,
        data: ModulPraktikumCreate,
        pengguna: User,
    ):

        self._validasi_asisten(pengguna)
        self._validasi_kelas(kelas_id, pengguna)

        nomor_duplikat = self._repository.cek_nomor_modul(
            kelas_id=kelas_id,
            nomor_modul=data.module_number,
        )

        if nomor_duplikat is not None:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    f"Modul nomor {data.module_number} "
                    "sudah tersedia pada kelas ini."
                ),
            )

        modul = PracticumModule(
            class_id=kelas_id,
            module_number=data.module_number,
            title=data.title.strip(),
            description=(
                data.description.strip()
                if data.description
                else None
            ),
            is_published=False,
        )

        try:
            hasil = self._repository.tambah(modul)
            self._repository.commit()
            return hasil

        except Exception:
            self._repository.rollback()
            raise

    # =====================================================
    # PERBARUI MODUL
    # =====================================================

    def perbarui_modul(
        self,
        modul_id: int,
        data: ModulPraktikumUpdate,
        pengguna: User,
    ):

        self._validasi_asisten(pengguna)

        modul = self._repository.ambil_modul_berdasarkan_id(
            modul_id=modul_id,
            asisten_id=pengguna.id,
        )

        if modul is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Modul tidak ditemukan.",
            )

        perubahan = data.model_dump(exclude_unset=True)

        if "module_number" in perubahan:
            nomor_baru = perubahan["module_number"]

            if nomor_baru is not None:
                nomor_duplikat = self._repository.cek_nomor_modul(
                    kelas_id=modul.class_id,
                    nomor_modul=nomor_baru,
                    kecuali_modul_id=modul.id,
                )

                if nomor_duplikat is not None:
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail=(
                            f"Modul nomor {nomor_baru} "
                            "sudah tersedia pada kelas ini."
                        ),
                    )

                modul.module_number = nomor_baru

        if "title" in perubahan:
            judul = perubahan["title"]

            if judul is not None:
                modul.title = judul.strip()

        if "description" in perubahan:
            deskripsi = perubahan["description"]

            modul.description = (
                deskripsi.strip()
                if deskripsi
                else None
            )

        if "is_published" in perubahan:
            modul.is_published = perubahan["is_published"]

        try:
            hasil = self._repository.simpan_perubahan(modul)
            self._repository.commit()
            return hasil

        except Exception:
            self._repository.rollback()
            raise

    # =====================================================
    # PUBLIKASIKAN MODUL
    # =====================================================

    def publikasikan_modul(
        self,
        modul_id: int,
        pengguna: User,
    ):

        self._validasi_asisten(pengguna)

        modul = self._repository.ambil_modul_berdasarkan_id(
            modul_id=modul_id,
            asisten_id=pengguna.id,
        )

        if modul is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Modul tidak ditemukan.",
            )

        modul.is_published = True

        try:
            hasil = self._repository.simpan_perubahan(modul)
            self._repository.commit()
            return hasil

        except Exception:
            self._repository.rollback()
            raise

    # =====================================================
    # TARIK PUBLIKASI MODUL
    # =====================================================

    def tarik_publikasi_modul(
        self,
        modul_id: int,
        pengguna: User,
    ):

        self._validasi_asisten(pengguna)

        modul = self._repository.ambil_modul_berdasarkan_id(
            modul_id=modul_id,
            asisten_id=pengguna.id,
        )

        if modul is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Modul tidak ditemukan.",
            )

        modul.is_published = False

        try:
            hasil = self._repository.simpan_perubahan(modul)
            self._repository.commit()
            return hasil

        except Exception:
            self._repository.rollback()
            raise

    # =====================================================
    # HAPUS MODUL
    # =====================================================

    def hapus_modul(
        self,
        modul_id: int,
        pengguna: User,
    ):

        self._validasi_asisten(pengguna)

        modul = self._repository.ambil_modul_berdasarkan_id(
            modul_id=modul_id,
            asisten_id=pengguna.id,
        )

        if modul is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Modul tidak ditemukan.",
            )

        try:
            self._repository.hapus(modul)
            self._repository.commit()

            return {
                "message": "Modul praktikum berhasil dihapus."
            }

        except Exception:
            self._repository.rollback()
            raise
