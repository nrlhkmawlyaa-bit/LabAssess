from sqlalchemy.orm import Session

from app.models.pengguna import User
from app.core.keamanan import pengelola_password


class GantiPasswordService:
    """
    Menangani penggantian password sementara
    menjadi password permanen milik mahasiswa
    maupun asisten laboratorium.
    """

    ROLE_DIIZINKAN = (
        "mahasiswa",
        "asisten_lab",
    )

    def __init__(self, db: Session):
        self._db = db

    def ganti_password(
        self,
        pengguna: User,
        password_baru: str,
    ) -> dict:

        if pengguna.role not in self.ROLE_DIIZINKAN:
            raise ValueError(
                "Role pengguna tidak diizinkan mengganti password sementara."
            )

        if not pengguna.must_change_password:
            raise ValueError(
                "Akun tidak sedang diwajibkan mengganti password."
            )

        if pengelola_password.verifikasi(
            password_baru,
            pengguna.password_hash,
        ):
            raise ValueError(
                "Password baru tidak boleh sama dengan password sementara."
            )

        try:
            pengguna.password_hash = (
                pengelola_password.buat_hash(
                    password_baru
                )
            )

            pengguna.must_change_password = False

            pengguna.temporary_password_expires_at = None

            self._db.commit()
            self._db.refresh(pengguna)

        except Exception:
            self._db.rollback()
            raise

        return {
            "pesan": (
                "Password berhasil diganti. "
                "Silakan masuk ke dashboard."
            ),
            "berhasil": True,
        }