
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.pengguna import User
from app.repositories.modul_mahasiswa_repository import (
    ModulMahasiswaRepository,
)


class ModulMahasiswaService:
    """
    Service untuk mengelola akses modul praktikum mahasiswa.
    """

    def __init__(self, db: Session):
        self._repository = ModulMahasiswaRepository(db)

    def _validasi_mahasiswa(self, mahasiswa: User) -> None:
        if mahasiswa.role != "mahasiswa":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Akses hanya diperbolehkan untuk mahasiswa.",
            )

        if not mahasiswa.is_active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Akun mahasiswa tidak aktif.",
            )

    def ambil_semua_modul(
        self,
        kelas_id: int,
        mahasiswa: User,
    ):
        """
        Mengambil modul yang telah dipublikasikan
        pada kelas yang diikuti mahasiswa.
        """

        self._validasi_mahasiswa(mahasiswa)

        return self._repository.ambil_semua_modul(
            kelas_id=kelas_id,
            mahasiswa_id=mahasiswa.id,
        )

    def ambil_detail_modul(
        self,
        modul_id: int,
        mahasiswa: User,
    ):
        """
        Mengambil detail modul yang boleh diakses mahasiswa.
        """

        self._validasi_mahasiswa(mahasiswa)

        modul = self._repository.ambil_modul_berdasarkan_id(
            modul_id=modul_id,
            mahasiswa_id=mahasiswa.id,
        )

        if modul is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=(
                    "Modul tidak ditemukan, belum dipublikasikan, "
                    "atau kamu tidak memiliki akses."
                ),
            )

        return modul

    def ambil_file_modul(
        self,
        modul_id: int,
        file_id: int,
        mahasiswa: User,
    ):
        """
        Memeriksa hak akses mahasiswa sebelum mengunduh file.
        """

        self._validasi_mahasiswa(mahasiswa)

        file_modul = self._repository.ambil_file_berdasarkan_id(
            file_id=file_id,
            modul_id=modul_id,
            mahasiswa_id=mahasiswa.id,
        )

        if file_modul is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=(
                    "File tidak ditemukan atau kamu tidak "
                    "memiliki akses untuk mengunduhnya."
                ),
            )

        return file_modul
