

from datetime import datetime, timedelta, timezone

from zoneinfo import ZoneInfo

from decimal import Decimal, ROUND_HALF_UP

from random import SystemRandom



from fastapi import HTTPException, status



from app.models.pengguna import User

from app.models.kuis import Quiz

from app.models.soal_kuis import QuizQuestion

from app.models.opsi_kuis import QuizOption

from app.models.pengerjaan_kuis import QuizAttempt

from app.models.jawaban_kuis import QuizAnswer

from app.models.nilai_kuis import QuizGrade
from app.models.kelas_perkuliahan import CourseClass
from app.models.mata_kuliah import Course
from app.models.modul_praktikum import PracticumModule



from app.repositories.kuis_repository import KuisRepository



from app.schemas.kuis import (

    KuisCreate,

    KuisUpdate,

    SoalKuisCreate,

    SoalKuisUpdate,

    JawabanKuisSave,

    PenilaianEsaiRequest,

    NilaiPraktikumResponse,

)





class KuisService:

    """

    Service untuk mengelola Pre-Test dan Post-Test

    pada aplikasi LabAssess.



    Menggunakan prinsip OOP dan Repository Pattern.

    """



    def __init__(self, db):

        self._db = db
        self._repository = KuisRepository(db)

        self._random = SystemRandom()



        # =====================================================
        # VALIDASI ASISTEN
        # =====================================================
    def _validasi_asisten(self, pengguna: User) -> None:

        if pengguna.role != "asisten_lab":

            raise HTTPException(

                status_code=status.HTTP_403_FORBIDDEN,

                detail="Fitur ini hanya untuk asisten laboratorium.",

            )



        if not pengguna.is_active:

            raise HTTPException(

                status_code=status.HTTP_403_FORBIDDEN,

                detail="Akun asisten tidak aktif.",

            )



        # =====================================================
        # VALIDASI MAHASISWA
        # =====================================================
    def _validasi_mahasiswa(self, pengguna: User) -> None:

        if pengguna.role != "mahasiswa":

            raise HTTPException(

                status_code=status.HTTP_403_FORBIDDEN,

                detail="Fitur ini hanya untuk mahasiswa.",

            )



        if not pengguna.is_active:

            raise HTTPException(

                status_code=status.HTTP_403_FORBIDDEN,

                detail="Akun mahasiswa tidak aktif.",

            )



        # =====================================================
        # VALIDASI KEPEMILIKAN KELAS ASISTEN
        # =====================================================
    def _validasi_kelas_asisten(

        self,

        kelas_id: int,

        pengguna: User,

    ) -> None:

        kelas = self._repository.cek_kelas_asisten(

            kelas_id=kelas_id,

            asisten_id=pengguna.id,

        )



        if kelas is None:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail=(

                    "Kelas tidak ditemukan atau bukan "

                    "merupakan kelas yang ditugaskan kepadamu."

                ),

            )



        # =====================================================
        # VALIDASI KEIKUTSERTAAN MAHASISWA
        # =====================================================
    def _validasi_kelas_mahasiswa(

        self,

        kelas_id: int,

        pengguna: User,

    ) -> None:

        kelas = self._repository.cek_kelas_mahasiswa(

            kelas_id=kelas_id,

            mahasiswa_id=pengguna.id,

        )



        if kelas is None:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail=(

                    "Kelas tidak ditemukan atau kamu "

                    "tidak terdaftar pada kelas tersebut."

                ),

            )



        # =====================================================
        # VALIDASI KUIS MILIK ASISTEN
        # =====================================================
    def _ambil_kuis_asisten(

        self,

        kuis_id: int,

        pengguna: User,

    ) -> Quiz:

        kuis = self._repository.ambil_kuis_berdasarkan_id(

            kuis_id=kuis_id,

            asisten_id=pengguna.id,

        )



        if kuis is None:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail="Kuis tidak ditemukan.",

            )



        return kuis



        # =====================================================
        # VALIDASI STATUS KUIS
        # =====================================================
    def _validasi_kuis_belum_diterbitkan(

        self,

        kuis: Quiz,

    ) -> None:

        if kuis.status != "draft":

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail=(

                    "Kuis hanya dapat diubah ketika "

                    "berstatus draft."

                ),

            )



        # =====================================================
        # VALIDASI WAKTU KUIS
        # =====================================================
    def _waktu_sekarang(self) -> datetime:

        """Menghasilkan waktu sekarang dalam UTC."""

        return datetime.now(timezone.utc)



    def _normalisasi_waktu(

        self,

        waktu: datetime,

        zona_default=timezone.utc,

    ) -> datetime:

        """Mengubah datetime menjadi aware UTC secara konsisten.



        Jadwal kuis dari MySQL menggunakan DATETIME tanpa timezone,

        sehingga nilai naive untuk start_at/end_at dianggap sebagai

        waktu lokal Bontang (Asia/Makassar). Timestamp pengerjaan

        dibuat oleh aplikasi dalam UTC, sehingga pemanggil timestamp

        pengerjaan tetap menggunakan default UTC.

        """

        if waktu.tzinfo is None:

            waktu = waktu.replace(tzinfo=zona_default)

        return waktu.astimezone(timezone.utc)



    def _validasi_jadwal_kuis(

        self,

        kuis: Quiz,

    ) -> None:

        sekarang = self._waktu_sekarang()



        zona_bontang = ZoneInfo("Asia/Makassar")

        waktu_mulai = self._normalisasi_waktu(

            kuis.start_at, zona_default=zona_bontang

        )

        waktu_selesai = self._normalisasi_waktu(

            kuis.end_at, zona_default=zona_bontang

        )



        if sekarang < waktu_mulai:

            raise HTTPException(

                status_code=status.HTTP_403_FORBIDDEN,

                detail="Kuis belum memasuki waktu pengerjaan.",

            )



        if sekarang > waktu_selesai:

            raise HTTPException(

                status_code=status.HTTP_403_FORBIDDEN,

                detail="Waktu pengerjaan kuis telah berakhir.",

            )





        # =====================================================
        # MENGAMBIL SEMUA KUIS DALAM KELAS
        # =====================================================
    def ambil_semua_kuis(

        self,

        kelas_id: int,

        pengguna: User,

    ):

        self._validasi_asisten(pengguna)

        self._validasi_kelas_asisten(kelas_id, pengguna)



        return self._repository.ambil_semua_kuis(

            kelas_id=kelas_id,

            asisten_id=pengguna.id,

        )



        # =====================================================
        # MENGAMBIL DETAIL KUIS
        # =====================================================
    def ambil_detail_kuis(

        self,

        kuis_id: int,

        pengguna: User,

    ):

        self._validasi_asisten(pengguna)



        return self._ambil_kuis_asisten(

            kuis_id=kuis_id,

            pengguna=pengguna,

        )



        # =====================================================
        # MEMBUAT KUIS PRE-TEST / POST-TEST
        # =====================================================
    def buat_kuis(

        self,

        data: KuisCreate,

        pengguna: User,

    ):

        self._validasi_asisten(pengguna)



        self._validasi_kelas_asisten(

            kelas_id=data.class_id,

            pengguna=pengguna,

        )



        # Jika module_id diberikan, pastikan modul memang berada di kelas
        # yang sama dan kelas tersebut ditugaskan kepada asisten ini.
        if data.module_id is not None:

            modul = self._repository.ambil_modul_untuk_kelas_asisten(

                modul_id=data.module_id,

                kelas_id=data.class_id,

                asisten_id=pengguna.id,

            )

            if modul is None:

                raise HTTPException(

                    status_code=status.HTTP_404_NOT_FOUND,

                    detail=(

                        "Modul tidak ditemukan, bukan milik kelas ini, "

                        "atau kelas tidak ditugaskan kepadamu."

                    ),

                )


        kuis_duplikat = self._repository.cek_jenis_kuis(

            kelas_id=data.class_id,

            jenis_kuis=data.quiz_type,

            module_id=data.module_id,

        )



        if kuis_duplikat is not None:

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail=(

                    f"{data.quiz_type.replace('_', ' ').title()} "

                    "sudah dibuat pada kelas ini."

                ),

            )



        sekarang = self._waktu_sekarang()



        waktu_mulai = data.start_at

        waktu_selesai = data.end_at



        zona_bontang = ZoneInfo("Asia/Makassar")

        if waktu_mulai.tzinfo is None:

            waktu_mulai = waktu_mulai.replace(tzinfo=zona_bontang)

        else:

            waktu_mulai = waktu_mulai.astimezone(zona_bontang)



        if waktu_selesai.tzinfo is None:

            waktu_selesai = waktu_selesai.replace(tzinfo=zona_bontang)

        else:

            waktu_selesai = waktu_selesai.astimezone(zona_bontang)



        waktu_mulai_utc = self._normalisasi_waktu(

            waktu_mulai, zona_default=zona_bontang

        )

        waktu_selesai_utc = self._normalisasi_waktu(

            waktu_selesai, zona_default=zona_bontang

        )



        if waktu_selesai_utc <= waktu_mulai_utc:

            raise HTTPException(

                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                detail="Waktu selesai harus setelah waktu mulai.",

            )



        if waktu_selesai_utc <= sekarang:

            raise HTTPException(

                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                detail="Waktu selesai kuis harus berada di masa depan.",

            )



        kuis = Quiz(

            class_id=data.class_id,

            module_id=data.module_id,

            created_by=pengguna.id,

            quiz_type=data.quiz_type,

            title=data.title.strip(),

            description=(

                data.description.strip()

                if data.description

                else None

            ),

            start_at=waktu_mulai,

            end_at=waktu_selesai,

            duration_minutes=data.duration_minutes,

            shuffle_questions=data.shuffle_questions,

            shuffle_options=data.shuffle_options,

            status="draft",

        )



        try:

            hasil = self._repository.tambah_kuis(kuis)

            self._repository.commit()

            return hasil



        except Exception:

            self._repository.rollback()

            raise



        # =====================================================
        # MEMPERBARUI KONFIGURASI KUIS
        # =====================================================
    def perbarui_kuis(

        self,

        kuis_id: int,

        data: KuisUpdate,

        pengguna: User,

    ):

        self._validasi_asisten(pengguna)



        kuis = self._ambil_kuis_asisten(

            kuis_id=kuis_id,

            pengguna=pengguna,

        )



        self._validasi_kuis_belum_diterbitkan(kuis)



        perubahan = data.model_dump(exclude_unset=True)



        if "status" in perubahan:

            raise HTTPException(

                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                detail=(

                    "Status kuis harus diubah melalui "

                    "fitur publikasi atau penutupan kuis."

                ),

            )



        for field in (

            "title",

            "description",

            "start_at",

            "end_at",

            "duration_minutes",

            "shuffle_questions",

            "shuffle_options",

        ):

            if field not in perubahan:

                continue



            nilai = perubahan[field]



            if field == "title" and nilai is not None:

                nilai = nilai.strip()



                if not nilai:

                    raise HTTPException(

                        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                        detail="Judul kuis tidak boleh kosong.",

                    )



            if field == "description" and nilai is not None:

                nilai = nilai.strip() or None



            if field in ("start_at", "end_at") and nilai is not None:

                zona_bontang = ZoneInfo("Asia/Makassar")

                if nilai.tzinfo is None:

                    nilai = nilai.replace(tzinfo=zona_bontang)

                else:

                    nilai = nilai.astimezone(zona_bontang)



            setattr(kuis, field, nilai)



        waktu_mulai = self._normalisasi_waktu(

            kuis.start_at,

            zona_default=ZoneInfo("Asia/Makassar"),

        )

        waktu_selesai = self._normalisasi_waktu(

            kuis.end_at,

            zona_default=ZoneInfo("Asia/Makassar"),

        )



        if waktu_selesai <= waktu_mulai:

            raise HTTPException(

                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                detail="Waktu selesai harus setelah waktu mulai.",

            )



        if waktu_selesai <= self._waktu_sekarang():

            raise HTTPException(

                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                detail="Waktu selesai kuis harus berada di masa depan.",

            )



        try:

            hasil = self._repository.simpan_perubahan_kuis(

                kuis

            )

            self._repository.commit()

            return hasil



        except Exception:

            self._repository.rollback()

            raise



        # =====================================================
        # MENGUBAH STATUS PUBLIKASI KUIS
        # =====================================================
    def ubah_status_kuis(

        self,

        kuis_id: int,

        status_baru: str,

        pengguna: User,

    ):

        self._validasi_asisten(pengguna)



        kuis = self._ambil_kuis_asisten(

            kuis_id=kuis_id,

            pengguna=pengguna,

        )



        if status_baru not in ("draft", "published", "closed"):

            raise HTTPException(

                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                detail="Status kuis tidak valid.",

            )



            # Kuis berstatus closed boleh dibuka kembali menjadi published.
            # Validasi jadwal dan keberadaan soal tetap dijalankan di bawah.
        if status_baru == "published":

            if not kuis.questions:

                raise HTTPException(

                    status_code=status.HTTP_409_CONFLICT,

                    detail="Kuis belum memiliki soal.",

                )



            sekarang = self._waktu_sekarang()

            zona_bontang = ZoneInfo("Asia/Makassar")

            waktu_selesai = self._normalisasi_waktu(

                kuis.end_at,

                zona_default=zona_bontang,

            )

            waktu_mulai = self._normalisasi_waktu(

                kuis.start_at,

                zona_default=zona_bontang,

            )



            if waktu_selesai <= sekarang:

                raise HTTPException(

                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                    detail="Jadwal kuis sudah berakhir.",

                )



            if waktu_mulai <= sekarang:

                raise HTTPException(

                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                    detail=(

                        "Kuis harus dipublikasikan sebelum "

                        "waktu mulai pengerjaan."

                    ),

                )



        kuis.status = status_baru



        try:

            hasil = self._repository.simpan_perubahan_kuis(

                kuis

            )

            self._repository.commit()

            return hasil



        except Exception:

            self._repository.rollback()

            raise



        # =====================================================
        # MENGHAPUS KUIS
        # =====================================================
    def hapus_kuis(

        self,

        kuis_id: int,

        pengguna: User,

    ):

        self._validasi_asisten(pengguna)



        kuis = self._ambil_kuis_asisten(

            kuis_id=kuis_id,

            pengguna=pengguna,

        )



        if kuis.attempts:

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail=(

                    "Kuis tidak dapat dihapus karena "

                    "sudah memiliki data pengerjaan mahasiswa."

                ),

            )



        try:

            self._repository.hapus_kuis(kuis)

            self._repository.commit()



            return {

                "message": "Kuis berhasil dihapus."

            }



        except Exception:

            self._repository.rollback()

            raise





        # =====================================================
        # MENGAMBIL SEMUA SOAL DALAM KUIS
        # =====================================================
    def ambil_semua_soal(

        self,

        kuis_id: int,

        pengguna: User,

    ):

        self._validasi_asisten(pengguna)



        kuis = self._ambil_kuis_asisten(

            kuis_id=kuis_id,

            pengguna=pengguna,

        )



        return kuis.questions



        # =====================================================
        # MENAMBAHKAN SOAL
        # =====================================================
    def tambah_soal(

        self,

        kuis_id: int,

        data: SoalKuisCreate,

        pengguna: User,

    ):

        self._validasi_asisten(pengguna)



        kuis = self._ambil_kuis_asisten(

            kuis_id=kuis_id,

            pengguna=pengguna,

        )



        self._validasi_kuis_belum_diterbitkan(kuis)



        nomor_duplikat = self._repository.cek_nomor_soal(

            kuis_id=kuis_id,

            nomor_soal=data.question_order,

        )



        if nomor_duplikat is not None:

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail="Nomor urutan soal sudah digunakan.",

            )



        soal = QuizQuestion(

            quiz_id=kuis_id,

            question_text=data.question_text.strip(),

            question_type=data.question_type,

            question_order=data.question_order,

            points=data.points,

        )



        try:

            soal = self._repository.tambah_soal(soal)



            for data_opsi in data.options:

                opsi = QuizOption(

                    question_id=soal.id,

                    option_text=data_opsi.option_text.strip(),

                    is_correct=data_opsi.is_correct,

                    option_order=data_opsi.option_order,

                )



                self._repository.tambah_opsi(opsi)



            self._repository.commit()



            return self._repository.ambil_soal_berdasarkan_id(

                soal_id=soal.id,

                kuis_id=kuis_id,

            )



        except Exception:

            self._repository.rollback()

            raise



        # =====================================================
        # MEMPERBARUI SOAL
        # =====================================================
    def perbarui_soal(

        self,

        kuis_id: int,

        soal_id: int,

        data: SoalKuisUpdate,

        pengguna: User,

    ):

        self._validasi_asisten(pengguna)



        kuis = self._ambil_kuis_asisten(

            kuis_id=kuis_id,

            pengguna=pengguna,

        )



        self._validasi_kuis_belum_diterbitkan(kuis)



        soal = self._repository.ambil_soal_berdasarkan_id(

            soal_id=soal_id,

            kuis_id=kuis_id,

        )



        if soal is None:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail="Soal tidak ditemukan.",

            )



        perubahan = data.model_dump(exclude_unset=True)



        if "question_order" in perubahan:

            nomor_baru = perubahan["question_order"]



            if nomor_baru is not None:

                nomor_duplikat = self._repository.cek_nomor_soal(

                    kuis_id=kuis_id,

                    nomor_soal=nomor_baru,

                    kecuali_soal_id=soal.id,

                )



                if nomor_duplikat is not None:

                    raise HTTPException(

                        status_code=status.HTTP_409_CONFLICT,

                        detail="Nomor urutan soal sudah digunakan.",

                    )



        for field in (

            "question_text",

            "question_type",

            "question_order",

            "points",

        ):

            if field not in perubahan:

                continue



            nilai = perubahan[field]



            if field == "question_text" and nilai is not None:

                nilai = nilai.strip()



                if not nilai:

                    raise HTTPException(

                        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                        detail="Pertanyaan tidak boleh kosong.",

                    )



            setattr(soal, field, nilai)



        try:

            hasil = self._repository.simpan_perubahan_soal(

                soal

            )

            self._repository.commit()



            return self._repository.ambil_soal_berdasarkan_id(

                soal_id=soal.id,

                kuis_id=kuis_id,

            )



        except Exception:

            self._repository.rollback()

            raise



        # =====================================================
        # MENGELOLA OPSI JAWABAN
        # =====================================================
    def perbarui_opsi_soal(

        self,

        kuis_id: int,

        soal_id: int,

        options: list,

        pengguna: User,

    ):

        self._validasi_asisten(pengguna)



        kuis = self._ambil_kuis_asisten(

            kuis_id=kuis_id,

            pengguna=pengguna,

        )



        self._validasi_kuis_belum_diterbitkan(kuis)



        soal = self._repository.ambil_soal_berdasarkan_id(

            soal_id=soal_id,

            kuis_id=kuis_id,

        )



        if soal is None:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail="Soal tidak ditemukan.",

            )



        if soal.question_type != "multiple_choice":

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail="Opsi hanya dapat diberikan pada soal pilihan ganda.",

            )



        if len(options) < 2:

            raise HTTPException(

                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                detail="Soal pilihan ganda minimal memiliki dua opsi.",

            )



        jumlah_benar = sum(

            1 for opsi in options if opsi.is_correct

        )



        if jumlah_benar != 1:

            raise HTTPException(

                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                detail="Harus terdapat tepat satu jawaban benar.",

            )



        nomor_opsi = [opsi.option_order for opsi in options]



        if len(nomor_opsi) != len(set(nomor_opsi)):

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail="Urutan opsi jawaban tidak boleh duplikat.",

            )



        if any(nomor <= 0 for nomor in nomor_opsi):

            raise HTTPException(

                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                detail="Urutan opsi harus lebih besar dari nol.",

            )



        try:

            opsi_lama = self._repository.ambil_opsi_soal(

                soal_id=soal_id

            )



            for opsi in opsi_lama:

                self._repository.hapus_opsi(opsi)



            for data_opsi in options:

                opsi_baru = QuizOption(

                    question_id=soal_id,

                    option_text=data_opsi.option_text.strip(),

                    is_correct=data_opsi.is_correct,

                    option_order=data_opsi.option_order,

                )



                self._repository.tambah_opsi(opsi_baru)



            self._repository.commit()



            return self._repository.ambil_soal_berdasarkan_id(

                soal_id=soal_id,

                kuis_id=kuis_id,

            )



        except Exception:

            self._repository.rollback()

            raise



        # =====================================================
        # MENGHAPUS SOAL
        # =====================================================
    def hapus_soal(

        self,

        kuis_id: int,

        soal_id: int,

        pengguna: User,

    ):

        self._validasi_asisten(pengguna)



        kuis = self._ambil_kuis_asisten(

            kuis_id=kuis_id,

            pengguna=pengguna,

        )



        self._validasi_kuis_belum_diterbitkan(kuis)



        soal = self._repository.ambil_soal_berdasarkan_id(

            soal_id=soal_id,

            kuis_id=kuis_id,

        )



        if soal is None:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail="Soal tidak ditemukan.",

            )



        if soal.answers:

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail=(

                    "Soal tidak dapat dihapus karena "

                    "sudah memiliki jawaban mahasiswa."

                ),

            )



        try:

            self._repository.hapus_soal(soal)

            self._repository.commit()



            return {

                "message": "Soal berhasil dihapus."

            }



        except Exception:

            self._repository.rollback()

            raise





        # =====================================================
        # MENGAMBIL DAFTAR KUIS MAHASISWA
        # =====================================================
    def ambil_kuis_mahasiswa(

        self,

        kelas_id: int,

        pengguna: User,

    ):

        self._validasi_mahasiswa(pengguna)



        self._validasi_kelas_mahasiswa(

            kelas_id=kelas_id,

            pengguna=pengguna,

        )



        return self._repository.ambil_kuis_mahasiswa(

            kelas_id=kelas_id,

            mahasiswa_id=pengguna.id,

        )



        # =====================================================
        # MENGAMBIL DETAIL KUIS MAHASISWA
        # =====================================================
    def ambil_detail_kuis_mahasiswa(

        self,

        kuis_id: int,

        pengguna: User,

    ):

        self._validasi_mahasiswa(pengguna)



        kuis = self._repository.ambil_kuis_mahasiswa_berdasarkan_id(

            kuis_id=kuis_id,

            mahasiswa_id=pengguna.id,

        )



        if kuis is None:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail="Kuis tidak ditemukan atau tidak tersedia.",

            )



        return kuis



        # =====================================================
        # MEMULAI PENGERJAAN KUIS
        # =====================================================
    def mulai_kuis(

        self,

        kuis_id: int,

        pengguna: User,

    ):

        self._validasi_mahasiswa(pengguna)



        kuis = self.ambil_detail_kuis_mahasiswa(

            kuis_id=kuis_id,

            pengguna=pengguna,

        )



        sekarang = self._waktu_sekarang()



        zona_bontang = ZoneInfo("Asia/Makassar")

        waktu_mulai = self._normalisasi_waktu(

            kuis.start_at, zona_default=zona_bontang

        )

        waktu_selesai = self._normalisasi_waktu(

            kuis.end_at, zona_default=zona_bontang

        )



        if sekarang < waktu_mulai:

            raise HTTPException(

                status_code=status.HTTP_403_FORBIDDEN,

                detail="Kuis belum dimulai.",

            )



        if sekarang >= waktu_selesai:

            raise HTTPException(

                status_code=status.HTTP_403_FORBIDDEN,

                detail="Waktu kuis telah berakhir.",

            )



        pengerjaan_lama = self._repository.ambil_pengerjaan(

            kuis_id=kuis.id,

            mahasiswa_id=pengguna.id,

        )



        if pengerjaan_lama is not None:

            if pengerjaan_lama.status == "submitted":

                raise HTTPException(

                    status_code=status.HTTP_409_CONFLICT,

                    detail="Kuis ini sudah pernah kamu kumpulkan.",

                )



            if self._waktu_sekarang() >= self._normalisasi_waktu(

                pengerjaan_lama.deadline_at

            ):

                return self._kumpulkan_otomatis(

                    pengerjaan=pengerjaan_lama,

                )



            return self._buat_respons_pengerjaan(

                pengerjaan=pengerjaan_lama,

                kuis=kuis,

            )



        deadline = min(

            sekarang + timedelta(minutes=kuis.duration_minutes),

            waktu_selesai,

        )



        soal = list(kuis.questions)



        if not soal:

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail="Kuis belum memiliki soal.",

            )



        urutan_soal = [

            item.id for item in soal

        ]



        if kuis.shuffle_questions:

            self._random.shuffle(urutan_soal)



        urutan_opsi = {}



        for item in soal:

            opsi_ids = [

                opsi.id for opsi in item.options

            ]



            if kuis.shuffle_options:

                self._random.shuffle(opsi_ids)



            urutan_opsi[str(item.id)] = opsi_ids



        pengerjaan = QuizAttempt(

            quiz_id=kuis.id,

            student_id=pengguna.id,

            started_at=sekarang,

            deadline_at=deadline,

            status="in_progress",

            question_order_snapshot=urutan_soal,

            option_order_snapshot=urutan_opsi,

        )



        try:

            self._repository.tambah_pengerjaan(

                pengerjaan

            )



            self._repository.commit()



            return self._buat_respons_pengerjaan(

                pengerjaan=pengerjaan,

                kuis=kuis,

            )



        except Exception:

            self._repository.rollback()

            raise



        # =====================================================
        # MEMBENTUK RESPONS PENGERJAAN
        # =====================================================
    def _buat_respons_pengerjaan(

        self,

        pengerjaan: QuizAttempt,

        kuis: Quiz,

    ):

        from app.schemas.kuis import (

            PengerjaanKuisMahasiswaResponse,

        )



        soal_map = {

            item.id: item

            for item in kuis.questions

        }



        urutan_soal = pengerjaan.question_order_snapshot



        urutan_opsi = pengerjaan.option_order_snapshot



        daftar_soal = []



        for soal_id in urutan_soal:

            soal = soal_map.get(soal_id)



            if soal is None:

                continue



            opsi_map = {

                opsi.id: opsi

                for opsi in soal.options

            }



            opsi_tersusun = []



            for opsi_id in urutan_opsi.get(str(soal.id), []):

                opsi = opsi_map.get(opsi_id)



                if opsi is None:

                    continue



                opsi_tersusun.append({

                    "id": opsi.id,

                    "option_text": opsi.option_text,

                    "option_order": opsi.option_order,

                })



            daftar_soal.append({

                "id": soal.id,

                "question_text": soal.question_text,

                "question_type": soal.question_type,

                "question_order": soal.question_order,

                "options": opsi_tersusun,

            })



        return PengerjaanKuisMahasiswaResponse(

            attempt_id=pengerjaan.id,

            quiz_id=kuis.id,

            title=kuis.title,

            quiz_type=kuis.quiz_type,

            duration_minutes=kuis.duration_minutes,

            started_at=pengerjaan.started_at,

            deadline_at=pengerjaan.deadline_at,

            status=pengerjaan.status,

            questions=daftar_soal,

        )



        # =====================================================
        # MENYIMPAN JAWABAN MAHASISWA
        # =====================================================
    def simpan_jawaban(

        self,

        pengerjaan_id: int,

        data: JawabanKuisSave,

        pengguna: User,

    ):

        self._validasi_mahasiswa(pengguna)



        pengerjaan = self._repository.ambil_pengerjaan_berdasarkan_id(

            pengerjaan_id=pengerjaan_id,

            mahasiswa_id=pengguna.id,

        )



        if pengerjaan is None:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail="Data pengerjaan tidak ditemukan.",

            )



        if pengerjaan.status != "in_progress":

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail="Pengerjaan kuis sudah ditutup.",

            )



        if self._waktu_sekarang() >= self._normalisasi_waktu(

            pengerjaan.deadline_at

        ):

            return self._kumpulkan_otomatis(

                pengerjaan=pengerjaan,

            )



        soal = self._repository.ambil_soal_berdasarkan_id(

            soal_id=data.question_id,

            kuis_id=pengerjaan.quiz_id,

        )



        if soal is None:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail="Soal tidak ditemukan dalam kuis ini.",

            )



        if soal.question_type == "multiple_choice":

            if data.selected_option_id is None:

                raise HTTPException(

                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                    detail="Pilih salah satu opsi jawaban.",

                )



            opsi_valid = any(

                opsi.id == data.selected_option_id

                for opsi in soal.options

            )



            if not opsi_valid:

                raise HTTPException(

                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                    detail="Opsi jawaban tidak sesuai dengan soal.",

                )



            essay_answer = None



        else:

            if data.selected_option_id is not None:

                raise HTTPException(

                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                    detail="Soal esai tidak menerima opsi pilihan ganda.",

                )



            essay_answer = (

                data.essay_answer.strip()

                if data.essay_answer

                else None

            )



            if not essay_answer:

                raise HTTPException(

                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,

                    detail="Jawaban esai tidak boleh kosong.",

                )



        jawaban = self._repository.ambil_jawaban(

            pengerjaan_id=pengerjaan.id,

            soal_id=soal.id,

        )



        try:

            if jawaban is None:

                jawaban = QuizAnswer(

                    attempt_id=pengerjaan.id,

                    question_id=soal.id,

                    selected_option_id=data.selected_option_id,

                    essay_answer=essay_answer,

                )



                self._repository.tambah_jawaban(

                    jawaban

                )



            else:

                jawaban.selected_option_id = data.selected_option_id

                jawaban.essay_answer = essay_answer



                self._repository.simpan_perubahan_jawaban(

                    jawaban

                )



            self._repository.commit()



            return jawaban



        except Exception:

            self._repository.rollback()

            raise



        # =====================================================
        # PENGUMPULAN OTOMATIS KETIKA WAKTU HABIS
        # =====================================================
    def _kumpulkan_otomatis(

        self,

        pengerjaan: QuizAttempt,

    ):

        pengerjaan.status = "submitted"

        pengerjaan.submitted_at = pengerjaan.deadline_at



        try:

            hasil = self._repository.simpan_perubahan_pengerjaan(

                pengerjaan

            )



            self._hitung_nilai_otomatis(

                pengerjaan=pengerjaan,

            )



            self._repository.commit()



            return hasil



        except Exception:

            self._repository.rollback()

            raise



        # =====================================================
        # MENGUMPULKAN KUIS MAHASISWA
        # =====================================================
    def kumpulkan_kuis(

        self,

        pengerjaan_id: int,

        pengguna: User,

    ):

        self._validasi_mahasiswa(pengguna)



        pengerjaan = self._repository.ambil_pengerjaan_berdasarkan_id(

            pengerjaan_id=pengerjaan_id,

            mahasiswa_id=pengguna.id,

        )



        if pengerjaan is None:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail="Data pengerjaan tidak ditemukan.",

            )



        if pengerjaan.status == "submitted":

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail="Kuis sudah dikumpulkan.",

            )



        sekarang = self._waktu_sekarang()



        pengerjaan.status = "submitted"

        deadline_utc = self._normalisasi_waktu(

            pengerjaan.deadline_at

        )

        pengerjaan.submitted_at = min(

            sekarang,

            deadline_utc,

        )



        try:

            self._repository.simpan_perubahan_pengerjaan(

                pengerjaan

            )



            nilai = self._hitung_nilai_otomatis(

                pengerjaan=pengerjaan,

            )



            self._repository.commit()



                # Nilai hanya boleh ditampilkan kepada mahasiswa setelah
                # dipublikasikan oleh asisten laboratorium.
            nilai_dipublikasikan = (

                nilai is not None

                and nilai.grading_status == "published"

            )



            return {

                "attempt_id": pengerjaan.id,

                "submitted_at": pengerjaan.submitted_at,

                "status": pengerjaan.status,

                "status_penilaian": (

                    nilai.grading_status if nilai is not None else "pending_review"

                ),

                "nilai_akhir": (

                    nilai.final_score if nilai_dipublikasikan else None

                ),

                "message": "Kuis berhasil dikumpulkan.",

            }



        except Exception:

            self._repository.rollback()

            raise





        # =====================================================
        # MENGHITUNG NILAI OTOMATIS PILIHAN GANDA
        # =====================================================
    def _hitung_nilai_otomatis(

        self,

        pengerjaan: QuizAttempt,

    ):

        jawaban_list = self._repository.ambil_semua_jawaban(

            pengerjaan_id=pengerjaan.id

        )



            # Menggunakan relasi pengerjaan ke kuis
        kuis = pengerjaan.quiz



        if kuis is None:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail="Data kuis tidak ditemukan.",

            )



        total_bobot = sum(

            (soal.points for soal in kuis.questions),

            Decimal("0.00"),

        )



        if total_bobot <= 0:

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail="Total bobot soal harus lebih besar dari nol.",

            )



        jawaban_map = {

            jawaban.question_id: jawaban

            for jawaban in jawaban_list

        }



        total_poin = Decimal("0.00")

        masih_menunggu_esai = False



        for soal in kuis.questions:

            jawaban = jawaban_map.get(soal.id)



                # Soal belum dijawab
            if jawaban is None:

                continue



            if soal.question_type == "multiple_choice":

                opsi = jawaban.selected_option



                if opsi is not None and opsi.is_correct:

                    jawaban.awarded_points = soal.points

                else:

                    jawaban.awarded_points = Decimal("0.00")



                total_poin += jawaban.awarded_points



            elif soal.question_type == "essay":

                    # Esai kosong tidak membutuhkan pemeriksaan.
                if not jawaban.essay_answer or not jawaban.essay_answer.strip():

                    jawaban.awarded_points = Decimal("0.00")

                    continue



                    # Esai yang sudah dijawab harus diperiksa.
                if jawaban.awarded_points is None:

                    masih_menunggu_esai = True

                else:

                    total_poin += jawaban.awarded_points



        if masih_menunggu_esai:

            status_nilai = "pending_review"

            nilai_akhir = None

            poin_akhir = None



        else:

            status_nilai = "graded"

            poin_akhir = total_poin



            nilai_akhir = (

                (total_poin / total_bobot) * Decimal("100")

            ).quantize(

                Decimal("0.01"),

                rounding=ROUND_HALF_UP,

            )



        nilai = self._repository.ambil_nilai(

            pengerjaan_id=pengerjaan.id

        )



        if nilai is None:

            nilai = QuizGrade(

                attempt_id=pengerjaan.id,

                total_possible_points=total_bobot,

                earned_points=poin_akhir,

                final_score=nilai_akhir,

                grading_status=status_nilai,

            )



            self._repository.tambah_nilai(nilai)



        else:

            nilai.total_possible_points = total_bobot

            nilai.earned_points = poin_akhir

            nilai.final_score = nilai_akhir

            nilai.grading_status = status_nilai

            nilai.published_at = None



            self._repository.simpan_perubahan_nilai(nilai)



        return nilai





    def nilai_esai(

        self,

        kuis_id: int,

        pengerjaan_id: int,

        jawaban_id: int,

        data: PenilaianEsaiRequest,

        asisten: User,

    ):

        self._validasi_asisten(asisten)



            # Pastikan kuis merupakan milik kelas yang ditangani asisten.
        kuis = self._ambil_kuis_asisten(

            kuis_id=kuis_id,

            pengguna=asisten,

        )



        pengerjaan = self._repository.ambil_pengerjaan_berdasarkan_id(

            pengerjaan_id=pengerjaan_id,

        )



        if pengerjaan is None or pengerjaan.quiz_id != kuis.id:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail="Data pengerjaan kuis tidak ditemukan.",

            )



        if pengerjaan.status != "submitted":

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail="Penilaian hanya dapat dilakukan setelah kuis dikumpulkan.",

            )



        nilai = self._repository.ambil_nilai(

            pengerjaan_id=pengerjaan.id

        )



        if nilai is not None and nilai.grading_status == "published":

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail="Nilai sudah dipublikasikan dan tidak dapat diubah.",

            )



        jawaban = self._repository.ambil_jawaban(

            pengerjaan_id=pengerjaan.id,

            soal_id=jawaban_id,

        )



        if jawaban is None:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail="Jawaban mahasiswa tidak ditemukan.",

            )



        soal = jawaban.question



        if soal.question_type != "essay":

            raise HTTPException(

                status_code=status.HTTP_400_BAD_REQUEST,

                detail="Jawaban ini bukan jawaban esai.",

            )



        if not jawaban.essay_answer or not jawaban.essay_answer.strip():

            raise HTTPException(

                status_code=status.HTTP_400_BAD_REQUEST,

                detail="Jawaban esai kosong tidak perlu dinilai.",

            )



        if data.awarded_points > soal.points:

            raise HTTPException(

                status_code=status.HTTP_400_BAD_REQUEST,

                detail=f"Nilai tidak boleh melebihi bobot soal ({soal.points}).",

            )



        try:

            jawaban.awarded_points = data.awarded_points

            jawaban.graded_by = asisten.id

            jawaban.graded_at = self._waktu_sekarang()

            jawaban.feedback = data.feedback



            self._repository.simpan_perubahan_jawaban(jawaban)



            nilai = self._hitung_nilai_otomatis(pengerjaan)



            self._repository.commit()



            return {

                "message": "Penilaian esai berhasil disimpan.",

                "jawaban_id": jawaban.id,

                "poin_diperoleh": jawaban.awarded_points,

                "nilai_kuis": nilai.final_score,

                "status_penilaian": nilai.grading_status,

            }



        except Exception:

            self._repository.rollback()

            raise





    def reset_pengerjaan_mahasiswa(

        self,

        kuis_id: int,

        mahasiswa_id: int,

        asisten: User,

    ):

        """Menghapus riwayat pengerjaan satu mahasiswa pada satu kuis."""

        self._validasi_asisten(asisten)

        kuis = self._ambil_kuis_asisten(

            kuis_id=kuis_id,

            pengguna=asisten,

        )



        kelas = self._repository.cek_kelas_mahasiswa(

            kelas_id=kuis.class_id,

            mahasiswa_id=mahasiswa_id,

        )

        if kelas is None:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail="Mahasiswa tidak terdaftar pada kelas kuis ini.",

            )



        pengerjaan = self._repository.ambil_pengerjaan(

            kuis_id=kuis.id,

            mahasiswa_id=mahasiswa_id,

        )

        if pengerjaan is None:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail="Mahasiswa belum memiliki riwayat pengerjaan kuis ini.",

            )



        try:

            self._repository.hapus_pengerjaan(pengerjaan)

            self._repository.commit()

            return {

                "message": "Riwayat pengerjaan mahasiswa berhasil direset.",

                "quiz_id": kuis.id,

                "student_id": mahasiswa_id,

            }

        except Exception:

            self._repository.rollback()

            raise



    def publikasikan_nilai(

        self,

        kuis_id: int,

        pengerjaan_id: int,

        asisten: User,

    ):

        self._validasi_asisten(asisten)



        kuis = self._ambil_kuis_asisten(

            kuis_id=kuis_id,

            pengguna=asisten,

        )



        pengerjaan = self._repository.ambil_pengerjaan_berdasarkan_id(

            pengerjaan_id=pengerjaan_id,

        )



        if pengerjaan is None or pengerjaan.quiz_id != kuis.id:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail="Data pengerjaan kuis tidak ditemukan.",

            )



        if pengerjaan.status != "submitted":

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail="Kuis belum dikumpulkan oleh mahasiswa.",

            )



        nilai = self._repository.ambil_nilai(

            pengerjaan_id=pengerjaan.id

        )



        if nilai is None:

            raise HTTPException(

                status_code=status.HTTP_404_NOT_FOUND,

                detail="Data nilai kuis belum tersedia.",

            )



        if nilai.grading_status == "pending_review":

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail="Masih ada jawaban esai yang belum dinilai.",

            )



        if nilai.grading_status == "published":

            raise HTTPException(

                status_code=status.HTTP_409_CONFLICT,

                detail="Nilai sudah dipublikasikan sebelumnya.",

            )



        try:

            nilai.grading_status = "published"

            nilai.published_at = self._waktu_sekarang()



            self._repository.simpan_perubahan_nilai(nilai)

            self._repository.commit()



            return {

                "message": "Nilai kuis berhasil dipublikasikan.",

                "pengerjaan_id": pengerjaan.id,

                "nilai_akhir": nilai.final_score,

                "status_penilaian": nilai.grading_status,

                "published_at": nilai.published_at,

            }



        except Exception:

            self._repository.rollback()

            raise





    def ambil_ringkasan_nilai_praktikum(

        self,

        kelas_id: int,

        mahasiswa: User,

    ) -> NilaiPraktikumResponse:

        self._validasi_mahasiswa(mahasiswa)

        self._validasi_kelas_mahasiswa(

            kelas_id=kelas_id,

            mahasiswa_id=mahasiswa.id,

        )



        hasil_kuis = {}



        for jenis in ("pre_test", "post_test"):

            kuis = self._repository.cek_jenis_kuis(

                kelas_id=kelas_id,

                jenis_kuis=jenis,

            )



            if kuis is None:

                hasil_kuis[jenis] = None

                continue



            pengerjaan = self._repository.ambil_pengerjaan(

                kuis_id=kuis.id,

                mahasiswa_id=mahasiswa.id,

            )



            if pengerjaan is None or pengerjaan.status != "submitted":

                hasil_kuis[jenis] = None

                continue



            nilai = self._repository.ambil_nilai(

                pengerjaan_id=pengerjaan.id,

            )



            hasil_kuis[jenis] = nilai



        nilai_pre = hasil_kuis["pre_test"]

        nilai_post = hasil_kuis["post_test"]



        skor_pre = None

        skor_post = None



        if (

            nilai_pre is not None

            and nilai_pre.grading_status == "published"

        ):

            skor_pre = nilai_pre.final_score



        if (

            nilai_post is not None

            and nilai_post.grading_status == "published"

        ):

            skor_post = nilai_post.final_score



        kedua_kuis_selesai = (

            nilai_pre is not None

            and nilai_post is not None

        )



        kedua_nilai_dipublikasikan = (

            skor_pre is not None

            and skor_post is not None

        )



        if kedua_nilai_dipublikasikan:

            nilai_akhir = (

                (skor_pre + skor_post) / Decimal("2")

            ).quantize(

                Decimal("0.01"),

                rounding=ROUND_HALF_UP,

            )



            grading_status = "completed"

            is_complete = True



        elif kedua_kuis_selesai:

            nilai_akhir = None

            grading_status = "pending_review"

            is_complete = False



        else:

            nilai_akhir = None

            grading_status = "incomplete"

            is_complete = False



        return NilaiPraktikumResponse(

            class_id=kelas_id,

            student_id=mahasiswa.id,

            pre_test_score=skor_pre,

            post_test_score=skor_post,

            final_score=nilai_akhir,

            is_complete=is_complete,

            grading_status=grading_status,

        )


    # =====================================================
    # RIWAYAT NILAI MAHASISWA
    # =====================================================

    def ambil_riwayat_nilai_mahasiswa(
        self,
        mahasiswa: User,
    ) -> list[dict]:
        """Mengambil riwayat kuis milik mahasiswa yang sedang login."""

        self._validasi_mahasiswa(mahasiswa)

        daftar_pengerjaan = (
            self._repository.ambil_riwayat_nilai_mahasiswa(
                mahasiswa_id=mahasiswa.id,
            )
        )

        hasil = []

        for pengerjaan in daftar_pengerjaan:
            kuis = pengerjaan.quiz
            nilai = pengerjaan.grade

            dipublikasikan = (
                nilai is not None
                and nilai.grading_status == "published"
            )

            # Ambil konteks kelas, mata kuliah, dan modul untuk pengelompokan
            # riwayat di Dashboard Mahasiswa. Data relasi dibaca saja.
            kelas = self._db.get(CourseClass, kuis.class_id)
            mata_kuliah = (
                self._db.get(Course, kelas.course_id)
                if kelas is not None
                else None
            )
            modul = (
                self._db.get(PracticumModule, kuis.module_id)
                if kuis.module_id is not None
                else None
            )

            hasil.append({
                "attempt_id": pengerjaan.id,
                "quiz_id": kuis.id,
                "judul_kuis": kuis.title,
                "jenis_kuis": kuis.quiz_type,
                "class_id": kuis.class_id,
                "class_code": kelas.class_code if kelas is not None else None,
                "course_id": kelas.course_id if kelas is not None else None,
                "course_name": mata_kuliah.name if mata_kuliah is not None else None,
                "course_code": mata_kuliah.code if mata_kuliah is not None else None,
                "module_id": kuis.module_id,
                "module_number": modul.module_number if modul is not None else None,
                "module_title": modul.title if modul is not None else None,
                "submitted_at": pengerjaan.submitted_at,
                "status_pengerjaan": pengerjaan.status,
                "status_penilaian": (
                    nilai.grading_status
                    if nilai is not None
                    else "pending_review"
                ),
                "nilai_akhir": (
                    nilai.final_score if dipublikasikan else None
                ),
                "published_at": (
                    nilai.published_at if dipublikasikan else None
                ),
            })

        return hasil

    # =====================================================
    # DAFTAR NILAI MAHASISWA UNTUK ASISTEN
    # =====================================================

    def ambil_daftar_pengerjaan_asisten(
        self,
        kuis_id: int,
        asisten: User,
    ) -> list[dict]:
        """Mengambil daftar pengerjaan mahasiswa pada kuis milik asisten."""

        self._validasi_asisten(asisten)
        kuis = self._ambil_kuis_asisten(
            kuis_id=kuis_id,
            pengguna=asisten,
        )

        daftar_pengerjaan = self._repository.ambil_semua_pengerjaan(
            kuis_id=kuis.id,
        )

        hasil = []

        for pengerjaan in daftar_pengerjaan:
            mahasiswa = pengerjaan.student
            nilai = pengerjaan.grade

            hasil.append({
                "attempt_id": pengerjaan.id,
                "student_id": mahasiswa.id,
                "nama_mahasiswa": mahasiswa.full_name,
                "nim": mahasiswa.nim,
                "quiz_id": kuis.id,
                "judul_kuis": kuis.title,
                "jenis_kuis": kuis.quiz_type,
                "status_pengerjaan": pengerjaan.status,
                "submitted_at": pengerjaan.submitted_at,
                "status_penilaian": (
                    nilai.grading_status
                    if nilai is not None
                    else (
                        "belum_dinilai"
                        if pengerjaan.status == "submitted"
                        else "belum_dikumpulkan"
                    )
                ),
                "nilai_akhir": (
                    nilai.final_score if nilai is not None else None
                ),
                "published_at": (
                    nilai.published_at if nilai is not None else None
                ),
            })

        return hasil

    # =====================================================
    # DETAIL PENGERJAAN MAHASISWA UNTUK ASISTEN
    # =====================================================

    def ambil_detail_pengerjaan_asisten(
        self,
        kuis_id: int,
        pengerjaan_id: int,
        asisten: User,
    ) -> dict:
        """Mengambil jawaban mahasiswa untuk diperiksa oleh asisten."""

        self._validasi_asisten(asisten)
        kuis = self._ambil_kuis_asisten(
            kuis_id=kuis_id,
            pengguna=asisten,
        )

        pengerjaan = self._repository.ambil_pengerjaan_berdasarkan_id(
            pengerjaan_id=pengerjaan_id,
        )

        if pengerjaan is None or pengerjaan.quiz_id != kuis.id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Data pengerjaan kuis tidak ditemukan.",
            )

        daftar_jawaban = self._repository.ambil_semua_jawaban(
            pengerjaan_id=pengerjaan.id,
        )

        jawaban_hasil = []

        for jawaban in daftar_jawaban:
            soal = jawaban.question
            opsi_dipilih = jawaban.selected_option

            jawaban_hasil.append({
                "answer_id": jawaban.id,
                "question_id": soal.id,
                "question_text": soal.question_text,
                "question_type": soal.question_type,
                "question_order": soal.question_order,
                "total_points": soal.points,
                "selected_option_id": jawaban.selected_option_id,
                "selected_option_text": (
                    opsi_dipilih.option_text
                    if opsi_dipilih is not None
                    else None
                ),
                "essay_answer": jawaban.essay_answer,
                "awarded_points": jawaban.awarded_points,
                "feedback": jawaban.feedback,
                "graded_at": jawaban.graded_at,
                "correct_options": [
                    {
                        "id": opsi.id,
                        "option_text": opsi.option_text,
                    }
                    for opsi in soal.options
                    if opsi.is_correct
                ] if soal.question_type == "multiple_choice" else [],
            })

        mahasiswa = pengerjaan.student
        nilai = pengerjaan.grade

        return {
            "attempt_id": pengerjaan.id,
            "quiz_id": kuis.id,
            "judul_kuis": kuis.title,
            "jenis_kuis": kuis.quiz_type,
            "student_id": mahasiswa.id,
            "nama_mahasiswa": mahasiswa.full_name,
            "nim": mahasiswa.nim,
            "status_pengerjaan": pengerjaan.status,
            "started_at": pengerjaan.started_at,
            "submitted_at": pengerjaan.submitted_at,
            "status_penilaian": (
                nilai.grading_status if nilai is not None else "belum_dinilai"
            ),
            "total_possible_points": (
                nilai.total_possible_points if nilai is not None else None
            ),
            "earned_points": (
                nilai.earned_points if nilai is not None else None
            ),
            "nilai_akhir": (
                nilai.final_score if nilai is not None else None
            ),
            "published_at": (
                nilai.published_at if nilai is not None else None
            ),
            "answers": jawaban_hasil,
        }
