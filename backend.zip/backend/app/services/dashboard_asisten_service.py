
from fastapi import HTTPException, status

from app.domain.asisten_lab import AsistenLabUser
from app.models.pengguna import User

from app.repositories.dashboard_asisten_repository import (
    DashboardAsistenRepository,
)

from app.schemas.dashboard_asisten import (
    DashboardAsistenResponse,
    KelasDashboardAsistenResponse,
)

from app.schemas.detail_kelas_asisten import (
    DetailKelasAsistenResponse,
    MahasiswaDetailKelasResponse,
)


class DashboardAsistenService:
    """
    Service untuk mengelola dashboard dan detail kelas
    asisten laboratorium.
    """

    def __init__(self, db):
        self._repository = DashboardAsistenRepository(db)

    def ambil_ringkasan(
        self,
        pengguna: User,
    ) -> DashboardAsistenResponse:

        if pengguna.role != "asisten_lab":
            raise PermissionError(
                "Dashboard ini hanya untuk asisten laboratorium."
            )

        domain_asisten = AsistenLabUser(
            id_pengguna=pengguna.id,
            nama_lengkap=pengguna.full_name,
            aktif=pengguna.is_active,
        )

        if not domain_asisten.dapat_masuk():
            raise PermissionError(
                "Akun asisten tidak aktif."
            )

        kelas_list = self._repository.ambil_kelas_asisten(
            domain_asisten.id_pengguna
        )

        daftar_kelas = []
        seluruh_mahasiswa = set()

        for kelas in kelas_list:
            mahasiswa = kelas.students

            for item in mahasiswa:
                seluruh_mahasiswa.add(item.id)

            daftar_kelas.append(
                KelasDashboardAsistenResponse(
                    id=kelas.id,
                    kode_kelas=kelas.class_code,
                    kode_mata_kuliah=kelas.course.code,
                    nama_mata_kuliah=kelas.course.name,
                    tahun_akademik=(
                        kelas.academic_period.academic_year
                    ),
                    semester=kelas.academic_period.semester,
                    is_active=kelas.is_active,
                    jumlah_mahasiswa=len(mahasiswa),
                )
            )

        total_kelas_aktif = sum(
            1 for kelas in kelas_list if kelas.is_active
        )

        return DashboardAsistenResponse(
            nama_asisten=pengguna.full_name,
            total_kelas=len(kelas_list),
            total_kelas_aktif=total_kelas_aktif,
            total_mahasiswa=len(seluruh_mahasiswa),
            daftar_kelas=daftar_kelas,
        )

    def ambil_detail_kelas(
        self,
        kelas_id: int,
        pengguna: User,
    ) -> DetailKelasAsistenResponse:
        """
        Mengambil detail kelas beserta mahasiswa
        yang terdaftar di dalam kelas tersebut.

        Asisten hanya dapat melihat kelas yang
        ditugaskan oleh admin kepadanya.
        """

        if pengguna.role != "asisten_lab":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Fitur ini hanya untuk asisten laboratorium.",
            )

        domain_asisten = AsistenLabUser(
            id_pengguna=pengguna.id,
            nama_lengkap=pengguna.full_name,
            aktif=pengguna.is_active,
        )

        if not domain_asisten.dapat_masuk():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Akun asisten tidak aktif.",
            )

        kelas = self._repository.ambil_detail_kelas_asisten(
            kelas_id=kelas_id,
            asisten_id=pengguna.id,
        )

        if kelas is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=(
                    "Kelas tidak ditemukan atau bukan "
                    "merupakan kelas yang ditugaskan kepadamu."
                ),
            )

        daftar_mahasiswa = [
            MahasiswaDetailKelasResponse(
                id=mahasiswa.id,
                nama_lengkap=mahasiswa.full_name,
                nim=mahasiswa.nim,
                program_studi=(
                    mahasiswa.study_program.name
                    if mahasiswa.study_program
                    else None
                ),
            )
            for mahasiswa in kelas.students
        ]

        return DetailKelasAsistenResponse(
            id=kelas.id,
            kode_kelas=kelas.class_code,
            kode_mata_kuliah=kelas.course.code,
            nama_mata_kuliah=kelas.course.name,
            sks=kelas.course.credits,
            tahun_akademik=(
                kelas.academic_period.academic_year
            ),
            semester=kelas.academic_period.semester,
            is_active=kelas.is_active,
            total_mahasiswa=len(daftar_mahasiswa),
            daftar_mahasiswa=daftar_mahasiswa,
        )
