import re
import uuid

from pathlib import Path

from fastapi import HTTPException, UploadFile, status

from app.models.pengguna import User
from app.models.file_modul_praktikum import PracticumModuleFile

from app.repositories.file_modul_praktikum_repository import (
    FileModulPraktikumRepository,
)

from app.services.modul_praktikum_service import (
    ModulPraktikumService,
)


class FileModulPraktikumService:
    """
    Service untuk mengelola file lampiran modul praktikum.

    Fitur:
    - Upload beberapa file sekaligus.
    - Menampilkan daftar lampiran.
    - Mengambil detail lampiran.
    - Menghapus lampiran.
    - Memvalidasi hak akses asisten.
    """

    MAKSIMAL_UKURAN_FILE = 50 * 1024 * 1024
    MAKSIMAL_JUMLAH_FILE = 10
    UKURAN_CHUNK = 1024 * 1024

    DIREKTORI_STORAGE = (
        Path(__file__).resolve().parents[2]
        / "storage"
        / "modul_praktikum"
    )

    EKSTENSI_DILARANG = {
        ".exe",
        ".dll",
        ".bat",
        ".cmd",
        ".com",
        ".msi",
        ".ps1",
        ".psm1",
        ".sh",
        ".bash",
        ".zsh",
        ".php",
        ".phtml",
        ".js",
        ".mjs",
        ".cjs",
        ".vbs",
        ".vbe",
        ".wsf",
        ".hta",
        ".jar",
        ".scr",
        ".reg",
        ".svg",
    }

    def __init__(self, db):
        self._repository = FileModulPraktikumRepository(db)
        self._service_modul = ModulPraktikumService(db)

    # =====================================================
    # VALIDASI AKSES MODUL
    # =====================================================

    def _validasi_akses_modul(
        self,
        modul_id: int,
        pengguna: User,
    ):
        return self._service_modul.ambil_detail_modul(
            modul_id=modul_id,
            pengguna=pengguna,
        )

    # =====================================================
    # VALIDASI NAMA FILE
    # =====================================================

    def _validasi_nama_file(
        self,
        nama_file: str,
    ) -> str:

        if not nama_file:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Nama file tidak boleh kosong.",
            )

        # Hilangkan kemungkinan path dari nama file pengguna.
        nama_bersih = Path(
            nama_file.replace("\\", "/")
        ).name.strip()

        # Hapus karakter kontrol.
        nama_bersih = re.sub(
            r"[\x00-\x1f\x7f]",
            "",
            nama_bersih,
        )

        if not nama_bersih or nama_bersih in {".", ".."}:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Nama file tidak valid.",
            )

        if len(nama_bersih) > 255:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Nama file maksimal 255 karakter.",
            )

        ekstensi = Path(nama_bersih).suffix.lower()

        if ekstensi in self.EKSTENSI_DILARANG:
            raise HTTPException(
                status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
                detail=(
                    f"File dengan ekstensi {ekstensi} "
                    "tidak diizinkan."
                ),
            )

        return nama_bersih

    # =====================================================
    # UPLOAD BEBERAPA FILE
    # =====================================================

    async def unggah_file(
        self,
        modul_id: int,
        daftar_file: list[UploadFile],
        pengguna: User,
    ) -> list[PracticumModuleFile]:

        self._validasi_akses_modul(
            modul_id=modul_id,
            pengguna=pengguna,
        )

        if not daftar_file:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Pilih minimal satu file untuk diunggah.",
            )

        if len(daftar_file) > self.MAKSIMAL_JUMLAH_FILE:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    f"Maksimal {self.MAKSIMAL_JUMLAH_FILE} "
                    "file dalam satu kali upload."
                ),
            )

        self.DIREKTORI_STORAGE.mkdir(
            parents=True,
            exist_ok=True,
        )

        file_fisik_tersimpan = []
        hasil_upload = []

        try:
            for file in daftar_file:

                nama_asli = self._validasi_nama_file(
                    file.filename or ""
                )

                ekstensi = Path(nama_asli).suffix.lower()

                nama_penyimpanan = (
                    f"{uuid.uuid4().hex}{ekstensi}"
                )

                lokasi_file = (
                    self.DIREKTORI_STORAGE
                    / nama_penyimpanan
                )

                total_byte = 0

                try:
                    with lokasi_file.open("wb") as tujuan:

                        while True:
                            potongan = await file.read(
                                self.UKURAN_CHUNK
                            )

                            if not potongan:
                                break

                            total_byte += len(potongan)

                            if total_byte > self.MAKSIMAL_UKURAN_FILE:
                                raise HTTPException(
                                    status_code=status.HTTP_413_CONTENT_TOO_LARGE,
                                    detail=(
                                        f"Ukuran file {nama_asli} "
                                        "melebihi batas 50 MB."
                                    ),
                                )

                            tujuan.write(potongan)

                finally:
                    await file.close()

                if total_byte == 0:
                    lokasi_file.unlink(missing_ok=True)

                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"File {nama_asli} kosong.",
                    )

                file_fisik_tersimpan.append(lokasi_file)

                metadata = PracticumModuleFile(
                    module_id=modul_id,
                    original_filename=nama_asli,
                    stored_filename=nama_penyimpanan,
                    storage_path=str(lokasi_file),
                    content_type=file.content_type,
                    file_size=total_byte,
                )

                self._repository.tambah(metadata)
                hasil_upload.append(metadata)

            self._repository.commit()

            return hasil_upload

        except Exception:
            self._repository.rollback()

            # Hapus file fisik jika transaksi database gagal.
            for lokasi in file_fisik_tersimpan:
                lokasi.unlink(missing_ok=True)

            raise

    # =====================================================
    # AMBIL DAFTAR FILE
    # =====================================================

    def ambil_daftar_file(
        self,
        modul_id: int,
        pengguna: User,
    ):

        self._validasi_akses_modul(
            modul_id=modul_id,
            pengguna=pengguna,
        )

        return self._repository.ambil_semua(
            modul_id=modul_id,
        )

    # =====================================================
    # AMBIL DETAIL FILE
    # =====================================================

    def ambil_detail_file(
        self,
        modul_id: int,
        file_id: int,
        pengguna: User,
    ):

        self._validasi_akses_modul(
            modul_id=modul_id,
            pengguna=pengguna,
        )

        file = self._repository.ambil_berdasarkan_id(
            file_id=file_id,
            modul_id=modul_id,
        )

        if file is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Lampiran tidak ditemukan.",
            )

        lokasi = Path(file.storage_path)

        if not lokasi.is_file():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="File fisik tidak ditemukan di server.",
            )

        return file

    # =====================================================
    # HAPUS FILE
    # =====================================================

    def hapus_file(
        self,
        modul_id: int,
        file_id: int,
        pengguna: User,
    ):

        self._validasi_akses_modul(
            modul_id=modul_id,
            pengguna=pengguna,
        )

        file = self._repository.ambil_berdasarkan_id(
            file_id=file_id,
            modul_id=modul_id,
        )

        if file is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Lampiran tidak ditemukan.",
            )

        lokasi = Path(file.storage_path)

        try:
            self._repository.hapus(file)
            self._repository.commit()

            lokasi.unlink(missing_ok=True)

            return {
                "message": "Lampiran berhasil dihapus."
            }

        except Exception:
            self._repository.rollback()
            raise