
from app.domain.pengguna_dasar import PenggunaDasar


class MahasiswaUser(PenggunaDasar):

    @property
    def peran(self) -> str:
        return "mahasiswa"

    def hak_akses(self) -> tuple[str, ...]:
        return (
            "profile:read:self",
            "quizzes:attempt",
            "results:read:self",
            "history:read:self",
        )
