
from app.domain.pengguna_dasar import PenggunaDasar


class AsistenLabUser(PenggunaDasar):

    @property
    def peran(self) -> str:
        return "asisten_lab"

    def hak_akses(self) -> tuple[str, ...]:
        return (
            "modules:manage",
            "questions:manage",
            "quizzes:manage",
            "assessments:grade",
            "participants:view",
        )
