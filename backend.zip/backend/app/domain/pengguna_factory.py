
from app.models.pengguna import User

from app.domain.pengguna_dasar import PenggunaDasar
from app.domain.admin import AdminUser
from app.domain.asisten_lab import AsistenLabUser
from app.domain.mahasiswa import MahasiswaUser


class PenggunaFactory:
    """
    Mengubah model User dari database menjadi objek domain
    berdasarkan role pengguna.
    """

    @staticmethod
    def buat_dari_model(pengguna: User) -> PenggunaDasar:
        data_umum = {
            "id_pengguna": pengguna.id,
            "nama_lengkap": pengguna.full_name,
            "aktif": pengguna.is_active,
        }

        pembuat_pengguna = {
            "admin_developer": AdminUser,
            "asisten_lab": AsistenLabUser,
            "mahasiswa": MahasiswaUser,
        }

        kelas_pengguna = pembuat_pengguna.get(pengguna.role)

        if kelas_pengguna is None:
            raise ValueError(
                f"Role pengguna tidak dikenali: {pengguna.role}"
            )

        return kelas_pengguna(**data_umum)
