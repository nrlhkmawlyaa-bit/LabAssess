
from app.domain.pengguna_dasar import PenggunaDasar


class AdminUser(PenggunaDasar):

    @property
    def peran(self) -> str:
        return "admin_developer"

    def hak_akses(self) -> tuple[str, ...]:
        return (
            "users:manage",
            "students:enroll",
            "assistants:assign",
            "courses:manage",
        )
