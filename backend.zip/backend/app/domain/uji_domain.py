
from app.domain import (
    AdminUser,
    AsistenLabUser,
    MahasiswaUser,
)


daftar_pengguna = [
    AdminUser(1, "Administrator"),
    AsistenLabUser(2, "Asisten Laboratorium"),
    MahasiswaUser(3, "Mahasiswa"),
]

for pengguna in daftar_pengguna:
    print("=" * 40)
    print(f"Nama       : {pengguna.nama_lengkap}")
    print(f"Role       : {pengguna.peran}")
    print(f"Status     : {pengguna.dapat_masuk()}")
    print(f"Hak Akses  : {pengguna.hak_akses()}")
