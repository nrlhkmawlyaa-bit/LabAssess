
from app.database.session import SessionLocal
from app.models.pengguna import User
from app.domain.pengguna_factory import PenggunaFactory


def uji_factory():
    db = SessionLocal()

    try:
        daftar_pengguna = db.query(User).all()

        if not daftar_pengguna:
            print("Belum ada data pengguna di database.")
            return

        for data in daftar_pengguna:
            pengguna = PenggunaFactory.buat_dari_model(data)

            print("=" * 40)
            print(f"Nama      : {pengguna.nama_lengkap}")
            print(f"Role      : {pengguna.peran}")
            print(f"Kelas     : {type(pengguna).__name__}")
            print(f"Aktif     : {pengguna.dapat_masuk()}")
            print(f"Hak akses : {pengguna.hak_akses()}")

    finally:
        db.close()


if __name__ == "__main__":
    uji_factory()
