
from abc import ABC, abstractmethod


class PenggunaDasar(ABC):
    """
    Kelas dasar untuk seluruh jenis pengguna LabAssess.
    """

    def __init__(
        self,
        id_pengguna: int,
        nama_lengkap: str,
        aktif: bool = True
    ):
        self._id_pengguna = id_pengguna
        self._nama_lengkap = nama_lengkap
        self._aktif = aktif

    @property
    def id_pengguna(self) -> int:
        return self._id_pengguna

    @property
    def nama_lengkap(self) -> str:
        return self._nama_lengkap

    @property
    def aktif(self) -> bool:
        return self._aktif

    def ubah_status(self, status: bool) -> None:
        self._aktif = status

    def dapat_masuk(self) -> bool:
        return self._aktif

    @property
    @abstractmethod
    def peran(self) -> str:
        """Mengembalikan identitas role pengguna."""
        pass

    @abstractmethod
    def hak_akses(self) -> tuple[str, ...]:
        """Mengembalikan daftar hak akses pengguna."""
        pass
