
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, selectinload

from app.models.mata_kuliah import Course
from app.models.program_studi import StudyProgram
from app.models.kelas_perkuliahan import CourseClass


class MataKuliahRepository:
    """Repository untuk pengelolaan data mata kuliah."""

    def __init__(self, db: Session):
        self._db = db

    def daftar_mata_kuliah(
        self,
        kata_kunci: str | None = None,
        program_studi_id: int | None = None,
    ) -> list[Course]:

        pernyataan = (
            select(Course)
            .options(selectinload(Course.study_programs))
        )

        if kata_kunci:
            pola = f"%{kata_kunci.strip()}%"
            pernyataan = pernyataan.where(
                or_(
                    Course.code.ilike(pola),
                    Course.name.ilike(pola),
                )
            )

        if program_studi_id is not None:
            pernyataan = (
                pernyataan
                .join(Course.study_programs)
                .where(
                    StudyProgram.id == program_studi_id
                )
            )

        pernyataan = (
            pernyataan
            .distinct()
            .order_by(Course.name.asc())
        )

        return list(self._db.scalars(pernyataan).all())

    def ambil_berdasarkan_id(
        self,
        id_mata_kuliah: int,
    ) -> Course | None:

        pernyataan = (
            select(Course)
            .options(selectinload(Course.study_programs))
            .where(Course.id == id_mata_kuliah)
        )

        return self._db.scalar(pernyataan)

    def ambil_berdasarkan_kode(
        self,
        kode: str,
        kecuali_id: int | None = None,
    ) -> Course | None:

        pernyataan = select(Course).where(
            func.lower(Course.code) == kode.lower()
        )

        if kecuali_id is not None:
            pernyataan = pernyataan.where(
                Course.id != kecuali_id
            )

        return self._db.scalar(pernyataan)

    def daftar_program_studi(
        self,
        daftar_id: list[int],
    ) -> list[StudyProgram]:

        pernyataan = select(StudyProgram).where(
            StudyProgram.id.in_(daftar_id)
        )

        return list(self._db.scalars(pernyataan).all())

    def jumlah_kelas(
        self,
        id_mata_kuliah: int,
    ) -> int:

        pernyataan = select(
            func.count(CourseClass.id)
        ).where(
            CourseClass.course_id == id_mata_kuliah
        )

        return self._db.scalar(pernyataan) or 0

    def tambah(self, mata_kuliah: Course) -> Course:
        self._db.add(mata_kuliah)
        self._db.flush()
        return mata_kuliah

    def hapus(self, mata_kuliah: Course) -> None:
        self._db.delete(mata_kuliah)
