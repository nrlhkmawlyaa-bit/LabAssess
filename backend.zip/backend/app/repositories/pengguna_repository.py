
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.pengguna import User


class PenggunaRepository:
    """
    Repository untuk mengakses data pengguna.
    """

    def __init__(self, db: Session):
        self._db = db

    def cari_berdasarkan_identitas(
        self,
        identitas: str,
        role: str,
    ) -> User | None:
        """
        Mencari pengguna berdasarkan username atau NIM
        sesuai role yang dipilih.
        """

        if role in ("admin_developer", "asisten_lab"):
            kondisi_identitas = User.username == identitas

        elif role == "mahasiswa":
            kondisi_identitas = User.nim == identitas

        else:
            return None

        pernyataan = select(User).where(
            User.role == role,
            kondisi_identitas,
        )

        return self._db.scalar(pernyataan)
