
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, selectinload

from app.models.pengguna import User
from app.models.program_studi import StudyProgram


class ManajemenPenggunaRepository:
    """
    Repository untuk mengelola data mahasiswa dan asisten laboratorium.

    Bertanggung jawab terhadap komunikasi langsung dengan database.
    """

    def __init__(self, db: Session):
        self._db = db

    def daftar_pengguna(
        self,
        role: str | None = None,
        program_studi_id: int | None = None,
        status_aktif: bool | None = None,
        kata_kunci: str | None = None,
        halaman: int = 1,
        batas: int = 10,
    ):
        kondisi = [
            User.role.in_(("mahasiswa", "asisten_lab"))
        ]

        if role:
            kondisi.append(User.role == role)

        if program_studi_id is not None:
            kondisi.append(
                User.study_program_id == program_studi_id
            )

        if status_aktif is not None:
            kondisi.append(User.is_active == status_aktif)

        if kata_kunci:
            pola = f"%{kata_kunci.strip()}%"

            kondisi.append(
                or_(
                    User.full_name.ilike(pola),
                    User.username.ilike(pola),
                    User.nim.ilike(pola),
                )
            )

        pernyataan_total = (
            select(func.count(User.id))
            .where(*kondisi)
        )

        total = self._db.scalar(pernyataan_total) or 0

        pernyataan_data = (
            select(User)
            .options(selectinload(User.study_program))
            .where(*kondisi)
            .order_by(User.created_at.desc(), User.id.desc())
            .offset((halaman - 1) * batas)
            .limit(batas)
        )

        data = self._db.scalars(pernyataan_data).all()

        return total, data

    def ambil_pengguna_berdasarkan_id(
        self,
        id_pengguna: int,
    ) -> User | None:
        """
        Mengambil detail satu akun mahasiswa atau asisten.
        """

        pernyataan = (
            select(User)
            .options(selectinload(User.study_program))
            .where(
                User.id == id_pengguna,
                User.role.in_(("mahasiswa", "asisten_lab")),
            )
        )

        return self._db.scalar(pernyataan)

    def username_sudah_digunakan(
        self,
        username: str,
        kecuali_id: int | None = None,
    ) -> bool:
        """
        Memeriksa apakah username sudah digunakan akun lain.
        """

        pernyataan = select(User.id).where(
            User.username == username
        )

        if kecuali_id is not None:
            pernyataan = pernyataan.where(
                User.id != kecuali_id
            )

        return self._db.scalar(pernyataan) is not None

    def nim_sudah_digunakan(
        self,
        nim: str,
        kecuali_id: int | None = None,
    ) -> bool:
        """
        Memeriksa apakah NIM sudah digunakan akun lain.
        """

        pernyataan = select(User.id).where(
            User.nim == nim
        )

        if kecuali_id is not None:
            pernyataan = pernyataan.where(
                User.id != kecuali_id
            )

        return self._db.scalar(pernyataan) is not None

    def program_studi_tersedia(
        self,
        program_studi_id: int,
    ) -> bool:
        """
        Memeriksa keberadaan program studi.
        """

        pernyataan = select(StudyProgram.id).where(
            StudyProgram.id == program_studi_id
        )

        return self._db.scalar(pernyataan) is not None
