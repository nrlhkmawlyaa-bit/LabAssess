
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.models.modul_praktikum import PracticumModule
from app.models.kelas_perkuliahan import CourseClass
from app.models.pengguna import User


class ModulPraktikumRepository:
    """
    Repository untuk mengelola data modul praktikum.

    Bertanggung jawab atas seluruh operasi database
    yang berkaitan dengan modul praktikum.

    Setiap operasi modul dibatasi berdasarkan kelas
    yang ditugaskan kepada asisten laboratorium.
    """

    def __init__(self, db: Session):
        self._db = db

    # ==========================================
    # CEK KEPEMILIKAN KELAS OLEH ASISTEN
    # ==========================================

    def cek_kelas_asisten(
        self,
        kelas_id: int,
        asisten_id: int,
    ) -> CourseClass | None:

        statement = (
            select(CourseClass)
            .where(
                CourseClass.id == kelas_id,
                CourseClass.assistants.any(
                    User.id == asisten_id
                ),
            )
        )

        return self._db.scalar(statement)

    # ==========================================
    # AMBIL SEMUA MODUL DALAM KELAS
    # ==========================================

    def ambil_semua_modul(
        self,
        kelas_id: int,
        asisten_id: int,
    ) -> list[PracticumModule]:

        statement = (
            select(PracticumModule)
            .join(
                CourseClass,
                PracticumModule.class_id == CourseClass.id,
            )
            .where(
                PracticumModule.class_id == kelas_id,
                CourseClass.assistants.any(
                    User.id == asisten_id
                ),
            )
            .order_by(
                PracticumModule.module_number.asc()
            )
        )

        return list(
            self._db.scalars(statement).all()
        )

    # ==========================================
    # AMBIL MODUL BERDASARKAN ID
    # ==========================================

    def ambil_modul_berdasarkan_id(
        self,
        modul_id: int,
        asisten_id: int,
    ) -> PracticumModule | None:

        statement = (
            select(PracticumModule)
            .join(
                CourseClass,
                PracticumModule.class_id == CourseClass.id,
            )
            .where(
                PracticumModule.id == modul_id,
                CourseClass.assistants.any(
                    User.id == asisten_id
                ),
            )
        )

        return self._db.scalar(statement)

    # ==========================================
    # CEK NOMOR MODUL DUPLIKAT
    # ==========================================

    def cek_nomor_modul(
        self,
        kelas_id: int,
        nomor_modul: int,
        kecuali_modul_id: int | None = None,
    ) -> PracticumModule | None:

        statement = select(PracticumModule).where(
            PracticumModule.class_id == kelas_id,
            PracticumModule.module_number == nomor_modul,
        )

        if kecuali_modul_id is not None:
            statement = statement.where(
                PracticumModule.id != kecuali_modul_id
            )

        return self._db.scalar(statement)

    # ==========================================
    # TAMBAHKAN MODUL
    # ==========================================

    def tambah(
        self,
        modul: PracticumModule,
    ) -> PracticumModule:

        self._db.add(modul)
        self._db.flush()

        return modul

    # ==========================================
    # SIMPAN PERUBAHAN MODUL
    # ==========================================

    def simpan_perubahan(
        self,
        modul: PracticumModule,
    ) -> PracticumModule:

        self._db.add(modul)
        self._db.flush()

        return modul

    # ==========================================
    # HAPUS MODUL
    # ==========================================

    def hapus(
        self,
        modul: PracticumModule,
    ) -> None:

        self._db.delete(modul)
        self._db.flush()

    # ==========================================
    # SIMPAN TRANSAKSI
    # ==========================================

    def commit(self) -> None:
        self._db.commit()

    # ==========================================
    # BATALKAN TRANSAKSI
    # ==========================================

    def rollback(self) -> None:
        self._db.rollback()
