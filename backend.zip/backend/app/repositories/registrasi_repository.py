
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.pengguna import User
from app.models.program_studi import StudyProgram


class RegistrasiRepository:

    def __init__(self, db: Session):
        self._db = db

    def cari_mahasiswa_berdasarkan_nim(
        self,
        nim: str,
    ) -> User | None:

        pernyataan = select(User).where(
            User.nim == nim
        )

        return self._db.scalar(pernyataan)

    def cari_program_studi(
        self,
        program_studi_id: int,
    ) -> StudyProgram | None:

        pernyataan = select(StudyProgram).where(
            StudyProgram.id == program_studi_id
        )

        return self._db.scalar(pernyataan)
