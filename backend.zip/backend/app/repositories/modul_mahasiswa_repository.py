
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.models.pengguna import User
from app.models.kelas_perkuliahan import CourseClass
from app.models.modul_praktikum import PracticumModule
from app.models.file_modul_praktikum import PracticumModuleFile


class ModulMahasiswaRepository:
    """
    Repository untuk mengakses modul praktikum
    berdasarkan kelas yang diikuti mahasiswa.
    """

    def __init__(self, db: Session):
        self._db = db

    def ambil_semua_modul(
        self,
        kelas_id: int,
        mahasiswa_id: int,
    ) -> list[PracticumModule]:
        """
        Mengambil seluruh modul yang sudah dipublikasikan
        pada kelas yang diikuti mahasiswa.
        """

        statement = (
            select(PracticumModule)
            .join(PracticumModule.course_class)
            .join(CourseClass.students)
            .where(
                PracticumModule.class_id == kelas_id,
                PracticumModule.is_published.is_(True),
                CourseClass.is_active.is_(True),
                User.id == mahasiswa_id,
                User.role == "mahasiswa",
                User.is_active.is_(True),
            )
            .options(
                selectinload(PracticumModule.files),
            )
            .order_by(PracticumModule.module_number.asc())
        )

        return list(
            self._db.scalars(statement).unique().all()
        )

    def ambil_modul_berdasarkan_id(
        self,
        modul_id: int,
        mahasiswa_id: int,
    ) -> PracticumModule | None:
        """
        Mengambil detail modul jika mahasiswa terdaftar
        pada kelas pemilik modul dan modul sudah dipublikasikan.
        """

        statement = (
            select(PracticumModule)
            .join(PracticumModule.course_class)
            .join(CourseClass.students)
            .where(
                PracticumModule.id == modul_id,
                PracticumModule.is_published.is_(True),
                CourseClass.is_active.is_(True),
                User.id == mahasiswa_id,
                User.role == "mahasiswa",
                User.is_active.is_(True),
            )
            .options(
                selectinload(PracticumModule.files),
            )
        )

        return self._db.scalars(statement).unique().first()

    def ambil_file_berdasarkan_id(
        self,
        file_id: int,
        modul_id: int,
        mahasiswa_id: int,
    ) -> PracticumModuleFile | None:
        """
        Mengambil file hanya jika mahasiswa berhak
        mengakses modul tersebut.
        """

        statement = (
            select(PracticumModuleFile)
            .join(PracticumModuleFile.practicum_module)
            .join(PracticumModule.course_class)
            .join(CourseClass.students)
            .where(
                PracticumModuleFile.id == file_id,
                PracticumModuleFile.module_id == modul_id,
                PracticumModule.is_published.is_(True),
                CourseClass.is_active.is_(True),
                User.id == mahasiswa_id,
                User.role == "mahasiswa",
                User.is_active.is_(True),
            )
        )

        return self._db.scalars(statement).first()
