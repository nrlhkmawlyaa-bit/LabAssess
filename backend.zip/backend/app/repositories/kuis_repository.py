

from sqlalchemy import select

from sqlalchemy.orm import Session, selectinload



from app.models.kuis import Quiz

from app.models.soal_kuis import QuizQuestion

from app.models.opsi_kuis import QuizOption

from app.models.pengerjaan_kuis import QuizAttempt

from app.models.jawaban_kuis import QuizAnswer

from app.models.nilai_kuis import QuizGrade



from app.models.kelas_perkuliahan import CourseClass
from app.models.modul_praktikum import PracticumModule

from app.models.pengguna import User





class KuisRepository:

    """

    Repository untuk mengelola seluruh data Pre-Test

    dan Post-Test pada aplikasi LabAssess.



    Bertanggung jawab terhadap operasi database

    yang berkaitan dengan:



    - Kuis

    - Soal kuis

    - Opsi jawaban

    - Pengerjaan mahasiswa

    - Jawaban mahasiswa

    - Nilai kuis



    Setiap operasi asisten dibatasi berdasarkan kelas

    yang ditugaskan kepadanya.

    """



    def __init__(self, db: Session):

        self._db = db



    # =====================================================

    # VALIDASI KEPEMILIKAN KELAS

    # =====================================================



    def cek_kelas_asisten(

        self,

        kelas_id: int,

        asisten_id: int,

    ) -> CourseClass | None:

        """

        Memastikan kelas ditugaskan kepada asisten.

        """



        statement = (

            select(CourseClass)

            .where(

                CourseClass.id == kelas_id,

                CourseClass.assistants.any(

                    User.id == asisten_id

                ),

            )

        )



        return self._db.scalar(statement)



    def cek_kelas_mahasiswa(

        self,

        kelas_id: int,

        mahasiswa_id: int,

    ) -> CourseClass | None:

        """

        Memastikan mahasiswa terdaftar pada kelas.

        """



        statement = (

            select(CourseClass)

            .where(

                CourseClass.id == kelas_id,

                CourseClass.students.any(

                    User.id == mahasiswa_id

                ),

            )

        )



        return self._db.scalar(statement)



    # =====================================================

    # MENGELOLA KUIS

    # =====================================================



    def ambil_semua_kuis(

        self,

        kelas_id: int,

        asisten_id: int,

    ) -> list[Quiz]:

        """

        Mengambil seluruh Pre-Test dan Post-Test

        dari kelas yang ditangani asisten.

        """



        statement = (

            select(Quiz)

            .join(

                CourseClass,

                Quiz.class_id == CourseClass.id,

            )

            .where(

                Quiz.class_id == kelas_id,

                CourseClass.assistants.any(

                    User.id == asisten_id

                ),

            )

            .order_by(

                Quiz.created_at.desc()

            )

        )



        return list(

            self._db.scalars(statement).all()

        )



    def ambil_kuis_berdasarkan_id(

        self,

        kuis_id: int,

        asisten_id: int,

    ) -> Quiz | None:

        """

        Mengambil detail kuis berdasarkan ID

        dengan memeriksa kepemilikan kelas.

        """



        statement = (

            select(Quiz)

            .join(

                CourseClass,

                Quiz.class_id == CourseClass.id,

            )

            .options(

                selectinload(Quiz.questions)

                .selectinload(QuizQuestion.options)

            )

            .where(

                Quiz.id == kuis_id,

                CourseClass.assistants.any(

                    User.id == asisten_id

                ),

            )

        )



        return self._db.scalar(statement)



    def ambil_kuis_mahasiswa(

        self,

        kelas_id: int,

        mahasiswa_id: int,

    ) -> list[Quiz]:

        """

        Mengambil kuis yang tersedia untuk mahasiswa

        berdasarkan kelas yang diikutinya.



        Hanya kuis berstatus published yang ditampilkan.

        """



        statement = (

            select(Quiz)

            .join(

                CourseClass,

                Quiz.class_id == CourseClass.id,

            )

            .where(

                Quiz.class_id == kelas_id,

                Quiz.status == "published",

                CourseClass.students.any(

                    User.id == mahasiswa_id

                ),

            )

            .order_by(

                Quiz.start_at.asc()

            )

        )



        return list(

            self._db.scalars(statement).all()

        )



    def ambil_kuis_mahasiswa_berdasarkan_id(

        self,

        kuis_id: int,

        mahasiswa_id: int,

    ) -> Quiz | None:

        """

        Mengambil kuis untuk mahasiswa.



        Kuis hanya dapat diakses jika mahasiswa

        terdaftar pada kelas terkait.

        """



        statement = (

            select(Quiz)

            .join(

                CourseClass,

                Quiz.class_id == CourseClass.id,

            )

            .options(

                selectinload(Quiz.questions)

                .selectinload(QuizQuestion.options)

            )

            .where(

                Quiz.id == kuis_id,

                Quiz.status == "published",

                CourseClass.students.any(

                    User.id == mahasiswa_id

                ),

            )

        )



        return self._db.scalar(statement)



    def ambil_modul_untuk_kelas_asisten(

        self,

        modul_id: int,

        kelas_id: int,

        asisten_id: int,

    ) -> PracticumModule | None:

        """Memastikan modul berada di kelas dan kelas ditugaskan ke asisten."""

        statement = (

            select(PracticumModule)

            .join(CourseClass, PracticumModule.class_id == CourseClass.id)

            .where(

                PracticumModule.id == modul_id,

                PracticumModule.class_id == kelas_id,

                CourseClass.assistants.any(User.id == asisten_id),

            )

        )

        return self._db.scalar(statement)


    def cek_jenis_kuis(

        self,

        kelas_id: int,

        jenis_kuis: str,

        kecuali_kuis_id: int | None = None,

        module_id: int | None = None,

    ) -> Quiz | None:

        """

        Memeriksa duplikasi jenis evaluasi pada satu modul.
        Jika module_id None, pencarian dibatasi ke kuis legacy
        yang belum terhubung ke modul.

        """



        statement = select(Quiz).where(

            Quiz.class_id == kelas_id,

            Quiz.quiz_type == jenis_kuis,

            Quiz.module_id.is_(None) if module_id is None else Quiz.module_id == module_id,

        )



        if kecuali_kuis_id is not None:

            statement = statement.where(

                Quiz.id != kecuali_kuis_id

            )



        return self._db.scalar(statement)



    def tambah_kuis(

        self,

        kuis: Quiz,

    ) -> Quiz:

        """

        Menambahkan kuis baru.

        """



        self._db.add(kuis)

        self._db.flush()



        return kuis



    def simpan_perubahan_kuis(

        self,

        kuis: Quiz,

    ) -> Quiz:

        """

        Menyimpan perubahan konfigurasi kuis.

        """



        self._db.add(kuis)

        self._db.flush()



        return kuis



    def hapus_kuis(

        self,

        kuis: Quiz,

    ) -> None:

        """

        Menghapus kuis.

        """



        self._db.delete(kuis)

        self._db.flush()



    # =====================================================

    # MENGELOLA SOAL

    # =====================================================



    def ambil_semua_soal(

        self,

        kuis_id: int,

    ) -> list[QuizQuestion]:

        """

        Mengambil seluruh soal berdasarkan kuis.

        """



        statement = (

            select(QuizQuestion)

            .options(

                selectinload(QuizQuestion.options)

            )

            .where(

                QuizQuestion.quiz_id == kuis_id

            )

            .order_by(

                QuizQuestion.question_order.asc()

            )

        )



        return list(

            self._db.scalars(statement).all()

        )



    def ambil_soal_berdasarkan_id(

        self,

        soal_id: int,

        kuis_id: int,

    ) -> QuizQuestion | None:

        """

        Mengambil satu soal berdasarkan ID dan kuis.

        """



        statement = (

            select(QuizQuestion)

            .options(

                selectinload(QuizQuestion.options)

            )

            .where(

                QuizQuestion.id == soal_id,

                QuizQuestion.quiz_id == kuis_id,

            )

        )



        return self._db.scalar(statement)



    def cek_nomor_soal(

        self,

        kuis_id: int,

        nomor_soal: int,

        kecuali_soal_id: int | None = None,

    ) -> QuizQuestion | None:

        """

        Memeriksa duplikasi urutan soal.

        """



        statement = select(QuizQuestion).where(

            QuizQuestion.quiz_id == kuis_id,

            QuizQuestion.question_order == nomor_soal,

        )



        if kecuali_soal_id is not None:

            statement = statement.where(

                QuizQuestion.id != kecuali_soal_id

            )



        return self._db.scalar(statement)



    def tambah_soal(

        self,

        soal: QuizQuestion,

    ) -> QuizQuestion:

        """

        Menambahkan soal baru.

        """



        self._db.add(soal)

        self._db.flush()



        return soal



    def simpan_perubahan_soal(

        self,

        soal: QuizQuestion,

    ) -> QuizQuestion:

        """

        Menyimpan perubahan soal.

        """



        self._db.add(soal)

        self._db.flush()



        return soal



    def hapus_soal(

        self,

        soal: QuizQuestion,

    ) -> None:

        """

        Menghapus soal.

        """



        self._db.delete(soal)

        self._db.flush()



    # =====================================================

    # MENGELOLA OPSI JAWABAN

    # =====================================================



    def ambil_opsi_soal(

        self,

        soal_id: int,

    ) -> list[QuizOption]:

        """

        Mengambil seluruh opsi dari sebuah soal.

        """



        statement = (

            select(QuizOption)

            .where(

                QuizOption.question_id == soal_id

            )

            .order_by(

                QuizOption.option_order.asc()

            )

        )



        return list(

            self._db.scalars(statement).all()

        )



    def tambah_opsi(

        self,

        opsi: QuizOption,

    ) -> QuizOption:

        """

        Menambahkan opsi jawaban.

        """



        self._db.add(opsi)

        self._db.flush()



        return opsi



    def hapus_opsi(

        self,

        opsi: QuizOption,

    ) -> None:

        """

        Menghapus opsi jawaban.

        """



        self._db.delete(opsi)

        self._db.flush()



    # =====================================================

    # MENGELOLA PENGERJAAN KUIS

    # =====================================================



    def ambil_pengerjaan(

        self,

        kuis_id: int,

        mahasiswa_id: int,

    ) -> QuizAttempt | None:

        """

        Mengambil pengerjaan mahasiswa.



        Unique constraint pada database memastikan

        satu mahasiswa hanya memiliki satu pengerjaan

        untuk satu kuis.

        """



        statement = (

            select(QuizAttempt)

            .options(

                selectinload(QuizAttempt.answers),

                selectinload(QuizAttempt.grade),

            )

            .where(

                QuizAttempt.quiz_id == kuis_id,

                QuizAttempt.student_id == mahasiswa_id,

            )

        )



        return self._db.scalar(statement)



    def ambil_pengerjaan_berdasarkan_id(

        self,

        pengerjaan_id: int,

        mahasiswa_id: int | None = None,

    ) -> QuizAttempt | None:

        """

        Mengambil pengerjaan berdasarkan ID.



        Jika mahasiswa_id diberikan, pengerjaan

        dibatasi hanya milik mahasiswa tersebut.

        """



        statement = (

            select(QuizAttempt)

            .options(

                selectinload(QuizAttempt.answers),

                selectinload(QuizAttempt.grade),

            )

            .where(

                QuizAttempt.id == pengerjaan_id

            )

        )



        if mahasiswa_id is not None:

            statement = statement.where(

                QuizAttempt.student_id == mahasiswa_id

            )



        return self._db.scalar(statement)



    def ambil_semua_pengerjaan(

        self,

        kuis_id: int,

    ) -> list[QuizAttempt]:

        """

        Mengambil seluruh pengerjaan mahasiswa

        pada satu kuis.

        """



        statement = (

            select(QuizAttempt)

            .options(

                selectinload(QuizAttempt.student),

                selectinload(QuizAttempt.grade),

            )

            .where(

                QuizAttempt.quiz_id == kuis_id

            )

            .order_by(

                QuizAttempt.started_at.desc()

            )

        )



        return list(

            self._db.scalars(statement).all()

        )



    def ambil_riwayat_nilai_mahasiswa(
        self,
        mahasiswa_id: int,
    ) -> list[QuizAttempt]:
        """
        Mengambil seluruh riwayat pengerjaan kuis mahasiswa.

        Hanya mengambil pengerjaan milik mahasiswa yang sedang login
        dan yang sudah dikumpulkan.
        """

        statement = (
            select(QuizAttempt)
            .join(
                Quiz,
                QuizAttempt.quiz_id == Quiz.id,
            )
            .join(
                CourseClass,
                Quiz.class_id == CourseClass.id,
            )
            .options(
                selectinload(QuizAttempt.quiz),
                selectinload(QuizAttempt.grade),
            )
            .where(
                QuizAttempt.student_id == mahasiswa_id,
                QuizAttempt.status == "submitted",
                CourseClass.students.any(
                    User.id == mahasiswa_id
                ),
            )
            .order_by(
                QuizAttempt.submitted_at.desc()
            )
        )

        return list(
            self._db.scalars(statement).all()
        )


    def hapus_pengerjaan(

        self,

        pengerjaan: QuizAttempt,

    ) -> None:

        """Menghapus satu percobaan beserta jawaban dan nilainya."""

        self._db.delete(pengerjaan)

        self._db.flush()



    def tambah_pengerjaan(

        self,

        pengerjaan: QuizAttempt,

    ) -> QuizAttempt:

        """

        Membuat pengerjaan baru.

        """



        self._db.add(pengerjaan)

        self._db.flush()



        return pengerjaan



    def simpan_perubahan_pengerjaan(

        self,

        pengerjaan: QuizAttempt,

    ) -> QuizAttempt:

        """

        Menyimpan perubahan pengerjaan.

        """



        self._db.add(pengerjaan)

        self._db.flush()



        return pengerjaan



    # =====================================================

    # MENGELOLA JAWABAN MAHASISWA

    # =====================================================



    def ambil_jawaban(

        self,

        pengerjaan_id: int,

        soal_id: int,

    ) -> QuizAnswer | None:

        """

        Mengambil jawaban mahasiswa berdasarkan

        pengerjaan dan soal.

        """



        statement = select(QuizAnswer).where(

            QuizAnswer.attempt_id == pengerjaan_id,

            QuizAnswer.question_id == soal_id,

        )



        return self._db.scalar(statement)



    def ambil_semua_jawaban(

        self,

        pengerjaan_id: int,

    ) -> list[QuizAnswer]:

        """

        Mengambil seluruh jawaban mahasiswa.

        """



        statement = (

            select(QuizAnswer)

            .options(

                selectinload(QuizAnswer.question),

                selectinload(QuizAnswer.selected_option),

            )

            .where(

                QuizAnswer.attempt_id == pengerjaan_id

            )

        )



        return list(

            self._db.scalars(statement).all()

        )



    def tambah_jawaban(

        self,

        jawaban: QuizAnswer,

    ) -> QuizAnswer:

        """

        Menambahkan jawaban mahasiswa.

        """



        self._db.add(jawaban)

        self._db.flush()



        return jawaban



    def simpan_perubahan_jawaban(

        self,

        jawaban: QuizAnswer,

    ) -> QuizAnswer:

        """

        Menyimpan perubahan jawaban mahasiswa.

        """



        self._db.add(jawaban)

        self._db.flush()



        return jawaban



    # =====================================================

    # MENGELOLA NILAI KUIS

    # =====================================================



    def ambil_nilai(

        self,

        pengerjaan_id: int,

    ) -> QuizGrade | None:

        """

        Mengambil nilai berdasarkan pengerjaan.

        """



        statement = select(QuizGrade).where(

            QuizGrade.attempt_id == pengerjaan_id

        )



        return self._db.scalar(statement)



    def tambah_nilai(

        self,

        nilai: QuizGrade,

    ) -> QuizGrade:

        """

        Membuat data nilai kuis.

        """



        self._db.add(nilai)

        self._db.flush()



        return nilai



    def simpan_perubahan_nilai(

        self,

        nilai: QuizGrade,

    ) -> QuizGrade:

        """

        Menyimpan perubahan nilai kuis.

        """



        self._db.add(nilai)

        self._db.flush()



        return nilai



    # =====================================================

    # TRANSAKSI DATABASE

    # =====================================================



    def commit(self) -> None:

        """

        Menyimpan seluruh perubahan transaksi.

        """



        self._db.commit()



    def rollback(self) -> None:

        """

        Membatalkan seluruh perubahan transaksi.

        """



        self._db.rollback()
