
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.models.pengguna import User
from app.models.kelas_perkuliahan import CourseClass


class MahasiswaRepository:
    """
    Repository untuk mengambil data akademik mahasiswa.

    Seluruh pengambilan kelas dibatasi berdasarkan
    relasi mahasiswa pada tabel class_students.
    """

    def __init__(self, db: Session):
        self._db = db

    # ==========================================
    # AMBIL SELURUH KELAS MAHASISWA
    # ==========================================

    def ambil_semua_kelas(
        self,
        mahasiswa_id: int,
    ) -> list[CourseClass]:

        statement = (
            select(CourseClass)
            .join(
                CourseClass.students
            )
            .where(
                User.id == mahasiswa_id,
                User.role == "mahasiswa",
                CourseClass.is_active.is_(True),
            )
            .options(
                selectinload(CourseClass.course),
                selectinload(CourseClass.academic_period),
                selectinload(CourseClass.assistants),
            )
            .order_by(
                CourseClass.id.asc()
            )
        )

        return list(
            self._db.scalars(statement).unique().all()
        )

    # ==========================================
    # AMBIL DETAIL KELAS MAHASISWA
    # ==========================================

    def ambil_kelas_berdasarkan_id(
        self,
        kelas_id: int,
        mahasiswa_id: int,
    ) -> CourseClass | None:

        statement = (
            select(CourseClass)
            .join(
                CourseClass.students
            )
            .where(
                CourseClass.id == kelas_id,
                User.id == mahasiswa_id,
                User.role == "mahasiswa",
                CourseClass.is_active.is_(True),
            )
            .options(
                selectinload(CourseClass.course),
                selectinload(CourseClass.academic_period),
                selectinload(CourseClass.assistants),
            )
        )

        return self._db.scalar(statement)
