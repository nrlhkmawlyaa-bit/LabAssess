
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.periode_akademik import AcademicPeriod


class PeriodeAkademikRepository:
    """
    Repository untuk mengelola data periode akademik.
    Seluruh operasi database periode akademik dilakukan di sini.
    """

    def __init__(self, db: Session):
        self._db = db

    # ==========================================
    # AMBIL SELURUH PERIODE AKADEMIK
    # ==========================================

    def ambil_semua(self) -> list[AcademicPeriod]:
        statement = (
            select(AcademicPeriod)
            .order_by(
                AcademicPeriod.academic_year.desc(),
                AcademicPeriod.semester.asc(),
            )
        )

        return list(self._db.scalars(statement).all())

    # ==========================================
    # AMBIL PERIODE BERDASARKAN ID
    # ==========================================

    def ambil_berdasarkan_id(
        self,
        periode_id: int,
    ) -> AcademicPeriod | None:

        return self._db.get(AcademicPeriod, periode_id)

    # ==========================================
    # CARI PERIODE BERDASARKAN TAHUN DAN SEMESTER
    # ==========================================

    def ambil_berdasarkan_tahun_dan_semester(
        self,
        academic_year: str,
        semester: str,
    ) -> AcademicPeriod | None:

        statement = select(AcademicPeriod).where(
            AcademicPeriod.academic_year == academic_year,
            AcademicPeriod.semester == semester,
        )

        return self._db.scalar(statement)

    # ==========================================
    # TAMBAHKAN PERIODE AKADEMIK
    # ==========================================

    def tambah(
        self,
        periode: AcademicPeriod,
    ) -> AcademicPeriod:

        self._db.add(periode)
        self._db.flush()

        return periode

    # ==========================================
    # HAPUS PERIODE AKADEMIK
    # ==========================================

    def hapus(
        self,
        periode: AcademicPeriod,
    ) -> None:

        self._db.delete(periode)
        self._db.flush()
