
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.models.kelas_perkuliahan import CourseClass


class KelasPerkuliahanRepository:
    """
    Repository untuk mengelola data kelas perkuliahan.
    """

    def __init__(self, db: Session):
        self._db = db

    # ==========================================
    # AMBIL SEMUA KELAS
    # ==========================================

    def ambil_semua(self) -> list[CourseClass]:
        statement = (
            select(CourseClass)
            .options(
                selectinload(CourseClass.course),
                selectinload(CourseClass.academic_period),
                selectinload(CourseClass.assistants),
                selectinload(CourseClass.students),
            )
            .order_by(CourseClass.id.desc())
        )

        return list(self._db.scalars(statement).all())

    # ==========================================
    # AMBIL KELAS BERDASARKAN ID
    # ==========================================

    def ambil_berdasarkan_id(
        self,
        kelas_id: int,
    ) -> CourseClass | None:

        statement = (
            select(CourseClass)
            .options(
                selectinload(CourseClass.course),
                selectinload(CourseClass.academic_period),
                selectinload(CourseClass.assistants),
                selectinload(CourseClass.students),
            )
            .where(CourseClass.id == kelas_id)
        )

        return self._db.scalar(statement)

    # ==========================================
    # CEK KODE KELAS DUPLIKAT
    # ==========================================

    def ambil_berdasarkan_kode(
        self,
        course_id: int,
        academic_period_id: int,
        class_code: str,
    ) -> CourseClass | None:

        statement = select(CourseClass).where(
            CourseClass.course_id == course_id,
            CourseClass.academic_period_id == academic_period_id,
            CourseClass.class_code == class_code,
        )

        return self._db.scalar(statement)

    # ==========================================
    # TAMBAHKAN KELAS
    # ==========================================

    def tambah(
        self,
        kelas: CourseClass,
    ) -> CourseClass:

        self._db.add(kelas)
        self._db.flush()

        return kelas

    # ==========================================
    # HAPUS KELAS
    # ==========================================

    def hapus(
        self,
        kelas: CourseClass,
    ) -> None:

        self._db.delete(kelas)
        self._db.flush()
