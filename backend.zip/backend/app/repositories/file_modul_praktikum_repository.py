from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.file_modul_praktikum import PracticumModuleFile


class FileModulPraktikumRepository:
    """
    Repository untuk mengelola metadata file lampiran modul praktikum.

    Bertanggung jawab atas:
    - Menyimpan metadata file.
    - Mengambil seluruh file berdasarkan modul.
    - Mengambil detail file.
    - Menghapus metadata file.
    - Mengelola transaksi database.
    """

    def __init__(self, db: Session):
        self._db = db

    # ==========================================
    # TAMBAHKAN METADATA FILE
    # ==========================================

    def tambah(
        self,
        file: PracticumModuleFile,
    ) -> PracticumModuleFile:

        self._db.add(file)
        self._db.flush()

        return file

    # ==========================================
    # AMBIL SEMUA FILE DALAM MODUL
    # ==========================================

    def ambil_semua(
        self,
        modul_id: int,
    ) -> list[PracticumModuleFile]:

        statement = (
            select(PracticumModuleFile)
            .where(
                PracticumModuleFile.module_id == modul_id
            )
            .order_by(
                PracticumModuleFile.uploaded_at.desc()
            )
        )

        return list(
            self._db.scalars(statement).all()
        )

    # ==========================================
    # AMBIL FILE BERDASARKAN ID DAN MODUL
    # ==========================================

    def ambil_berdasarkan_id(
        self,
        file_id: int,
        modul_id: int,
    ) -> PracticumModuleFile | None:

        statement = select(
            PracticumModuleFile
        ).where(
            PracticumModuleFile.id == file_id,
            PracticumModuleFile.module_id == modul_id,
        )

        return self._db.scalar(statement)

    # ==========================================
    # AMBIL FILE BERDASARKAN ID
    # ==========================================

    def ambil_detail(
        self,
        file_id: int,
    ) -> PracticumModuleFile | None:

        statement = select(
            PracticumModuleFile
        ).where(
            PracticumModuleFile.id == file_id
        )

        return self._db.scalar(statement)

    # ==========================================
    # HAPUS METADATA FILE
    # ==========================================

    def hapus(
        self,
        file: PracticumModuleFile,
    ) -> None:

        self._db.delete(file)
        self._db.flush()

    # ==========================================
    # SIMPAN TRANSAKSI
    # ==========================================

    def commit(self) -> None:
        self._db.commit()

    # ==========================================
    # BATALKAN TRANSAKSI
    # ==========================================

    def rollback(self) -> None:
        self._db.rollback()