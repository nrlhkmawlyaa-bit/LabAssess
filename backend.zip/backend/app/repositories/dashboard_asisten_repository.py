
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.models.kelas_perkuliahan import CourseClass
from app.models.pengguna import User


class DashboardAsistenRepository:
    """
    Repository untuk mengambil data dashboard asisten.

    Seluruh kelas difilter berdasarkan relasi asisten
    yang sedang login.
    """

    def __init__(self, db: Session):
        self._db = db

    def ambil_kelas_asisten(
        self,
        asisten_id: int,
    ) -> list[CourseClass]:

        statement = (
            select(CourseClass)
            .where(
                CourseClass.assistants.any(
                    User.id == asisten_id
                )
            )
            .options(
                selectinload(CourseClass.course),
                selectinload(CourseClass.academic_period),
                selectinload(CourseClass.students),
            )
            .order_by(CourseClass.id)
        )

        return list(
            self._db.scalars(statement).all()
        )

    def ambil_detail_kelas_asisten(
        self,
        kelas_id: int,
        asisten_id: int,
    ) -> CourseClass | None:
        """
        Mengambil detail kelas yang memang ditugaskan
        kepada asisten yang sedang login.
        """

        statement = (
            select(CourseClass)
            .where(
                CourseClass.id == kelas_id,
                CourseClass.assistants.any(
                    User.id == asisten_id
                ),
            )
            .options(
                selectinload(CourseClass.course),
                selectinload(CourseClass.academic_period),
                selectinload(
                    CourseClass.students
                ).selectinload(
                    User.study_program
                ),
            )
        )

        return self._db.scalar(statement)
