
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.models.kelas_perkuliahan import CourseClass
from app.models.pengguna import User
from app.models.kuis import Quiz
from app.models.pengerjaan_kuis import QuizAttempt


class RekapNilaiRepository:
    """Mengambil data rekap Pre-Test dan Post-Test milik asisten."""

    def __init__(self, db: Session):
        self._db = db

    def ambil_daftar_program_studi(
        self,
        asisten_id: int,
    ) -> list[dict]:
        """Daftar prodi mahasiswa pada kelas yang ditangani asisten."""

        statement = (
            select(CourseClass)
            .where(
                CourseClass.assistants.any(User.id == asisten_id),
            )
            .options(
                selectinload(
                    CourseClass.students
                ).selectinload(User.study_program)
            )
        )

        kelas_list = self._db.scalars(statement).unique().all()

        daftar_prodi = {}

        for kelas in kelas_list:
            for mahasiswa in kelas.students:
                if (
                    mahasiswa.role != "mahasiswa"
                    or mahasiswa.study_program is None
                ):
                    continue

                prodi = mahasiswa.study_program

                daftar_prodi[prodi.id] = {
                    "id": prodi.id,
                    "kode": prodi.code,
                    "nama": prodi.name,
                }

        return sorted(
            daftar_prodi.values(),
            key=lambda item: item["nama"].lower(),
        )

    def ambil_rekap_nilai(
        self,
        asisten_id: int,
        program_studi_id: int | None = None,
    ) -> list[dict]:
        """Mengambil rekap per kuis untuk seluruh kelas milik asisten."""

        statement = (
            select(CourseClass)
            .where(
                CourseClass.assistants.any(User.id == asisten_id),
            )
            .options(
                selectinload(CourseClass.course),
                selectinload(
                    CourseClass.students
                ).selectinload(User.study_program),
                selectinload(CourseClass.quizzes)
                .selectinload(Quiz.attempts)
                .selectinload(QuizAttempt.grade),
            )
            .order_by(CourseClass.id.asc())
        )

        kelas_list = self._db.scalars(statement).unique().all()
        hasil: list[dict] = []

        for kelas in kelas_list:
            mahasiswa_list = [
                mahasiswa
                for mahasiswa in kelas.students
                if mahasiswa.role == "mahasiswa"
                and mahasiswa.study_program is not None
                and (
                    program_studi_id is None
                    or mahasiswa.study_program_id == program_studi_id
                )
            ]

            if not mahasiswa_list:
                continue

            for kuis in sorted(
                kelas.quizzes,
                key=lambda item: (item.quiz_type, item.id),
            ):
                pengerjaan_by_student = {
                    pengerjaan.student_id: pengerjaan
                    for pengerjaan in kuis.attempts
                }

                for mahasiswa in mahasiswa_list:
                    pengerjaan = pengerjaan_by_student.get(mahasiswa.id)

                    nilai = (
                        pengerjaan.grade
                        if pengerjaan is not None
                        else None
                    )

                    sudah_dipublikasikan = (
                        nilai is not None
                        and nilai.grading_status == "published"
                    )

                    hasil.append({
                        "kelas_id": kelas.id,
                        "kode_kelas": kelas.class_code,
                        "mata_kuliah": (
                            kelas.course.name
                            if kelas.course
                            else None
                        ),
                        "mahasiswa_id": mahasiswa.id,
                        "nim": mahasiswa.nim,
                        "nama_mahasiswa": mahasiswa.full_name,
                        "program_studi_id": mahasiswa.study_program_id,
                        "kode_prodi": mahasiswa.study_program.code,
                        "program_studi": mahasiswa.study_program.name,
                        "kuis_id": kuis.id,
                        "judul_kuis": kuis.title,
                        "jenis_kuis": kuis.quiz_type,
                        "status_pengerjaan": (
                            pengerjaan.status
                            if pengerjaan is not None
                            else "belum_mengerjakan"
                        ),
                        "status_penilaian": (
                            nilai.grading_status
                            if nilai is not None
                            else "belum_dikerjakan"
                            if pengerjaan is None
                            else "belum_dinilai"
                        ),
                        "nilai": (
                            float(nilai.final_score)
                            if (
                                sudah_dipublikasikan
                                and nilai.final_score is not None
                            )
                            else None
                        ),
                        "tanggal_pengumpulan": (
                            pengerjaan.submitted_at.isoformat()
                            if (
                                pengerjaan is not None
                                and pengerjaan.submitted_at
                            )
                            else None
                        ),
                        "tanggal_publikasi": (
                            nilai.published_at.isoformat()
                            if (
                                sudah_dipublikasikan
                                and nilai.published_at
                            )
                            else None
                        ),
                    })

        return hasil
