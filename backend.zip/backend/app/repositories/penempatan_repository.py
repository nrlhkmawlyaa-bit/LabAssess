
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.models.pengguna import User
from app.models.kelas_perkuliahan import CourseClass
from app.models.mata_kuliah import Course


class PenempatanRepository:
    """
    Repository untuk mengelola relasi asisten dan mahasiswa
    dengan kelas perkuliahan.
    """

    def __init__(self, db: Session):
        self._db = db

    # ==========================================
    # KELAS PERKULIAHAN
    # ==========================================

    def ambil_semua_kelas(self) -> list[CourseClass]:
        statement = (
            select(CourseClass)
            .options(
                selectinload(CourseClass.assistants),
                selectinload(CourseClass.students),
                selectinload(CourseClass.course).selectinload(
                    Course.study_programs
                ),
            )
            .order_by(CourseClass.id)
        )

        return list(self._db.scalars(statement).all())

    def ambil_kelas_berdasarkan_id(
        self,
        kelas_id: int,
    ) -> CourseClass | None:
        statement = (
            select(CourseClass)
            .options(
                selectinload(CourseClass.assistants),
                selectinload(CourseClass.students),
                selectinload(CourseClass.course).selectinload(
                    Course.study_programs
                ),
            )
            .where(CourseClass.id == kelas_id)
        )

        return self._db.scalars(statement).first()

    # ==========================================
    # PENGGUNA
    # ==========================================

    def ambil_pengguna_berdasarkan_id(
        self,
        pengguna_id: int,
    ) -> User | None:
        return self._db.get(User, pengguna_id)

    def ambil_semua_asisten(self) -> list[User]:
        statement = (
            select(User)
            .where(
                User.role == "asisten_lab",
                User.is_active.is_(True),
            )
            .order_by(User.full_name)
        )

        return list(self._db.scalars(statement).all())

    def ambil_semua_mahasiswa(self) -> list[User]:
        statement = (
            select(User)
            .where(
                User.role == "mahasiswa",
                User.is_active.is_(True),
            )
            .order_by(User.full_name)
        )

        return list(self._db.scalars(statement).all())

    # ==========================================
    # PENEMPATAN ASISTEN
    # ==========================================

    def tambah_asisten_ke_kelas(
        self,
        kelas: CourseClass,
        asisten: User,
    ) -> None:
        if asisten not in kelas.assistants:
            kelas.assistants.append(asisten)

    def hapus_asisten_dari_kelas(
        self,
        kelas: CourseClass,
        asisten: User,
    ) -> None:
        if asisten in kelas.assistants:
            kelas.assistants.remove(asisten)

    # ==========================================
    # PENEMPATAN MAHASISWA
    # ==========================================

    def tambah_mahasiswa_ke_kelas(
        self,
        kelas: CourseClass,
        mahasiswa: User,
    ) -> None:
        if mahasiswa not in kelas.students:
            kelas.students.append(mahasiswa)

    def hapus_mahasiswa_dari_kelas(
        self,
        kelas: CourseClass,
        mahasiswa: User,
    ) -> None:
        if mahasiswa in kelas.students:
            kelas.students.remove(mahasiswa)

    # ==========================================
    # SIMPAN PERUBAHAN
    # ==========================================

    def simpan(self) -> None:
        self._db.flush()
        self._db.commit()

    def batalkan(self) -> None:
        self._db.rollback()
