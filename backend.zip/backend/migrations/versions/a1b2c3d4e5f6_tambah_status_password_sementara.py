
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# Identitas revision Alembic
revision: str = "a1b2c3d4e5f6"
down_revision: Union[str, Sequence[str], None] = "47fd4c64a23d"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """
    Menambahkan kolom untuk pengelolaan password sementara.
    """

    op.add_column(
        "users",
        sa.Column(
            "must_change_password",
            sa.Boolean(),
            server_default=sa.text("0"),
            nullable=False,
        ),
    )

    op.add_column(
        "users",
        sa.Column(
            "temporary_password_expires_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
    )


def downgrade() -> None:
    """
    Mengembalikan struktur tabel ke versi sebelumnya.
    """

    op.drop_column(
        "users",
        "temporary_password_expires_at",
    )

    op.drop_column(
        "users",
        "must_change_password",
    )
