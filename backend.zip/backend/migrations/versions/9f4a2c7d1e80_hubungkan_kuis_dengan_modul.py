"""hubungkan kuis dengan modul praktikum

Revision ID: 9f4a2c7d1e80
Revises: ee9d5c54a7fc
Create Date: 2026-11-21

Perubahan bersifat non-destruktif:
- menambah quizzes.module_id sebagai nullable;
- mempertahankan kuis lama dengan module_id NULL;
- mengganti batas unik dari (class_id, quiz_type) menjadi
  (module_id, quiz_type), sehingga setiap modul dapat memiliki
  satu Pre-Test dan satu Post-Test.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "9f4a2c7d1e80"
down_revision: Union[str, Sequence[str], None] = "ee9d5c54a7fc"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Nullable is intentional: existing quiz rows remain as legacy quizzes
    # until an assistant explicitly assigns them to a practicum module.
    op.add_column(
        "quizzes",
        sa.Column("module_id", sa.Integer(), nullable=True),
    )
    op.create_foreign_key(
        "fk_quizzes_module_id_practicum_modules",
        "quizzes",
        "practicum_modules",
        ["module_id"],
        ["id"],
        ondelete="SET NULL",
    )
    op.create_index(
        "ix_quizzes_module_id",
        "quizzes",
        ["module_id"],
        unique=False,
    )

    # NULL module_id values are allowed to repeat by MySQL/MariaDB and SQLite,
    # preserving all legacy quizzes while enforcing uniqueness for mapped ones.
    with op.batch_alter_table("quizzes") as batch_op:
        batch_op.drop_constraint("uq_quiz_class_type", type_="unique")
        batch_op.create_unique_constraint(
            "uq_quiz_module_type",
            ["module_id", "quiz_type"],
        )


def downgrade() -> None:
    # A downgrade would restore the old one-test-per-class rule. Refuse to
    # proceed if newer data violates that rule; never delete or merge quizzes.
    bind = op.get_bind()
    duplicates = bind.execute(
        sa.text(
            "SELECT class_id, quiz_type, COUNT(*) AS jumlah "
            "FROM quizzes GROUP BY class_id, quiz_type HAVING COUNT(*) > 1 "
            "LIMIT 1"
        )
    ).first()
    if duplicates:
        raise RuntimeError(
            "Downgrade dibatalkan: terdapat lebih dari satu kuis dengan "
            "jenis yang sama pada kelas yang sama. Tidak ada data yang dihapus."
        )

    with op.batch_alter_table("quizzes") as batch_op:
        batch_op.drop_constraint("uq_quiz_module_type", type_="unique")
        batch_op.create_unique_constraint(
            "uq_quiz_class_type",
            ["class_id", "quiz_type"],
        )

    op.drop_index("ix_quizzes_module_id", table_name="quizzes")
    op.drop_constraint(
        "fk_quizzes_module_id_practicum_modules",
        "quizzes",
        type_="foreignkey",
    )
    op.drop_column("quizzes", "module_id")
