
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa


# Identitas revision Alembic
revision: str = "47fd4c64a23d"
down_revision: Union[str, Sequence[str], None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Membuat tabel program studi dan pengguna."""

    # Tabel program studi
    op.create_table(
        "study_programs",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("code", sa.String(length=10), nullable=False),
        sa.Column("name", sa.String(length=100), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("code"),
        sa.UniqueConstraint("name"),
    )

    op.create_index(
        op.f("ix_study_programs_id"),
        "study_programs",
        ["id"],
        unique=False,
    )

    # Tabel pengguna
    op.create_table(
        "users",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("full_name", sa.String(length=150), nullable=False),
        sa.Column("username", sa.String(length=50), nullable=True),
        sa.Column("nim", sa.String(length=30), nullable=True),
        sa.Column("password_hash", sa.String(length=255), nullable=False),
        sa.Column("role", sa.String(length=30), nullable=False),
        sa.Column("study_program_id", sa.Integer(), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),

        # Validasi identitas berdasarkan role
        sa.CheckConstraint(
            """
            (
                role = 'mahasiswa'
                AND nim IS NOT NULL
                AND username IS NULL
                AND study_program_id IS NOT NULL
            )
            OR
            (
                role IN ('admin_developer', 'asisten_lab')
                AND username IS NOT NULL
                AND nim IS NULL
            )
            """,
            name="ck_users_role_identifier",
        ),

        # Validasi jenis role
        sa.CheckConstraint(
            "role IN ('admin_developer', 'asisten_lab', 'mahasiswa')",
            name="ck_users_valid_role",
        ),

        sa.ForeignKeyConstraint(
            ["study_program_id"],
            ["study_programs.id"],
        ),

        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("nim"),
        sa.UniqueConstraint("username"),
    )

    op.create_index(
        op.f("ix_users_id"),
        "users",
        ["id"],
        unique=False,
    )


def downgrade() -> None:
    """Menghapus tabel yang dibuat oleh migration ini."""

    op.drop_index(
        op.f("ix_users_id"),
        table_name="users",
    )

    op.drop_table("users")

    op.drop_index(
        op.f("ix_study_programs_id"),
        table_name="study_programs",
    )

    op.drop_table("study_programs")
