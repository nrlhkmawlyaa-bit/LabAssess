
from logging.config import fileConfig

from sqlalchemy import engine_from_config
from sqlalchemy import pool

from alembic import context

# Konfigurasi aplikasi LabAssess
from app.core.config import settings
from app.database.session import Base

# Import seluruh model agar tabel terdaftar
# pada Base.metadata

from app.models import (
    # Model akademik
    User,
    StudyProgram,
    Course,
    AcademicPeriod,
    CourseClass,

    # Model modul praktikum
    PracticumModule,
    PracticumModuleFile,

    # Model kuis
    Quiz,
    QuizQuestion,
    QuizOption,
    QuizAttempt,
    QuizAnswer,
    QuizGrade,
)


# =========================================================
# KONFIGURASI ALEMBIC
# =========================================================

config = context.config

# Mengambil konfigurasi logging dari alembic.ini
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Mengambil URL database dari file .env
config.set_main_option(
    "sqlalchemy.url",
    settings.database_url.replace("%", "%%"),
)

# Metadata seluruh model SQLAlchemy
target_metadata = Base.metadata


# =========================================================
# MIGRATION MODE OFFLINE
# =========================================================

def run_migrations_offline() -> None:
    """
    Menjalankan migration tanpa koneksi database langsung.
    SQL dibuat berdasarkan metadata dan konfigurasi database.
    """

    url = config.get_main_option("sqlalchemy.url")

    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
    )

    with context.begin_transaction():
        context.run_migrations()


# =========================================================
# MIGRATION MODE ONLINE
# =========================================================

def run_migrations_online() -> None:
    """
    Menjalankan migration dengan koneksi langsung
    ke database MySQL/MariaDB.
    """

    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:

        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
        )

        with context.begin_transaction():
            context.run_migrations()


# =========================================================
# EKSEKUSI MIGRATION
# =========================================================

if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
