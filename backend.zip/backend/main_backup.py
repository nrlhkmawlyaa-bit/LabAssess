
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings


# =========================================================
# IMPORT ROUTERS
# =========================================================

# Health Check
from app.api.health import router as health_router

# Autentikasi
from app.api.v1.endpoints.autentikasi import (
    router as autentikasi_router,
)

# Registrasi Mahasiswa
from app.api.v1.endpoints.registrasi import (
    router as registrasi_router,
)

# Pengujian Akses
from app.api.v1.endpoints.pengujian_akses import (
    router as pengujian_akses_router,
)

# Manajemen Asisten
from app.api.v1.endpoints.manajemen_asisten import (
    router as manajemen_asisten_router,
)

# Manajemen Pengguna
from app.api.v1.endpoints.manajemen_pengguna import (
    router as manajemen_pengguna_router,
)

# Manajemen Mata Kuliah
from app.api.v1.endpoints.manajemen_mata_kuliah import (
    router as manajemen_mata_kuliah_router,
)

# Manajemen Periode Akademik
from app.api.v1.endpoints.manajemen_periode_akademik import (
    router as manajemen_periode_akademik_router,
)

# Manajemen Kelas Perkuliahan
from app.api.v1.endpoints.manajemen_kelas_perkuliahan import (
    router as manajemen_kelas_perkuliahan_router,
)

# Manajemen Penempatan
from app.api.v1.endpoints.manajemen_penempatan import (
    router as manajemen_penempatan_router,
)

# Dashboard Asisten
from app.api.v1.endpoints.dashboard_asisten import (
    router as dashboard_asisten_router,
)

# Dashboard Mahasiswa
from app.api.v1.endpoints.dashboard_mahasiswa import (
    router as dashboard_mahasiswa_router,
)

# Manajemen Modul Praktikum Asisten
from app.api.v1.endpoints.manajemen_modul_praktikum import (
    router as manajemen_modul_praktikum_router,
)

# Manajemen File Modul Praktikum
from app.api.v1.endpoints.manajemen_file_modul_praktikum import (
    router as manajemen_file_modul_praktikum_router,
)

# Manajemen Kuis Asisten
from app.api.v1.endpoints.manajemen_kuis import (
    router as manajemen_kuis_router,
)

# Kuis Mahasiswa
from app.api.v1.endpoints.kuis_mahasiswa import (
    router as kuis_mahasiswa_router,
)

# Modul Mahasiswa
from app.api.v1.endpoints.modul_mahasiswa import (
    router as modul_mahasiswa_router,
)

# Rekap Nilai Asisten
from app.api.v1.endpoints.rekap_nilai import (
    router as rekap_nilai_router,
)


# =========================================================
# INISIALISASI FASTAPI
# =========================================================

app = FastAPI(
    title=settings.app_name,
    description="Laboratory Assessment System API",
    version="1.0.0",
)


# =========================================================
# KONFIGURASI CORS
# =========================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =========================================================
# PENDAFTARAN ROUTERS
# =========================================================

# Health Check
app.include_router(
    health_router,
)

# Autentikasi
app.include_router(
    autentikasi_router,
    prefix=settings.api_v1_prefix,
)

# Registrasi Mahasiswa
app.include_router(
    registrasi_router,
    prefix=settings.api_v1_prefix,
)

# Pengujian Akses
app.include_router(
    pengujian_akses_router,
    prefix=settings.api_v1_prefix,
)

# Manajemen Asisten
app.include_router(
    manajemen_asisten_router,
    prefix=settings.api_v1_prefix,
)

# Manajemen Pengguna
app.include_router(
    manajemen_pengguna_router,
    prefix=settings.api_v1_prefix,
)

# Manajemen Mata Kuliah
app.include_router(
    manajemen_mata_kuliah_router,
    prefix=settings.api_v1_prefix,
)

# Manajemen Periode Akademik
app.include_router(
    manajemen_periode_akademik_router,
    prefix=settings.api_v1_prefix,
)

# Manajemen Kelas Perkuliahan
app.include_router(
    manajemen_kelas_perkuliahan_router,
    prefix=settings.api_v1_prefix,
)

# Manajemen Penempatan
app.include_router(
    manajemen_penempatan_router,
    prefix=settings.api_v1_prefix,
)

# Dashboard Asisten
app.include_router(
    dashboard_asisten_router,
    prefix=settings.api_v1_prefix,
)

# Dashboard Mahasiswa
app.include_router(
    dashboard_mahasiswa_router,
    prefix=settings.api_v1_prefix,
)

# Manajemen Modul Praktikum Asisten
app.include_router(
    manajemen_modul_praktikum_router,
    prefix=settings.api_v1_prefix,
)

# Manajemen File Modul Praktikum
app.include_router(
    manajemen_file_modul_praktikum_router,
    prefix=settings.api_v1_prefix,
)

# Manajemen Kuis Asisten
app.include_router(
    manajemen_kuis_router,
    prefix=settings.api_v1_prefix,
)

# Kuis Mahasiswa
app.include_router(
    kuis_mahasiswa_router,
    prefix=settings.api_v1_prefix,
)

# Modul Mahasiswa
app.include_router(
    modul_mahasiswa_router,
    prefix=settings.api_v1_prefix,
)

# Rekap Nilai Asisten
app.include_router(
    rekap_nilai_router,
    prefix=settings.api_v1_prefix,
)


# =========================================================
# ROOT ENDPOINT
# =========================================================

@app.get("/")
def root():
    return {
        "message": "LabAssess API is running",
        "version": "1.0.0",
    }
