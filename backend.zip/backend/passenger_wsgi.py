import os
import sys
from pathlib import Path
from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parent
os.chdir(BACKEND_DIR)
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

load_dotenv(BACKEND_DIR / ".env")

from a2wsgi import ASGIMiddleware
from app.main import app

asgi_app = ASGIMiddleware(app)

def application(environ, start_response):
    script_name = environ.get("SCRIPT_NAME", "")
    path_info = environ.get("PATH_INFO", "")
    if path_info in ("", "/"):
        environ["PATH_INFO"] = "/"
        environ["SCRIPT_NAME"] = ""
    elif path_info.startswith("/health"):
        environ["PATH_INFO"] = path_info
        environ["SCRIPT_NAME"] = ""
    elif script_name and not path_info.startswith(script_name):
        environ["PATH_INFO"] = script_name + path_info
        environ["SCRIPT_NAME"] = ""
    return asgi_app(environ, start_response)
