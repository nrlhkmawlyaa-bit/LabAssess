
const API_BASE_URL = "/api/v1";

async function requestAPI(path, token, options = {}) {
  const isFormData = options.body instanceof FormData;

  const headers = {
    Accept: "application/json",
    Authorization: `Bearer ${token}`,
    ...options.headers,
  };

  // FormData tidak boleh diberi Content-Type manual.
  if (options.body && !isFormData) {
    headers["Content-Type"] = "application/json";
  }

  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const detail = data.detail;

    if (typeof detail === "string") {
      throw new Error(detail);
    }

    if (Array.isArray(detail)) {
      throw new Error(
        detail.map((item) => item.msg).join(", ")
      );
    }

    throw new Error(
      detail?.pesan ||
      "Terjadi kesalahan saat menghubungi server."
    );
  }

  return data;
}

// ==========================================
// MATA KULIAH
// ==========================================

export async function ambilDaftarMataKuliah(
  token,
  { kataKunci = "", programStudiId = "" } = {}
) {
  const params = new URLSearchParams();

  if (kataKunci.trim()) {
    params.set("kata_kunci", kataKunci.trim());
  }

  if (programStudiId) {
    params.set("program_studi_id", String(programStudiId));
  }

  const query = params.toString();

  return requestAPI(
    `/admin/mata-kuliah/${query ? `?${query}` : ""}`,
    token
  );
}

export async function tambahMataKuliah(token, data) {
  return requestAPI("/admin/mata-kuliah/", token, {
    method: "POST",
    body: JSON.stringify(data),
  });
}

export async function ubahMataKuliah(token, id, data) {
  return requestAPI(`/admin/mata-kuliah/${id}`, token, {
    method: "PATCH",
    body: JSON.stringify(data),
  });
}

export async function hapusMataKuliah(token, id) {
  return requestAPI(`/admin/mata-kuliah/${id}`, token, {
    method: "DELETE",
  });
}

// ==========================================
// PERIODE AKADEMIK
// ==========================================

export async function ambilDaftarPeriodeAkademik(token) {
  return requestAPI("/admin/periode-akademik/", token);
}

// ==========================================
// KELAS PERKULIAHAN
// ==========================================

export async function ambilDaftarKelas(token) {
  return requestAPI("/admin/kelas-perkuliahan/", token);
}

export async function tambahKelas(token, data) {
  return requestAPI("/admin/kelas-perkuliahan/", token, {
    method: "POST",
    body: JSON.stringify(data),
  });
}

export async function ubahKelas(token, id, data) {
  return requestAPI(`/admin/kelas-perkuliahan/${id}`, token, {
    method: "PATCH",
    body: JSON.stringify(data),
  });
}

export async function hapusKelas(token, id) {
  return requestAPI(`/admin/kelas-perkuliahan/${id}`, token, {
    method: "DELETE",
  });
}

// ==========================================
// MANAJEMEN PENEMPATAN
// ==========================================

// GET: Daftar seluruh penempatan
export async function ambilDaftarPenempatan(token) {
  return requestAPI("/admin/penempatan/", token);
}

// GET: Detail penempatan kelas
export async function ambilDetailPenempatan(token, kelasId) {
  return requestAPI(
    `/admin/penempatan/kelas/${kelasId}`,
    token
  );
}

// GET: Daftar asisten aktif
export async function ambilDaftarAsistenPenempatan(token) {
  return requestAPI("/admin/penempatan/asisten", token);
}

// GET: Daftar mahasiswa aktif
export async function ambilDaftarMahasiswaPenempatan(token) {
  return requestAPI("/admin/penempatan/mahasiswa", token);
}

// POST: Tempatkan asisten
export async function tempatkanAsisten(
  token,
  kelasId,
  penggunaId
) {
  return requestAPI(
    `/admin/penempatan/kelas/${kelasId}/asisten`,
    token,
    {
      method: "POST",
      body: JSON.stringify({
        pengguna_id: penggunaId,
      }),
    }
  );
}

// DELETE: Hapus penempatan asisten
export async function hapusPenempatanAsisten(
  token,
  kelasId,
  asistenId
) {
  return requestAPI(
    `/admin/penempatan/kelas/${kelasId}/asisten/${asistenId}`,
    token,
    {
      method: "DELETE",
    }
  );
}

// POST: Tempatkan mahasiswa
export async function tempatkanMahasiswa(
  token,
  kelasId,
  penggunaId
) {
  return requestAPI(
    `/admin/penempatan/kelas/${kelasId}/mahasiswa`,
    token,
    {
      method: "POST",
      body: JSON.stringify({
        pengguna_id: penggunaId,
      }),
    }
  );
}

// DELETE: Hapus penempatan mahasiswa
export async function hapusPenempatanMahasiswa(
  token,
  kelasId,
  mahasiswaId
) {
  return requestAPI(
    `/admin/penempatan/kelas/${kelasId}/mahasiswa/${mahasiswaId}`,
    token,
    {
      method: "DELETE",
    }
  );
}

// ==========================================
// DASHBOARD ASISTEN
// ==========================================

// GET: Ringkasan dashboard asisten
export async function ambilDashboardAsisten(token) {
  return requestAPI("/asisten/dashboard", token);
}

// GET: Detail kelas dan daftar mahasiswa
export async function ambilDetailKelasAsisten(token, kelasId) {
  return requestAPI(`/asisten/kelas/${kelasId}`, token);
}

// ==========================================
// MANAJEMEN MODUL PRAKTIKUM ASISTEN
// ==========================================

// GET: Daftar modul berdasarkan kelas
export async function ambilDaftarModulPraktikum(
  token,
  kelasId
) {
  return requestAPI(
    `/asisten/modul-praktikum/kelas/${kelasId}`,
    token
  );
}

// POST: Tambah modul praktikum
export async function tambahModulPraktikum(
  token,
  kelasId,
  data
) {
  return requestAPI(
    `/asisten/modul-praktikum/kelas/${kelasId}`,
    token,
    {
      method: "POST",
      body: JSON.stringify(data),
    }
  );
}

// GET: Detail modul praktikum
export async function ambilDetailModulPraktikum(
  token,
  modulId
) {
  return requestAPI(
    `/asisten/modul-praktikum/${modulId}`,
    token
  );
}

// PATCH: Edit modul praktikum
export async function ubahModulPraktikum(
  token,
  modulId,
  data
) {
  return requestAPI(
    `/asisten/modul-praktikum/${modulId}`,
    token,
    {
      method: "PATCH",
      body: JSON.stringify(data),
    }
  );
}

// PATCH: Publikasikan modul
export async function publikasikanModulPraktikum(
  token,
  modulId
) {
  return requestAPI(
    `/asisten/modul-praktikum/${modulId}/publikasikan`,
    token,
    {
      method: "PATCH",
    }
  );
}

// PATCH: Tarik publikasi modul
export async function tarikPublikasiModulPraktikum(
  token,
  modulId
) {
  return requestAPI(
    `/asisten/modul-praktikum/${modulId}/tarik-publikasi`,
    token,
    {
      method: "PATCH",
    }
  );
}

// DELETE: Hapus modul praktikum
export async function hapusModulPraktikum(
  token,
  modulId
) {
  return requestAPI(
    `/asisten/modul-praktikum/${modulId}`,
    token,
    {
      method: "DELETE",
    }
  );
}

// ==========================================
// LAMPIRAN MODUL PRAKTIKUM ASISTEN
// ==========================================

// POST: Upload beberapa file ke satu modul.
// Backend menerima satu file per request.

export async function unggahFileModulPraktikum(
  token,
  modulId,
  daftarFile
) {
  const hasilUpload = [];

  for (const file of daftarFile) {
    const formData = new FormData();

    formData.append("file", file);

    const hasil = await requestAPI(
      `/asisten/modul-praktikum/${modulId}/files`,
      token,
      {
        method: "POST",
        body: formData,
      }
    );

    if (Array.isArray(hasil)) {
      hasilUpload.push(...hasil);
    } else {
      hasilUpload.push(hasil);
    }
  }

  return hasilUpload;
}

// GET: Ambil daftar lampiran modul.
export async function ambilDaftarFileModulPraktikum(
  token,
  modulId
) {
  return requestAPI(
    `/asisten/modul-praktikum/${modulId}/files`,
    token
  );
}

// DELETE: Hapus lampiran modul.
export async function hapusFileModulPraktikum(
  token,
  modulId,
  fileId
) {
  return requestAPI(
    `/asisten/modul-praktikum/${modulId}/files/${fileId}`,
    token,
    {
      method: "DELETE",
    }
  );
}

// GET: Download lampiran modul.
export async function unduhFileModulPraktikum(
  token,
  modulId,
  fileId,
  namaFile
) {
  const response = await fetch(
    `${API_BASE_URL}/asisten/modul-praktikum/${modulId}/files/${fileId}/download`,
    {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  if (!response.ok) {
    const data = await response.json().catch(() => ({}));

    throw new Error(
      data.detail || "Gagal mengunduh lampiran."
    );
  }

  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);

  const link = document.createElement("a");

  link.href = url;
  link.download = namaFile || "lampiran";
  document.body.appendChild(link);
  link.click();
  link.remove();

  window.URL.revokeObjectURL(url);
}

// ==========================================
// DASHBOARD MAHASISWA
// ==========================================

// GET: Ringkasan dashboard mahasiswa dan kelasnya
export async function ambilDashboardMahasiswa(token) {
  return requestAPI("/mahasiswa/dashboard", token);
}

// GET: Daftar modul yang dipublikasikan pada kelas mahasiswa
export async function ambilDaftarModulMahasiswa(
  token,
  kelasId
) {
  return requestAPI(
    `/mahasiswa/kelas/${kelasId}/modul`,
    token
  );
}

// GET: Detail modul praktikum mahasiswa
export async function ambilDetailModulMahasiswa(
  token,
  modulId
) {
  return requestAPI(
    `/mahasiswa/modul/${modulId}`,
    token
  );
}

// GET: Download lampiran modul mahasiswa
export async function unduhFileModulMahasiswa(
  token,
  modulId,
  fileId,
  namaFile
) {
  const response = await fetch(
    `${API_BASE_URL}/mahasiswa/modul/${modulId}/files/${fileId}/download`,
    {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  if (!response.ok) {
    let pesan = "Gagal mengunduh lampiran.";

    try {
      const data = await response.json();
      if (typeof data.detail === "string") {
        pesan = data.detail;
      }
    } catch {
      // Gunakan pesan default jika respons bukan JSON.
    }

    throw new Error(pesan);
  }

  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);

  const link = document.createElement("a");
  link.href = url;
  link.download = namaFile || "lampiran-modul";
  document.body.appendChild(link);
  link.click();
  link.remove();

  window.URL.revokeObjectURL(url);
}

// ==========================================
// SISTEM KUIS MAHASISWA
// ==========================================

// GET: Daftar Pre-Test dan Post-Test berdasarkan kelas
export async function ambilDaftarKuisMahasiswa(
  token,
  kelasId
) {
  return requestAPI(
    `/mahasiswa/kuis/kelas/${kelasId}`,
    token
  );
}

// GET: Detail kuis mahasiswa
export async function ambilDetailKuisMahasiswa(
  token,
  kuisId
) {
  return requestAPI(
    `/mahasiswa/kuis/${kuisId}`,
    token
  );
}

// POST: Memulai atau melanjutkan pengerjaan kuis
export async function mulaiKuisMahasiswa(
  token,
  kuisId
) {
  return requestAPI(
    `/mahasiswa/kuis/${kuisId}/mulai`,
    token,
    {
      method: "POST",
    }
  );
}

// PUT: Menyimpan jawaban mahasiswa
export async function simpanJawabanKuisMahasiswa(
  token,
  pengerjaanId,
  data
) {
  return requestAPI(
    `/mahasiswa/kuis/pengerjaan/${pengerjaanId}/jawaban`,
    token,
    {
      method: "PUT",
      body: JSON.stringify(data),
    }
  );
}

// POST: Mengumpulkan jawaban kuis
export async function kumpulkanKuisMahasiswa(
  token,
  pengerjaanId
) {
  return requestAPI(
    `/mahasiswa/kuis/pengerjaan/${pengerjaanId}/kumpulkan`,
    token,
    {
      method: "POST",
    }
  );
}


// MANAJEMEN PRE-TEST & POST-TEST ASISTEN
export async function ambilDaftarKuisAsisten(token, kelasId) { return requestAPI(`/asisten/kuis/kelas/${kelasId}`, token); }
export async function buatKuisAsisten(token, kelasId, data) { return requestAPI(`/asisten/kuis/kelas/${kelasId}`, token, { method: "POST", body: JSON.stringify({ ...data, class_id: Number(kelasId) }) }); }
export async function ambilDaftarSoalKuisAsisten(token, kuisId) { return requestAPI(`/asisten/kuis/${kuisId}/soal`, token); }
export async function tambahSoalKuisAsisten(token, kuisId, data) { return requestAPI(`/asisten/kuis/${kuisId}/soal`, token, { method: "POST", body: JSON.stringify(data) }); }
export async function ubahStatusKuisAsisten(token, kuisId, status) { return requestAPI(`/asisten/kuis/${kuisId}/status`, token, { method: "PATCH", body: JSON.stringify({ status }) }); }


export async function ubahSoalKuisAsisten(token, kuisId, soalId, data) {
  return requestAPI(`/asisten/kuis/${kuisId}/soal/${soalId}`, token, {
    method: "PATCH", body: JSON.stringify(data),
  });
}
export async function ubahOpsiSoalKuisAsisten(token, kuisId, soalId, options) {
  return requestAPI(`/asisten/kuis/${kuisId}/soal/${soalId}/opsi`, token, {
    method: "PUT", body: JSON.stringify(options),
  });
}
export async function hapusSoalKuisAsisten(token, kuisId, soalId) {
  return requestAPI(`/asisten/kuis/${kuisId}/soal/${soalId}`, token, {
    method: "DELETE",
  });
}


export async function resetPengerjaanMahasiswaAsisten(token, kuisId, mahasiswaId) {
  return requestAPI(`/asisten/kuis/${kuisId}/pengerjaan/mahasiswa/${mahasiswaId}`, token, {
    method: "DELETE",
  });
}


// ==========================================
// RIWAYAT NILAI MAHASISWA
// ==========================================

// GET: Mengambil riwayat nilai mahasiswa yang sedang login
export async function ambilRiwayatNilaiMahasiswa(token) {
  return requestAPI(
    "/mahasiswa/kuis/riwayat-nilai",
    token
  );
}


// ==========================================
// NILAI MAHASISWA UNTUK ASISTEN
// ==========================================

// GET: Mengambil daftar pengerjaan mahasiswa dalam satu kuis
export async function ambilDaftarPengerjaanKuisAsisten(
  token,
  kuisId
) {
  return requestAPI(
    `/asisten/kuis/${kuisId}/pengerjaan`,
    token
  );
}


// GET: Mengambil detail pengerjaan mahasiswa
export async function ambilDetailPengerjaanKuisAsisten(
  token,
  kuisId,
  pengerjaanId
) {
  return requestAPI(
    `/asisten/kuis/${kuisId}/pengerjaan/${pengerjaanId}`,
    token
  );
}


// ==========================================
// REKAP NILAI ASISTEN LAB
// ==========================================

// GET: Daftar program studi pada kelas asisten
export async function ambilProgramStudiRekapNilai(token) {
  return requestAPI(
    "/asisten/rekap-nilai/program-studi",
    token
  );
}

// GET: Rekap nilai per kuis
export async function ambilRekapNilaiPerKuis(
  token,
  programStudiId = ""
) {
  const params = new URLSearchParams();

  if (programStudiId) {
    params.set("program_studi_id", programStudiId);
  }

  const query = params.toString();

  return requestAPI(
    `/asisten/rekap-nilai/per-kuis${query ? `?${query}` : ""}`,
    token
  );
}

// GET: Rekap nilai gabungan Pre-Test dan Post-Test
export async function ambilRekapNilaiGabungan(
  token,
  programStudiId = ""
) {
  const params = new URLSearchParams();

  if (programStudiId) {
    params.set("program_studi_id", programStudiId);
  }

  const query = params.toString();

  return requestAPI(
    `/asisten/rekap-nilai/gabungan${query ? `?${query}` : ""}`,
    token
  );
}

// GET: Ekspor rekap nilai ke Excel
export async function eksporRekapNilai(
  token,
  jenis,
  programStudiId = ""
) {
  const endpoint = jenis === "gabungan"
    ? "gabungan"
    : "per-kuis";

  const params = new URLSearchParams();

  if (programStudiId) {
    params.set("program_studi_id", programStudiId);
  }

  const query = params.toString();

  const response = await fetch(
    `/api/v1/asisten/rekap-nilai/export/${endpoint}${query ? `?${query}` : ""}`,
    {
      method: "GET",
      headers: {
        Accept: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        Authorization: `Bearer ${token}`,
      },
    }
  );

  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(
      data.detail || "Gagal mengunduh rekap nilai."
    );
  }

  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = `rekap_nilai_${endpoint}.xlsx`;

  document.body.appendChild(link);
  link.click();
  link.remove();

  window.URL.revokeObjectURL(url);
}
