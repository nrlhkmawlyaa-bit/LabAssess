
const API_BASE_URL = "/api/v1";

/* ==========================================
   HELPER REQUEST API
========================================== */

async function requestAPI(url, options = {}) {
  const response = await fetch(url, options);

  const hasil = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(
      typeof hasil.detail === "string"
        ? hasil.detail
        : "Terjadi kesalahan saat menghubungi server."
    );
  }

  return hasil;
}

function headerOtentikasi(token, json = false) {
  if (!token) {
    throw new Error(
      "Sesi login tidak ditemukan. Silakan login kembali."
    );
  }

  return {
    Authorization: `Bearer ${token}`,
    Accept: "application/json",
    ...(json ? { "Content-Type": "application/json" } : {}),
  };
}

/* ==========================================
   DAFTAR PENGGUNA
========================================== */

export async function ambilDaftarPengguna({
  token,
  role = "",
  programStudiId = "",
  statusAktif = "",
  kataKunci = "",
  halaman = 1,
  batas = 10,
}) {
  const parameter = new URLSearchParams();

  if (role) parameter.set("role", role);

  if (programStudiId) {
    parameter.set("program_studi_id", programStudiId);
  }

  if (statusAktif !== "") {
    parameter.set("status_aktif", statusAktif);
  }

  if (kataKunci.trim()) {
    parameter.set("kata_kunci", kataKunci.trim());
  }

  parameter.set("halaman", String(halaman));
  parameter.set("batas", String(batas));

  return requestAPI(
    `${API_BASE_URL}/admin/pengguna/?${parameter.toString()}`,
    {
      method: "GET",
      headers: headerOtentikasi(token),
    }
  );
}

/* ==========================================
   DETAIL PENGGUNA
========================================== */

export async function ambilDetailPengguna({
  token,
  idPengguna,
}) {
  return requestAPI(
    `${API_BASE_URL}/admin/pengguna/${idPengguna}`,
    {
      method: "GET",
      headers: headerOtentikasi(token),
    }
  );
}

/* ==========================================
   EDIT INFORMASI PENGGUNA
========================================== */

export async function editInformasiPengguna({
  token,
  idPengguna,
  data,
}) {
  return requestAPI(
    `${API_BASE_URL}/admin/pengguna/${idPengguna}`,
    {
      method: "PATCH",
      headers: headerOtentikasi(token, true),
      body: JSON.stringify(data),
    }
  );
}

/* ==========================================
   AKTIFKAN / NONAKTIFKAN PENGGUNA
========================================== */

export async function ubahStatusPengguna({
  token,
  idPengguna,
  aktif,
}) {
  return requestAPI(
    `${API_BASE_URL}/admin/pengguna/${idPengguna}/status`,
    {
      method: "PATCH",
      headers: headerOtentikasi(token, true),
      body: JSON.stringify({ aktif }),
    }
  );
}

/* ==========================================
   RESET PASSWORD PENGGUNA
========================================== */

export async function resetPasswordPengguna({
  token,
  idPengguna,
}) {
  return requestAPI(
    `${API_BASE_URL}/admin/pengguna/${idPengguna}/reset-password`,
    {
      method: "POST",
      headers: headerOtentikasi(token),
    }
  );
}

/* ==========================================
   TAMBAH AKUN ASISTEN LAB
========================================== */

export async function buatAkunAsisten({
  token,
  nama_lengkap,
  username,
  password,
}) {
  return requestAPI(
    `${API_BASE_URL}/admin/asisten/`,
    {
      method: "POST",
      headers: headerOtentikasi(token, true),
      body: JSON.stringify({
        nama_lengkap,
        username,
        password,
      }),
    }
  );
}
