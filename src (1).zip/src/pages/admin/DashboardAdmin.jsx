
import { useState } from "react";

import {
  Monitor,
  LayoutDashboard,
  Users,
  BookOpen,
  GraduationCap,
  LogOut,
  Menu,
  X,
} from "lucide-react";

import OverviewAdmin from "./OverviewAdmin.jsx";
import ManajemenPengguna from "./ManajemenPengguna.jsx";
import MataKuliah from "./MataKuliah.jsx";
import Penempatan from "./Penempatan.jsx";

import "../../styles/admin.css";

const MENU_ADMIN = [
  {
    id: "overview",
    label: "Overview",
    icon: LayoutDashboard,
  },
  {
    id: "pengguna",
    label: "Pengguna",
    icon: Users,
  },
  {
    id: "mata-kuliah",
    label: "Mata Kuliah",
    icon: BookOpen,
  },
  {
    id: "penempatan",
    label: "Penempatan",
    icon: GraduationCap,
  },
];

export default function DashboardAdmin({
  pengguna,
  token,
  onLogout,
}) {
  const [menuAktif, setMenuAktif] = useState("overview");

  const [menuMobileTerbuka, setMenuMobileTerbuka] =
    useState(false);

  function pilihMenu(id) {
    setMenuAktif(id);
    setMenuMobileTerbuka(false);
  }

  function renderHalaman() {
    switch (menuAktif) {
      case "overview":
        return (
          <OverviewAdmin
            pengguna={pengguna}
            token={token}
            onNavigate={pilihMenu}
          />
        );

      case "pengguna":
        return (
          <ManajemenPengguna token={token} />
        );

      case "mata-kuliah":
        return (
          <MataKuliah token={token} />
        );

      case "penempatan":
        return (
          <Penempatan token={token} />
        );

      default:
        return (
          <OverviewAdmin
            pengguna={pengguna}
            token={token}
            onNavigate={pilihMenu}
          />
        );
    }
  }

  return (
    <main className="admin-dashboard">
      <div className="admin-background-decoration admin-decoration-one" />
      <div className="admin-background-decoration admin-decoration-two" />

      {/* HEADER ADMIN */}

      <header className="admin-topbar">
        <a className="admin-brand" href="#overview">
          <span className="admin-brand-icon">
          <Monitor size={23} strokeWidth={2} />
        </span>

          <span className="admin-brand-name">
            LabAssess
            <small>LABORATORY SYSTEM</small>
          </span>
        </a>

        <div className="admin-topbar-right">
          <div className="admin-user-profile">
            <div className="admin-avatar">
              {(pengguna?.nama_lengkap || "A")
                .charAt(0)
                .toUpperCase()}
            </div>

            <div className="admin-user-detail">
              <strong>
                {pengguna?.nama_lengkap || "Administrator"}
              </strong>
              <span>Administrator</span>
            </div>
          </div>

          <button
            className="admin-logout-button"
            onClick={onLogout}
            title="Keluar dari akun"
            type="button"
          >
            <LogOut size={17} />
            <span>Keluar</span>
          </button>

          <button
            className="admin-mobile-menu-button"
            onClick={() =>
              setMenuMobileTerbuka((nilai) => !nilai)
            }
            aria-label="Buka navigasi"
            aria-expanded={menuMobileTerbuka}
            type="button"
          >
            {menuMobileTerbuka ? (
              <X size={21} />
            ) : (
              <Menu size={21} />
            )}
          </button>
        </div>
      </header>

      {/* NAVIGASI ADMIN */}

      <div className="admin-navigation-wrapper">
        <nav
          className={`admin-navigation ${
            menuMobileTerbuka ? "mobile-open" : ""
          }`}
        >
          {MENU_ADMIN.map((item) => {
            const Icon = item.icon;
            const aktif = menuAktif === item.id;

            return (
              <button
                key={item.id}
                className={`admin-nav-item ${
                  aktif ? "active" : ""
                }`}
                onClick={() => pilihMenu(item.id)}
                type="button"
                aria-current={aktif ? "page" : undefined}
              >
                <Icon size={17} strokeWidth={2} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* KONTEN HALAMAN */}

      <div className="admin-main-content">
        {renderHalaman()}
      </div>

      {/* FOOTER */}

      <footer className="admin-footer">
        <span>© 2026 LabAssess · STITEK Bontang</span>
        <span>Administrator Workspace</span>
      </footer>
    </main>
  );
}
