
import { useEffect, useMemo, useState } from "react";

import {
  BookOpen,
  CalendarDays,
  Users,
  GraduationCap,
  Plus,
  Search,
  RefreshCw,
  Pencil,
  Trash2,
  X,
  CheckCircle2,
  AlertCircle,
  Layers3,
  UserRoundPlus,
} from "lucide-react";

import {
  ambilDaftarMataKuliah,
  ambilDaftarPeriodeAkademik,
  ambilDaftarPenempatan,
  ambilDetailPenempatan,
  ambilDaftarAsistenPenempatan,
  ambilDaftarMahasiswaPenempatan,
  tempatkanAsisten,
  hapusPenempatanAsisten,
  tempatkanMahasiswa,
  hapusPenempatanMahasiswa,
  tambahKelas,
  ubahKelas,
  hapusKelas,
} from "../../services/academicService";

import "../../styles/penempatan.css";

const PROGRAM_STUDI = [
  { id: 1, nama: "Teknik Informatika" },
  { id: 2, nama: "Sistem Informasi" },
  { id: 3, nama: "Bisnis Digital" },
  { id: 4, nama: "Teknik Elektro" },
  { id: 5, nama: "Teknik Lingkungan" },
  { id: 6, nama: "Teknik Industri" },
];

function namaProgramStudi(programStudiId) {
  if (programStudiId === null || programStudiId === undefined) {
    return "Belum diatur";
  }

  return (
    PROGRAM_STUDI.find((program) => program.id === Number(programStudiId))
      ?.nama || `Program Studi #${programStudiId}`
  );
}

const FORM_AWAL = {
  course_id: "",
  academic_period_id: "",
  class_code: "",
};

export default function Penempatan({ token }) {
  // ==========================================
  // STATE DATA
  // ==========================================

  const [kelas, setKelas] = useState([]);
  const [mataKuliah, setMataKuliah] = useState([]);
  const [periode, setPeriode] = useState([]);

  const [loading, setLoading] = useState(true);
  const [menyimpan, setMenyimpan] = useState(false);

  // ==========================================
  // STATE FILTER
  // ==========================================

  const [kataKunci, setKataKunci] = useState("");
  const [filterPeriode, setFilterPeriode] = useState("");

  // ==========================================
  // STATE MODAL KELAS
  // ==========================================

  const [modalTerbuka, setModalTerbuka] = useState(false);
  const [kelasDiedit, setKelasDiedit] = useState(null);
  const [form, setForm] = useState(FORM_AWAL);

  // ==========================================
  // STATE MODAL PENEMPATAN
  // ==========================================

  const [modalPenempatanTerbuka, setModalPenempatanTerbuka] =
    useState(false);

  const [kelasTerpilih, setKelasTerpilih] = useState(null);

  const [tabPenempatan, setTabPenempatan] = useState("asisten");

  const [daftarAsisten, setDaftarAsisten] = useState([]);
  const [daftarMahasiswa, setDaftarMahasiswa] = useState([]);

  const [idPenggunaTerpilih, setIdPenggunaTerpilih] = useState([]);
  const [kataKunciPenempatan, setKataKunciPenempatan] = useState("");
  const [filterProdiPenempatan, setFilterProdiPenempatan] = useState("");

  const [loadingPenempatan, setLoadingPenempatan] = useState(false);
  const [menyimpanPenempatan, setMenyimpanPenempatan] = useState(false);

  // ==========================================
  // STATE NOTIFIKASI
  // ==========================================

  const [pesan, setPesan] = useState("");
  const [jenisPesan, setJenisPesan] = useState("success");

  // ==========================================
  // NOTIFIKASI
  // ==========================================

  function tampilkanPesan(teks, jenis = "success") {
    setPesan(teks);
    setJenisPesan(jenis);
  }

  // ==========================================
  // MUAT DATA
  // ==========================================

  async function muatData() {
    setLoading(true);

    try {
      const [dataKelas, dataMataKuliah, dataPeriode] =
        await Promise.all([
          ambilDaftarPenempatan(token),
          ambilDaftarMataKuliah(token),
          ambilDaftarPeriodeAkademik(token),
        ]);

      setKelas(Array.isArray(dataKelas) ? dataKelas : []);
      setMataKuliah(
        Array.isArray(dataMataKuliah) ? dataMataKuliah : []
      );
      setPeriode(Array.isArray(dataPeriode) ? dataPeriode : []);
    } catch (error) {
      tampilkanPesan(error.message, "error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    muatData();
  }, [token]);

  // ==========================================
  // DATA KELAS
  // ==========================================

  const daftarKelas = useMemo(() => {
    return kelas
      .map((item) => {
        const course = mataKuliah.find(
          (mk) => mk.id === item.course_id
        );

        const academicPeriod = periode.find(
          (p) => p.id === item.academic_period_id
        );

        return {
          ...item,
          namaMataKuliah:
            course?.nama || `Mata kuliah #${item.course_id}`,
          kodeMataKuliah: course?.kode || "-",
          sks: course?.sks ?? "-",
          namaPeriode: academicPeriod
            ? `${academicPeriod.academic_year} - ${academicPeriod.semester}`
            : `Periode #${item.academic_period_id}`,
          jumlahAsisten: item.asisten?.length || 0,
          jumlahMahasiswa: item.mahasiswa?.length || 0,
        };
      })
      .filter((item) => {
        const kata = kataKunci.toLowerCase();

        const cocokKataKunci =
          item.namaMataKuliah.toLowerCase().includes(kata) ||
          item.class_code.toLowerCase().includes(kata) ||
          item.kodeMataKuliah.toLowerCase().includes(kata);

        const cocokPeriode =
          !filterPeriode ||
          String(item.academic_period_id) === filterPeriode;

        return cocokKataKunci && cocokPeriode;
      });
  }, [kelas, mataKuliah, periode, kataKunci, filterPeriode]);

  // ==========================================
  // STATISTIK
  // ==========================================

  const statistik = useMemo(
    () => ({
      total: kelas.length,
      aktif: kelas.filter((item) => item.is_active).length,

      asisten: kelas.reduce(
        (total, item) => total + (item.asisten?.length || 0),
        0
      ),

      mahasiswa: kelas.reduce(
        (total, item) => total + (item.mahasiswa?.length || 0),
        0
      ),
    }),
    [kelas]
  );

  // ==========================================
  // TAMBAH KELAS
  // ==========================================

  function bukaTambah() {
    setKelasDiedit(null);
    setForm(FORM_AWAL);
    setModalTerbuka(true);
    setPesan("");
  }

  // ==========================================
  // EDIT KELAS
  // ==========================================

  function bukaEdit(item) {
    setKelasDiedit(item);

    setForm({
      course_id: String(item.course_id),
      academic_period_id: String(item.academic_period_id),
      class_code: item.class_code,
    });

    setModalTerbuka(true);
    setPesan("");
  }

  // ==========================================
  // TUTUP MODAL KELAS
  // ==========================================

  function tutupModal() {
    if (menyimpan) return;

    setModalTerbuka(false);
    setKelasDiedit(null);
    setForm(FORM_AWAL);
  }

  // ==========================================
  // SIMPAN KELAS
  // ==========================================

  async function simpanKelas(event) {
    event.preventDefault();

    if (!form.course_id || !form.academic_period_id) {
      tampilkanPesan(
        "Mata kuliah dan periode akademik wajib dipilih.",
        "error"
      );
      return;
    }

    if (!form.class_code.trim()) {
      tampilkanPesan("Kode kelas wajib diisi.", "error");
      return;
    }

    setMenyimpan(true);
    setPesan("");

    const data = {
      course_id: Number(form.course_id),
      academic_period_id: Number(form.academic_period_id),
      class_code: form.class_code.trim(),
    };

    try {
      if (kelasDiedit) {
        await ubahKelas(token, kelasDiedit.id, data);
      } else {
        await tambahKelas(token, data);
      }

      setModalTerbuka(false);
      setKelasDiedit(null);
      setForm(FORM_AWAL);

      tampilkanPesan(
        kelasDiedit
          ? "Kelas berhasil diperbarui."
          : "Kelas berhasil ditambahkan."
      );

      await muatData();
    } catch (error) {
      tampilkanPesan(error.message, "error");
    } finally {
      setMenyimpan(false);
    }
  }

  // ==========================================
  // UBAH STATUS KELAS
  // ==========================================

  async function ubahStatus(item) {
    const statusBaru = !item.is_active;

    const konfirmasi = window.confirm(
      statusBaru
        ? `Aktifkan kelas ${item.class_code}?`
        : `Nonaktifkan kelas ${item.class_code}?`
    );

    if (!konfirmasi) return;

    try {
      await ubahKelas(token, item.id, {
        is_active: statusBaru,
      });

      tampilkanPesan(
        statusBaru
          ? "Kelas berhasil diaktifkan."
          : "Kelas berhasil dinonaktifkan."
      );

      await muatData();
    } catch (error) {
      tampilkanPesan(error.message, "error");
    }
  }

  // ==========================================
  // HAPUS KELAS
  // ==========================================

  async function hapusData(item) {
    const konfirmasi = window.confirm(
      `Yakin ingin menghapus kelas ${item.class_code}?\n\nKelas yang masih memiliki asisten atau mahasiswa tidak dapat dihapus.`
    );

    if (!konfirmasi) return;

    try {
      await hapusKelas(token, item.id);

      tampilkanPesan("Kelas berhasil dihapus.");
      await muatData();
    } catch (error) {
      tampilkanPesan(error.message, "error");
    }
  }

  // ==========================================
  // BUKA MODAL PENEMPATAN
  // ==========================================

  async function bukaModalPenempatan(item) {
    setKelasTerpilih(item);
    setTabPenempatan("asisten");
    setModalPenempatanTerbuka(true);
    setLoadingPenempatan(true);
    setPesan("");

    try {
      const [detail, asisten, mahasiswa] = await Promise.all([
        ambilDetailPenempatan(token, item.id),
        ambilDaftarAsistenPenempatan(token),
        ambilDaftarMahasiswaPenempatan(token),
      ]);

      setKelasTerpilih(detail);
      setDaftarAsisten(Array.isArray(asisten) ? asisten : []);
      setDaftarMahasiswa(
        Array.isArray(mahasiswa) ? mahasiswa : []
      );
      setIdPenggunaTerpilih(
        (detail.asisten || []).map((item) => item.id)
      );
      setKataKunciPenempatan("");
      setFilterProdiPenempatan("");
    } catch (error) {
      tampilkanPesan(error.message, "error");
    } finally {
      setLoadingPenempatan(false);
    }
  }

  // ==========================================
  // TUTUP MODAL PENEMPATAN
  // ==========================================

  function tutupModalPenempatan() {
    if (menyimpanPenempatan) return;

    setModalPenempatanTerbuka(false);
    setKelasTerpilih(null);
    setIdPenggunaTerpilih([]);
    setKataKunciPenempatan("");
    setFilterProdiPenempatan("");
    setPesan("");
  }

  // ==========================================
  // PILIH / SIMPAN PENEMPATAN MASSAL
  // ==========================================

  function pilihSemuaPengguna(checked, daftar) {
    const idsTerlihat = daftar.map((item) => item.id);

    setIdPenggunaTerpilih((sebelumnya) => {
      if (checked) {
        return [...new Set([...sebelumnya, ...idsTerlihat])];
      }

      return sebelumnya.filter((id) => !idsTerlihat.includes(id));
    });
  }

  function ubahPilihanPengguna(id, checked) {
    setIdPenggunaTerpilih((sebelumnya) => {
      if (checked) {
        return [...new Set([...sebelumnya, id])];
      }

      return sebelumnya.filter((item) => item !== id);
    });
  }

  async function simpanPenempatan(event) {
    event.preventDefault();
    if (!kelasTerpilih) return;

    const daftarSaatIni =
      tabPenempatan === "asisten"
        ? kelasTerpilih.asisten || []
        : kelasTerpilih.mahasiswa || [];

    const idsSaatIni = daftarSaatIni.map((item) => item.id);
    const idsTambah = idPenggunaTerpilih.filter(
      (id) => !idsSaatIni.includes(id)
    );
    const idsHapus = idsSaatIni.filter(
      (id) => !idPenggunaTerpilih.includes(id)
    );

    if (idsTambah.length === 0 && idsHapus.length === 0) {
      tampilkanPesan("Tidak ada perubahan penempatan.", "error");
      return;
    }

    setMenyimpanPenempatan(true);
    setPesan("");

    let berhasil = 0;
    const gagal = [];

    try {
      for (const id of idsTambah) {
        try {
          if (tabPenempatan === "asisten") {
            await tempatkanAsisten(token, kelasTerpilih.id, id);
          } else {
            await tempatkanMahasiswa(token, kelasTerpilih.id, id);
          }
          berhasil += 1;
        } catch (error) {
          gagal.push(error.message || `Gagal menambahkan ID ${id}`);
        }
      }

      for (const id of idsHapus) {
        try {
          if (tabPenempatan === "asisten") {
            await hapusPenempatanAsisten(token, kelasTerpilih.id, id);
          } else {
            await hapusPenempatanMahasiswa(token, kelasTerpilih.id, id);
          }
          berhasil += 1;
        } catch (error) {
          gagal.push(error.message || `Gagal menghapus ID ${id}`);
        }
      }

      const detail = await ambilDetailPenempatan(
        token,
        kelasTerpilih.id
      );
      setKelasTerpilih(detail);

      const idsTerbaru =
        tabPenempatan === "asisten"
          ? (detail.asisten || []).map((item) => item.id)
          : (detail.mahasiswa || []).map((item) => item.id);

      setIdPenggunaTerpilih(idsTerbaru);
      await muatData();

      if (gagal.length > 0) {
        tampilkanPesan(
          `${berhasil} perubahan berhasil. ${gagal.length} gagal: ${gagal[0]}`,
          "error"
        );
      } else {
        tampilkanPesan(
          `${berhasil} perubahan penempatan berhasil disimpan.`
        );
      }
    } catch (error) {
      tampilkanPesan(error.message, "error");
    } finally {
      setMenyimpanPenempatan(false);
    }
  }

  // ==========================================
  // HAPUS PENEMPATAN
  // ==========================================

  async function hapusPenempatan(pengguna) {
    if (!kelasTerpilih) return;

    const jenis =
      tabPenempatan === "asisten" ? "asisten" : "mahasiswa";

    const konfirmasi = window.confirm(
      `Hapus ${pengguna.nama} dari kelas ${kelasTerpilih.class_code}?`
    );

    if (!konfirmasi) return;

    setMenyimpanPenempatan(true);
    setPesan("");

    try {
      if (tabPenempatan === "asisten") {
        await hapusPenempatanAsisten(
          token,
          kelasTerpilih.id,
          pengguna.id
        );
      } else {
        await hapusPenempatanMahasiswa(
          token,
          kelasTerpilih.id,
          pengguna.id
        );
      }

      const detail = await ambilDetailPenempatan(
        token,
        kelasTerpilih.id
      );

      setKelasTerpilih(detail);

      tampilkanPesan(
        `Penempatan ${jenis} berhasil dihapus.`
      );

      await muatData();
    } catch (error) {
      tampilkanPesan(error.message, "error");
    } finally {
      setMenyimpanPenempatan(false);
    }
  }

  // ==========================================
  // DAFTAR PENGGUNA PADA TAB AKTIF
  // ==========================================

  const penggunaTersedia =
    tabPenempatan === "asisten"
      ? daftarAsisten
      : daftarMahasiswa;

  const penggunaDiKelas =
    tabPenempatan === "asisten"
      ? kelasTerpilih?.asisten || []
      : kelasTerpilih?.mahasiswa || [];

  // ==========================================
  // TAMPILAN
  // ==========================================

  return (
    <section className="pt-page">
      {/* HEADER */}

      <div className="pt-heading">
        <div className="pt-heading-icon">
          <GraduationCap size={27} />
        </div>

        <div>
          <span className="pt-eyebrow">
            ADMINISTRASI AKADEMIK
          </span>

          <h1>Manajemen Penempatan</h1>

          <p>
            Kelola kelas perkuliahan, asisten laboratorium,
            dan mahasiswa dalam satu tempat.
          </p>
        </div>
      </div>

      {/* ALERT */}

      {pesan && !modalTerbuka && !modalPenempatanTerbuka && (
        <div className={`pt-alert ${jenisPesan}`}>
          {jenisPesan === "success" ? (
            <CheckCircle2 size={17} />
          ) : (
            <AlertCircle size={17} />
          )}

          <span>{pesan}</span>

          <button
            type="button"
            onClick={() => setPesan("")}
            aria-label="Tutup pesan"
          >
            <X size={16} />
          </button>
        </div>
      )}

      {/* STATISTIK */}

      <div className="pt-stat-grid">
        <article className="pt-stat-card">
          <div className="pt-stat-icon">
            <Layers3 size={21} />
          </div>

          <div>
            <span>Total Kelas</span>
            <strong>{loading ? "—" : statistik.total}</strong>
          </div>
        </article>

        <article className="pt-stat-card">
          <div className="pt-stat-icon">
            <CheckCircle2 size={21} />
          </div>

          <div>
            <span>Kelas Aktif</span>
            <strong>{loading ? "—" : statistik.aktif}</strong>
          </div>
        </article>

        <article className="pt-stat-card">
          <div className="pt-stat-icon">
            <Users size={21} />
          </div>

          <div>
            <span>Total Penempatan Asisten</span>
            <strong>{loading ? "—" : statistik.asisten}</strong>
          </div>
        </article>

        <article className="pt-stat-card">
          <div className="pt-stat-icon">
            <GraduationCap size={21} />
          </div>

          <div>
            <span>Total Mahasiswa Terdaftar</span>
            <strong>{loading ? "—" : statistik.mahasiswa}</strong>
          </div>
        </article>
      </div>

      {/* DAFTAR KELAS */}

      <div className="pt-content-card">
        <div className="pt-toolbar">
          <div>
            <h2>Daftar Kelas Perkuliahan</h2>

            <p>
              Kelola kelas berdasarkan mata kuliah dan periode akademik.
            </p>
          </div>

          <button
            type="button"
            className="pt-add-button"
            onClick={bukaTambah}
          >
            <Plus size={17} />
            Tambah Kelas
          </button>
        </div>

        {/* FILTER */}

        <div className="pt-filter-row">
          <div className="pt-search">
            <Search size={17} />

            <input
              type="text"
              placeholder="Cari mata kuliah atau kode kelas..."
              value={kataKunci}
              onChange={(event) =>
                setKataKunci(event.target.value)
              }
            />
          </div>

          <select
            value={filterPeriode}
            onChange={(event) =>
              setFilterPeriode(event.target.value)
            }
          >
            <option value="">Semua Periode</option>

            {periode.map((item) => (
              <option key={item.id} value={item.id}>
                {item.academic_year} - {item.semester}
              </option>
            ))}
          </select>

          <button
            type="button"
            className="pt-refresh-button"
            onClick={muatData}
            title="Muat ulang data"
            disabled={loading}
          >
            <RefreshCw
              size={17}
              className={loading ? "pt-spin" : ""}
            />
          </button>
        </div>

        {/* TABEL */}

        <div className="pt-table-wrapper">
          <table className="pt-table">
            <thead>
              <tr>
                <th>No.</th>
                <th>Mata Kuliah</th>
                <th>Kode Kelas</th>
                <th>Periode Akademik</th>
                <th>Asisten</th>
                <th>Mahasiswa</th>
                <th>Status</th>
                <th>Aksi</th>
              </tr>
            </thead>

            <tbody>
              {!loading &&
                daftarKelas.map((item, index) => (
                  <tr key={item.id}>
                    <td>{index + 1}</td>

                    <td>
                      <div className="pt-course-cell">
                        <strong>{item.namaMataKuliah}</strong>

                        <small>
                          {item.kodeMataKuliah} · {item.sks} SKS
                        </small>
                      </div>
                    </td>

                    <td>
                      <span className="pt-code">
                        {item.class_code}
                      </span>
                    </td>

                    <td>
                      <div className="pt-period-cell">
                        <CalendarDays size={15} />
                        {item.namaPeriode}
                      </div>
                    </td>

                    <td>
                      <span className="pt-count">
                        <Users size={14} />
                        {item.jumlahAsisten}
                      </span>
                    </td>

                    <td>
                      <span className="pt-count">
                        <GraduationCap size={15} />
                        {item.jumlahMahasiswa}
                      </span>
                    </td>

                    <td>
                      <button
                        type="button"
                        className={`pt-status ${
                          item.is_active ? "active" : "inactive"
                        }`}
                        onClick={() => ubahStatus(item)}
                      >
                        {item.is_active ? "Aktif" : "Nonaktif"}
                      </button>
                    </td>

                    <td>
                      <div className="pt-actions">
                        <button
                          type="button"
                          className="pt-manage-button"
                          title="Kelola penempatan"
                          onClick={() =>
                            bukaModalPenempatan(item)
                          }
                        >
                          <UserRoundPlus size={15} />
                        </button>

                        <button
                          type="button"
                          title="Edit kelas"
                          onClick={() => bukaEdit(item)}
                        >
                          <Pencil size={15} />
                        </button>

                        <button
                          type="button"
                          className="delete"
                          title="Hapus kelas"
                          onClick={() => hapusData(item)}
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>

          {loading && (
            <div className="pt-empty">
              <RefreshCw
                className="pt-spin"
                size={25}
              />
              <strong>Memuat data kelas...</strong>
              <p>Mohon tunggu sebentar.</p>
            </div>
          )}

          {!loading && daftarKelas.length === 0 && (
            <div className="pt-empty">
              <BookOpen size={30} />
              <strong>Belum ada kelas ditemukan</strong>
              <p>
                Tambahkan kelas baru atau ubah kata kunci pencarian.
              </p>
            </div>
          )}
        </div>

        <div className="pt-table-footer">
          Menampilkan {daftarKelas.length} dari {kelas.length} kelas.
        </div>
      </div>

      {/* MODAL TAMBAH / EDIT KELAS */}

      {modalTerbuka && (
        <div
          className="pt-modal-overlay"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              tutupModal();
            }
          }}
        >
          <div
            className="pt-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="pt-modal-title"
          >
            <div className="pt-modal-header">
              <div>
                <span className="pt-eyebrow">
                  PENGELOLAAN KELAS
                </span>

                <h2 id="pt-modal-title">
                  {kelasDiedit
                    ? "Edit Kelas"
                    : "Tambah Kelas Baru"}
                </h2>

                <p>
                  Lengkapi informasi kelas perkuliahan.
                </p>
              </div>

              <button
                type="button"
                onClick={tutupModal}
                disabled={menyimpan}
                aria-label="Tutup modal"
              >
                <X size={19} />
              </button>
            </div>

            <form onSubmit={simpanKelas}>
              <div className="pt-form-field">
                <label htmlFor="pt-course">
                  Mata Kuliah
                </label>

                <select
                  id="pt-course"
                  value={form.course_id}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      course_id: event.target.value,
                    })
                  }
                  required
                >
                  <option value="">
                    Pilih mata kuliah
                  </option>

                  {mataKuliah.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.kode} - {item.nama} ({item.sks} SKS)
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-form-field">
                <label htmlFor="pt-period">
                  Periode Akademik
                </label>

                <select
                  id="pt-period"
                  value={form.academic_period_id}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      academic_period_id: event.target.value,
                    })
                  }
                  required
                >
                  <option value="">
                    Pilih periode akademik
                  </option>

                  {periode.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.academic_year} - {item.semester}
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-form-field">
                <label htmlFor="pt-class-code">
                  Kode Kelas
                </label>

                <input
                  id="pt-class-code"
                  type="text"
                  value={form.class_code}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      class_code: event.target.value,
                    })
                  }
                  placeholder="Contoh: A, B, TI-01"
                  maxLength={20}
                  required
                />

                <small>
                  Maksimal 20 karakter. Kode kelas tidak boleh
                  sama pada mata kuliah dan periode yang sama.
                </small>
              </div>

              {pesan && jenisPesan === "error" && (
                <div className="pt-form-error">
                  <AlertCircle size={15} />
                  {pesan}
                </div>
              )}

              <div className="pt-modal-actions">
                <button
                  type="button"
                  className="pt-cancel-button"
                  onClick={tutupModal}
                  disabled={menyimpan}
                >
                  Batal
                </button>

                <button
                  type="submit"
                  className="pt-save-button"
                  disabled={menyimpan}
                >
                  {menyimpan
                    ? "Menyimpan..."
                    : kelasDiedit
                      ? "Simpan Perubahan"
                      : "Tambah Kelas"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL KELOLA PENEMPATAN */}

      {modalPenempatanTerbuka && kelasTerpilih && (
        <div
          className="pt-modal-overlay"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              tutupModalPenempatan();
            }
          }}
        >
          <div
            className="pt-modal pt-assignment-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="pt-assignment-title"
          >
            <div className="pt-modal-header">
              <div>
                <span className="pt-eyebrow">
                  PENGELOLAAN KELAS
                </span>

                <h2 id="pt-assignment-title">
                  Kelola Penempatan
                </h2>

                <p>
                  {kelasTerpilih.class_code} ·{" "}
                  {mataKuliah.find(
                    (item) =>
                      item.id === kelasTerpilih.course_id
                  )?.nama || "Mata Kuliah"}
                </p>
              </div>

              <button
                type="button"
                onClick={tutupModalPenempatan}
                disabled={menyimpanPenempatan}
                aria-label="Tutup modal"
              >
                <X size={19} />
              </button>
            </div>

            {/* TAB */}

            <div className="pt-assignment-tabs">
              <button
                type="button"
                className={
                  tabPenempatan === "asisten" ? "active" : ""
                }
                onClick={() => {
                  setTabPenempatan("asisten");
                  setIdPenggunaTerpilih(
                    (kelasTerpilih.asisten || []).map((item) => item.id)
                  );
                  setKataKunciPenempatan("");
                  setFilterProdiPenempatan("");
                  setPesan("");
                }}
              >
                <Users size={16} />
                Asisten Lab
                <span>
                  {kelasTerpilih.asisten?.length || 0}
                </span>
              </button>

              <button
                type="button"
                className={
                  tabPenempatan === "mahasiswa" ? "active" : ""
                }
                onClick={() => {
                  setTabPenempatan("mahasiswa");
                  setIdPenggunaTerpilih(
                    (kelasTerpilih.mahasiswa || []).map((item) => item.id)
                  );
                  setKataKunciPenempatan("");
                  setFilterProdiPenempatan("");
                  setPesan("");
                }}
              >
                <GraduationCap size={17} />
                Mahasiswa
                <span>
                  {kelasTerpilih.mahasiswa?.length || 0}
                </span>
              </button>
            </div>

            {loadingPenempatan ? (
              <div className="pt-empty">
                <RefreshCw
                  className="pt-spin"
                  size={25}
                />
                <strong>Memuat data penempatan...</strong>
                <p>Mohon tunggu sebentar.</p>
              </div>
            ) : (
              <>
                {/* PENCARIAN DAN FILTER PENGGUNA */}

                <div className="pt-bulk-toolbar">
                  <div className="pt-search pt-bulk-search">
                    <Search size={17} />
                    <input
                      type="text"
                      placeholder={
                        tabPenempatan === "mahasiswa"
                          ? "Cari nama atau NIM mahasiswa..."
                          : "Cari nama asisten..."
                      }
                      value={kataKunciPenempatan}
                      onChange={(event) =>
                        setKataKunciPenempatan(event.target.value)
                      }
                    />
                  </div>

                  {tabPenempatan === "mahasiswa" && (
                    <select
                      value={filterProdiPenempatan}
                      onChange={(event) =>
                        setFilterProdiPenempatan(event.target.value)
                      }
                      aria-label="Filter program studi"
                    >
                      <option value="">Semua Program Studi</option>
                      {PROGRAM_STUDI.map((program) => (
                        <option key={program.id} value={program.id}>
                          {program.nama}
                        </option>
                      ))}
                    </select>
                  )}
                </div>

                {(() => {
                  const daftarAktif = penggunaTersedia.filter((pengguna) => {
                    const kata = kataKunciPenempatan.trim().toLowerCase();
                    const cocokKata =
                      !kata ||
                      (pengguna.nama || "").toLowerCase().includes(kata) ||
                      (pengguna.nim || "").toLowerCase().includes(kata);
                    const cocokProdi =
                      !filterProdiPenempatan ||
                      String(pengguna.program_studi_id) === filterProdiPenempatan;
                    return cocokKata && cocokProdi;
                  });

                  const semuaTerpilih =
                    daftarAktif.length > 0 &&
                    daftarAktif.every((item) =>
                      idPenggunaTerpilih.includes(item.id)
                    );

                  return (
                    <div className="pt-bulk-panel">
                      <div className="pt-bulk-summary">
                        <div>
                          <h3>
                            {tabPenempatan === "mahasiswa"
                              ? "Daftar Seluruh Mahasiswa"
                              : "Daftar Seluruh Asisten"}
                          </h3>
                          <p>
                            Centang pengguna yang ingin dimasukkan ke kelas ini.
                            Pengguna yang sudah terdaftar akan tetap tercentang.
                          </p>
                        </div>
                        <span>
                          {idPenggunaTerpilih.length} dipilih
                        </span>
                      </div>

                      <div className="pt-bulk-select-all">
                        <label>
                          <input
                            type="checkbox"
                            checked={semuaTerpilih}
                            onChange={(event) =>
                              pilihSemuaPengguna(event.target.checked, daftarAktif)
                            }
                          />
                          <strong>Pilih semua yang ditampilkan</strong>
                        </label>
                        <small>{daftarAktif.length} pengguna ditemukan</small>
                      </div>

                      <div className="pt-bulk-table-wrap">
                        <table className="pt-bulk-table">
                          <thead>
                            <tr>
                              <th>Pilih</th>
                              <th>Nama</th>
                              <th>{tabPenempatan === "mahasiswa" ? "NIM" : "Peran"}</th>
                              {tabPenempatan === "mahasiswa" && <th>Program Studi</th>}
                              <th>Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {daftarAktif.map((pengguna) => {
                              const sudahTerdaftar = penggunaDiKelas.some(
                                (item) => item.id === pengguna.id
                              );
                              return (
                                <tr key={pengguna.id}>
                                  <td>
                                    <input
                                      type="checkbox"
                                      checked={idPenggunaTerpilih.includes(pengguna.id)}
                                      onChange={(event) =>
                                        ubahPilihanPengguna(
                                          pengguna.id,
                                          event.target.checked
                                        )
                                      }
                                      aria-label={`Pilih ${pengguna.nama}`}
                                    />
                                  </td>
                                  <td>
                                    <strong>{pengguna.nama}</strong>
                                  </td>
                                  <td>
                                    {tabPenempatan === "mahasiswa"
                                      ? pengguna.nim || "—"
                                      : "Asisten Laboratorium"}
                                  </td>
                                  {tabPenempatan === "mahasiswa" && (
                                    <td>
                                      {namaProgramStudi(pengguna.program_studi_id)}
                                    </td>
                                  )}
                                  <td>
                                    <span className={
                                      sudahTerdaftar
                                        ? "pt-bulk-status assigned"
                                        : "pt-bulk-status"
                                    }>
                                      {sudahTerdaftar ? "Sudah masuk" : "Belum masuk"}
                                    </span>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>

                        {daftarAktif.length === 0 && (
                          <div className="pt-assignment-empty">
                            <Users size={25} />
                            <strong>Data pengguna tidak ditemukan</strong>
                            <p>Coba ubah kata kunci atau filter program studi.</p>
                          </div>
                        )}
                      </div>

                      <div className="pt-bulk-footer">
                        <span>
                          {penggunaDiKelas.length} saat ini di kelas ·{" "}
                          {idPenggunaTerpilih.length} akan terdaftar
                        </span>
                        <button
                          type="button"
                          className="pt-save-button"
                          onClick={simpanPenempatan}
                          disabled={
                            menyimpanPenempatan ||
                            (
                              idPenggunaTerpilih.length === penggunaDiKelas.length &&
                              penggunaDiKelas.every((item) =>
                                idPenggunaTerpilih.includes(item.id)
                              )
                            )
                          }
                        >
                          {menyimpanPenempatan
                            ? "Menyimpan..."
                            : "Simpan Penempatan"}
                        </button>
                      </div>
                    </div>
                  );
                })()}

                {/* PESAN */}

                {pesan && (
                  <div className={`pt-alert ${jenisPesan}`}>
                    {jenisPesan === "success" ? (
                      <CheckCircle2 size={16} />
                    ) : (
                      <AlertCircle size={16} />
                    )}

                    <span>{pesan}</span>

                    <button
                      type="button"
                      onClick={() => setPesan("")}
                      aria-label="Tutup pesan"
                    >
                      <X size={15} />
                    </button>
                  </div>
                )}

              </>
            )}

            <div className="pt-modal-actions">
              <button
                type="button"
                className="pt-cancel-button"
                onClick={tutupModalPenempatan}
                disabled={menyimpanPenempatan}
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
