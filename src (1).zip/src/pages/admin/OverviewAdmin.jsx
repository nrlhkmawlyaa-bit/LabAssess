
import { useCallback, useEffect, useState } from "react";

import {
  Users,
  UserRoundCheck,
  GraduationCap,
  BookOpen,
  Layers3,
  CheckCircle2,
  UserX,
  ClipboardList,
  RefreshCw,
  Plus,
  ArrowRight,
} from "lucide-react";

import { ambilDaftarPengguna } from "../../services/adminService";

import {
  ambilDaftarMataKuliah,
  ambilDaftarPenempatan,
} from "../../services/academicService";

import "../../styles/admin.css";

export default function OverviewAdmin({ pengguna, token, onNavigate }) {
  const [statistik, setStatistik] = useState({
    totalPengguna: 0,
    asisten: 0,
    mahasiswa: 0,
    mataKuliah: 0,
  });

  const [daftarKelas, setDaftarKelas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const muatRingkasan = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const [
        dataMahasiswa,
        dataAsisten,
        dataMataKuliah,
        dataPenempatan,
      ] = await Promise.all([
        ambilDaftarPengguna({
          token,
          role: "mahasiswa",
          halaman: 1,
          batas: 1,
        }),
        ambilDaftarPengguna({
          token,
          role: "asisten_lab",
          halaman: 1,
          batas: 1,
        }),
        ambilDaftarMataKuliah(token),
        ambilDaftarPenempatan(token),
      ]);

      const jumlahMahasiswa = dataMahasiswa.total || 0;
      const jumlahAsisten = dataAsisten.total || 0;

      const kelas = Array.isArray(dataPenempatan)
        ? dataPenempatan
        : [];

      setStatistik({
        totalPengguna: jumlahMahasiswa + jumlahAsisten,
        mahasiswa: jumlahMahasiswa,
        asisten: jumlahAsisten,
        mataKuliah: Array.isArray(dataMataKuliah)
          ? dataMataKuliah.length
          : 0,
      });

      setDaftarKelas(kelas);
    } catch (err) {
      setError(err.message || "Gagal mengambil data dashboard.");
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    muatRingkasan();
  }, [muatRingkasan]);

  const totalKelas = daftarKelas.length;

  const kelasLengkap = daftarKelas.filter(
    (kelas) =>
      kelas.is_active &&
      kelas.asisten?.length > 0 &&
      kelas.mahasiswa?.length > 0
  ).length;

  const kelasTanpaAsisten = daftarKelas.filter(
    (kelas) =>
      kelas.is_active &&
      (!kelas.asisten || kelas.asisten.length === 0)
  ).length;

  const kelasTanpaMahasiswa = daftarKelas.filter(
    (kelas) =>
      kelas.is_active &&
      (!kelas.mahasiswa || kelas.mahasiswa.length === 0)
  ).length;

  const totalPenempatanAsisten = daftarKelas.reduce(
    (total, kelas) => total + (kelas.asisten?.length || 0),
    0
  );

  const totalPenempatanMahasiswa = daftarKelas.reduce(
    (total, kelas) => total + (kelas.mahasiswa?.length || 0),
    0
  );

  const totalDistribusi =
    statistik.mahasiswa + statistik.asisten;

  const persentaseMahasiswa = totalDistribusi
    ? (statistik.mahasiswa / totalDistribusi) * 100
    : 0;

  const persentaseAsisten = totalDistribusi
    ? (statistik.asisten / totalDistribusi) * 100
    : 0;

  function statusKelas(kelas) {
    if (!kelas.is_active) {
      return {
        label: "Nonaktif",
        className: "overview-status-inactive",
      };
    }

    if (
      kelas.asisten?.length > 0 &&
      kelas.mahasiswa?.length > 0
    ) {
      return {
        label: "Lengkap",
        className: "overview-status-complete",
      };
    }

    if (!kelas.asisten?.length && !kelas.mahasiswa?.length) {
      return {
        label: "Belum ditempatkan",
        className: "overview-status-warning",
      };
    }

    if (!kelas.asisten?.length) {
      return {
        label: "Belum ada asisten",
        className: "overview-status-warning",
      };
    }

    return {
      label: "Belum ada mahasiswa",
      className: "overview-status-warning",
    };
  }

  return (
    <div className="overview-admin-page">

      {/* HEADER RINGKASAN */}

      <section className="overview-heading">
        <div>
          <span className="admin-eyebrow">SYSTEM OVERVIEW</span>
          <h1>Ringkasan sistem</h1>
          <p>Gambaran umum aktivitas dan data LabAssess.</p>
        </div>

        <button
          type="button"
          className="overview-refresh-button"
          onClick={muatRingkasan}
          disabled={loading}
          title="Muat ulang data"
        >
          <RefreshCw size={17} />
          <span>Perbarui data</span>
        </button>
      </section>

      {error && (
        <div className="overview-error">
          <strong>Gagal memuat data dashboard.</strong>
          <span>{error}</span>
          <button type="button" onClick={muatRingkasan}>
            Coba lagi
          </button>
        </div>
      )}

      {/* PANEL PENEMPATAN DAN DISTRIBUSI */}

      <section className="overview-bottom-grid">

        {/* RINGKASAN PENEMPATAN */}

        <article className="overview-panel overview-placement-panel">
          <div className="overview-panel-heading">
            <div className="overview-panel-icon">
              <ClipboardList size={21} />
            </div>

            <div>
              <h2>Ringkasan Penempatan</h2>
              <p>Pantau distribusi mahasiswa dan asisten laboratorium.</p>
            </div>
          </div>

          {loading ? (
            <div className="overview-empty-state">
              <RefreshCw size={25} className="overview-spin" />
              <strong>Memuat data penempatan...</strong>
            </div>
          ) : (
            <>
              <div className="overview-placement-summary">
                <div className="overview-placement-metric">
                  <div className="overview-metric-icon">
                    <Layers3 size={19} />
                  </div>
                  <div>
                    <span>Total kelas</span>
                    <strong>{totalKelas}</strong>
                  </div>
                </div>

                <div className="overview-placement-metric">
                  <div className="overview-metric-icon complete">
                    <CheckCircle2 size={19} />
                  </div>
                  <div>
                    <span>Kelas lengkap</span>
                    <strong>{kelasLengkap}</strong>
                  </div>
                </div>

                <div className="overview-placement-metric">
                  <div className="overview-metric-icon warning">
                    <UserX size={19} />
                  </div>
                  <div>
                    <span>Belum ada asisten</span>
                    <strong>{kelasTanpaAsisten}</strong>
                  </div>
                </div>

                <div className="overview-placement-metric">
                  <div className="overview-metric-icon student">
                    <GraduationCap size={19} />
                  </div>
                  <div>
                    <span>Belum ada mahasiswa</span>
                    <strong>{kelasTanpaMahasiswa}</strong>
                  </div>
                </div>
              </div>

              <div className="overview-class-list-heading">
                <strong>Status penempatan kelas</strong>
                <span>{totalKelas} kelas</span>
              </div>

              {daftarKelas.length === 0 ? (
                <div className="overview-empty-state">
                  <Layers3 size={25} />
                  <strong>Belum ada kelas</strong>
                  <p>Kelas yang dibuat admin akan muncul di sini.</p>
                </div>
              ) : (
                <div className="overview-class-list">
                  {daftarKelas.slice(0, 5).map((kelas) => {
                    const status = statusKelas(kelas);

                    return (
                      <div className="overview-class-item" key={kelas.id}>
                        <div className="overview-class-info">
                          <strong>Kelas {kelas.class_code}</strong>
                          <span>
                            {kelas.asisten?.length || 0} asisten
                            {" · "}
                            {kelas.mahasiswa?.length || 0} mahasiswa
                          </span>
                        </div>

                        <span
                          className={`overview-class-status ${status.className}`}
                        >
                          {status.label}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}

              {totalKelas > 5 && (
                <p className="overview-more-info">
                  Menampilkan 5 dari {totalKelas} kelas.
                </p>
              )}
            </>
          )}

          <button
            type="button"
            className="overview-text-link"
            onClick={() => onNavigate?.("penempatan")}
          >
            Kelola penempatan
            <ArrowRight size={15} />
          </button>
        </article>

        {/* DISTRIBUSI PENGGUNA */}

        <article className="overview-panel overview-distribution-panel">
          <div className="overview-panel-heading">
            <div className="overview-panel-icon">
              <Users size={21} />
            </div>

            <div>
              <h2>Distribusi Pengguna</h2>
              <p>Komposisi akun pengguna LabAssess.</p>
            </div>
          </div>

          {loading ? (
            <div className="overview-empty-state">
              <RefreshCw size={25} className="overview-spin" />
              <strong>Memuat distribusi pengguna...</strong>
            </div>
          ) : (
            <>
              <div className="overview-distribution-total">
                <span>Total akun pengguna</span>
                <strong>{statistik.totalPengguna}</strong>
              </div>

              <div className="overview-distribution-chart">
                <div
                  className="overview-distribution-segment mahasiswa"
                  style={{ width: `${persentaseMahasiswa}%` }}
                />
                <div
                  className="overview-distribution-segment asisten"
                  style={{ width: `${persentaseAsisten}%` }}
                />
              </div>

              <div className="overview-distribution-legend">
                <div>
                  <span className="overview-legend-dot mahasiswa" />
                  <div>
                    <span>Mahasiswa</span>
                    <strong>{statistik.mahasiswa}</strong>
                  </div>
                  <small>{persentaseMahasiswa.toFixed(0)}%</small>
                </div>

                <div>
                  <span className="overview-legend-dot asisten" />
                  <div>
                    <span>Asisten Laboratorium</span>
                    <strong>{statistik.asisten}</strong>
                  </div>
                  <small>{persentaseAsisten.toFixed(0)}%</small>
                </div>
              </div>

              <div className="overview-distribution-placement">
                <h3>Aktivitas penempatan</h3>

                <div>
                  <span>Total penempatan asisten</span>
                  <strong>{totalPenempatanAsisten}</strong>
                </div>

                <div>
                  <span>Total penempatan mahasiswa</span>
                  <strong>{totalPenempatanMahasiswa}</strong>
                </div>
              </div>
            </>
          )}
        </article>
      </section>

      {/* TINDAKAN CEPAT */}

      <section className="overview-quick-actions">
        <div className="overview-quick-heading">
          <div>
            <h2>Tindakan Cepat</h2>
            <p>Akses langsung ke pengelolaan LabAssess.</p>
          </div>
        </div>

        
<div className="overview-quick-grid">

  <button
    type="button"
    onClick={() => onNavigate?.("pengguna")}
  >
    <span className="overview-quick-icon rose">
      <Users size={19} />
    </span>
    <span>
      <strong>Manajemen Akun</strong>
      <small>Kelola mahasiswa dan asisten</small>
    </span>
    <ArrowRight size={17} />
  </button>

  <button
    type="button"
    onClick={() => onNavigate?.("mata-kuliah")}
  >
    <span className="overview-quick-icon peach">
      <BookOpen size={19} />
    </span>
    <span>
      <strong>Mata Kuliah</strong>
      <small>Kelola data mata kuliah</small>
    </span>
    <ArrowRight size={17} />
  </button>

  <button
    type="button"
    onClick={() => onNavigate?.("penempatan")}
  >
    <span className="overview-quick-icon lavender">
      <GraduationCap size={19} />
    </span>
    <span>
      <strong>Penempatan Kelas</strong>
      <small>Atur mahasiswa dan asisten</small>
    </span>
    <ArrowRight size={17} />
  </button>

</div>

      </section>
    </div>
  );
}
