
import { useCallback, useEffect, useMemo, useState } from "react";

import {
  Search,
  Users,
  GraduationCap,
  UserRoundCheck,
  UserPlus,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  X,
  ShieldCheck,
  AlertCircle,
  SlidersHorizontal,
  MoreHorizontal,
  KeyRound,
  Pencil,
  Power,
  Eye,
} from "lucide-react";

import {
  ambilDaftarPengguna,
  buatAkunAsisten,
  ubahStatusPengguna,
  editInformasiPengguna,
  resetPasswordPengguna,
} from "../../services/adminService";

import "../../styles/manajemen_pengguna.css";

const PROGRAM_STUDI = [
  { id: 1, nama: "Teknik Informatika" },
  { id: 2, nama: "Sistem Informasi" },
  { id: 3, nama: "Bisnis Digital" },
  { id: 4, nama: "Teknik Elektro" },
  { id: 5, nama: "Teknik Lingkungan" },
  { id: 6, nama: "Teknik Industri" },
];

const BATAS_DATA = 10;

function formatTanggal(nilai) {
  if (!nilai) return "—";

  const tanggal = new Date(nilai);

  if (Number.isNaN(tanggal.getTime())) return "—";

  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(tanggal);
}

function LabelRole({ role }) {
  const mahasiswa = role === "mahasiswa";

  return (
    <span
      className={`pengguna-role ${
        mahasiswa ? "role-mahasiswa" : "role-asisten"
      }`}
    >
      {mahasiswa ? (
        <GraduationCap size={14} />
      ) : (
        <UserRoundCheck size={14} />
      )}
      {mahasiswa ? "Mahasiswa" : "Asisten Lab"}
    </span>
  );
}

function LabelStatus({ aktif }) {
  return (
    <span
      className={`pengguna-status ${
        aktif ? "status-aktif" : "status-nonaktif"
      }`}
    >
      <span />
      {aktif ? "Aktif" : "Nonaktif"}
    </span>
  );
}

function MenuAksiPengguna({
  pengguna,
  terbuka,
  onToggle,
  onPilih,
}) {
  return (
    <div className="pengguna-action-menu">
      <button
        type="button"
        className={`pengguna-action-trigger ${
          terbuka ? "is-open" : ""
        }`}
        onClick={(event) => {
          event.stopPropagation();
          onToggle();
        }}
        aria-label={`Tindakan untuk ${pengguna.nama_lengkap}`}
        aria-expanded={terbuka}
        title="Tindakan akun"
      >
        <MoreHorizontal size={19} />
      </button>

      {terbuka && (
        <div className="pengguna-action-dropdown" role="menu">
          <span className="pengguna-action-heading">
            Tindakan Akun
          </span>

          <button
            type="button"
            role="menuitem"
            onClick={() => onPilih("detail")}
          >
            <Eye size={15} />
            <span>Detail Akun</span>
          </button>

          <button
            type="button"
            role="menuitem"
            onClick={() => onPilih("edit")}
          >
            <Pencil size={15} />
            <span>Edit Informasi Akun</span>
          </button>

          <button
            type="button"
            role="menuitem"
            onClick={() => onPilih("reset")}
          >
            <KeyRound size={15} />
            <span>Reset Password</span>
          </button>

          <div className="pengguna-action-divider" />

          <button
            type="button"
            role="menuitem"
            className="pengguna-action-danger"
            onClick={() => onPilih("status")}
          >
            <Power size={15} />
            <span>
              {pengguna.aktif
                ? "Nonaktifkan Akun"
                : "Aktifkan Akun"}
            </span>
          </button>
        </div>
      )}
    </div>
  );
}

function KartuPengguna({
  pengguna,
  menuTerbuka,
  onToggleMenu,
  onPilihAksi,
}) {
  return (
    <article className="pengguna-mobile-card">
      <div className="pengguna-mobile-top">
        <div className="pengguna-avatar">
          {pengguna.nama_lengkap?.charAt(0)?.toUpperCase() || "?"}
        </div>

        <div className="pengguna-mobile-identity">
          <strong>{pengguna.nama_lengkap}</strong>
          <span>
            {pengguna.nim ||
              pengguna.username ||
              "Identitas belum tersedia"}
          </span>
        </div>

        <div className="pengguna-mobile-actions">
          <LabelStatus aktif={pengguna.aktif} />

          <MenuAksiPengguna
            pengguna={pengguna}
            terbuka={menuTerbuka}
            onToggle={onToggleMenu}
            onPilih={onPilihAksi}
          />
        </div>
      </div>

      <div className="pengguna-mobile-details">
        <div>
          <span>Role</span>
          <LabelRole role={pengguna.role} />
        </div>

        <div>
          <span>Program Studi</span>
          <strong>{pengguna.program_studi || "—"}</strong>
        </div>

        <div>
          <span>Terdaftar</span>
          <strong>{formatTanggal(pengguna.dibuat_pada)}</strong>
        </div>
      </div>
    </article>
  );
}

export default function ManajemenPengguna({ token }) {
  const [daftarPengguna, setDaftarPengguna] = useState([]);
  const [total, setTotal] = useState(0);
  const [halaman, setHalaman] = useState(1);

  const [kataKunci, setKataKunci] = useState("");
  const [pencarian, setPencarian] = useState("");

  const [filterRole, setFilterRole] = useState("");
  const [filterProgram, setFilterProgram] = useState("");
  const [filterStatus, setFilterStatus] = useState("");

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [filterMobileTerbuka, setFilterMobileTerbuka] =
    useState(false);

  const [menuTerbukaId, setMenuTerbukaId] = useState(null);
  const [aksiTerpilih, setAksiTerpilih] = useState(null);

  const [statusLoading, setStatusLoading] = useState(false);
  const [statusError, setStatusError] = useState("");

  const [aksiLoading, setAksiLoading] = useState(false);
  const [aksiError, setAksiError] = useState("");
  const [hasilReset, setHasilReset] = useState(null);

  const [formEdit, setFormEdit] = useState({
    nama_lengkap: "",
    username: "",
    nim: "",
    program_studi_id: "",
  });

  // ==========================================
  // STATE TAMBAH ASISTEN
  // ==========================================

  const [modalTambahAsisten, setModalTambahAsisten] =
    useState(false);

  const [formAsisten, setFormAsisten] = useState({
    nama_lengkap: "",
    username: "",
    password: "",
  });

  const [tambahAsistenLoading, setTambahAsistenLoading] =
    useState(false);

  const [tambahAsistenError, setTambahAsistenError] =
    useState("");

  const [tambahAsistenBerhasil, setTambahAsistenBerhasil] =
    useState(false);

  // ==========================================
  // AMBIL DATA PENGGUNA
  // ==========================================

  const ambilData = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const hasil = await ambilDaftarPengguna({
        token,
        role: filterRole,
        programStudiId: filterProgram,
        statusAktif: filterStatus,
        kataKunci: pencarian,
        halaman,
        batas: BATAS_DATA,
      });

      setDaftarPengguna(hasil.data || []);
      setTotal(hasil.total || 0);
    } catch (err) {
      setDaftarPengguna([]);
      setTotal(0);
      setError(err.message || "Terjadi kesalahan.");
    } finally {
      setLoading(false);
    }
  }, [
    token,
    filterRole,
    filterProgram,
    filterStatus,
    pencarian,
    halaman,
  ]);

  useEffect(() => {
    ambilData();
  }, [ambilData]);

  // ==========================================
  // PERHITUNGAN DATA
  // ==========================================

  const jumlahHalaman = Math.max(
    1,
    Math.ceil(total / BATAS_DATA)
  );

  const nomorAwal =
    total === 0 ? 0 : (halaman - 1) * BATAS_DATA + 1;

  const nomorAkhir = Math.min(
    halaman * BATAS_DATA,
    total
  );

  const ringkasan = useMemo(
    () => ({
      mahasiswa: daftarPengguna.filter(
        (item) => item.role === "mahasiswa"
      ).length,

      asisten: daftarPengguna.filter(
        (item) => item.role === "asisten_lab"
      ).length,

      aktif: daftarPengguna.filter(
        (item) => item.aktif
      ).length,
    }),
    [daftarPengguna]
  );

  // ==========================================
  // PENCARIAN DAN FILTER
  // ==========================================

  function cariPengguna(event) {
    event.preventDefault();
    setHalaman(1);
    setPencarian(kataKunci.trim());
  }

  function resetFilter() {
    setFilterRole("");
    setFilterProgram("");
    setFilterStatus("");
    setKataKunci("");
    setPencarian("");
    setHalaman(1);
    setFilterMobileTerbuka(false);
  }

  function ubahFilter(setter, nilai) {
    setter(nilai);
    setHalaman(1);
  }

  // ==========================================
  // TAMBAH AKUN ASISTEN
  // ==========================================

  function bukaModalTambahAsisten() {
    setFormAsisten({
      nama_lengkap: "",
      username: "",
      password: "",
    });

    setTambahAsistenError("");
    setTambahAsistenBerhasil(false);
    setModalTambahAsisten(true);
  }

  function tutupModalTambahAsisten() {
    if (tambahAsistenLoading) return;

    setModalTambahAsisten(false);
    setTambahAsistenError("");
    setTambahAsistenBerhasil(false);
  }

  async function simpanAkunAsisten(event) {
    event.preventDefault();

    if (tambahAsistenLoading) return;

    const namaLengkap = formAsisten.nama_lengkap.trim();
    const username = formAsisten.username.trim();
    const password = formAsisten.password;

    if (!namaLengkap || !username || !password) {
      setTambahAsistenError(
        "Semua kolom wajib diisi."
      );
      return;
    }

    if (namaLengkap.length < 2) {
      setTambahAsistenError(
        "Nama lengkap minimal 2 karakter."
      );
      return;
    }

    if (username.length < 3) {
      setTambahAsistenError(
        "Username minimal 3 karakter."
      );
      return;
    }

    if (password.length < 8) {
      setTambahAsistenError(
        "Password minimal 8 karakter."
      );
      return;
    }

    const jumlahBytePassword = new TextEncoder()
      .encode(password).length;

    if (jumlahBytePassword > 72) {
      setTambahAsistenError(
        "Password tidak boleh melebihi 72 byte."
      );
      return;
    }

    setTambahAsistenLoading(true);
    setTambahAsistenError("");

    try {
      await buatAkunAsisten({
        token,
        nama_lengkap: namaLengkap,
        username,
        password,
      });

      setTambahAsistenBerhasil(true);

      setFormAsisten({
        nama_lengkap: "",
        username: "",
        password: "",
      });

      // Tampilkan daftar asisten setelah akun dibuat.
      setFilterRole("asisten_lab");
      setFilterProgram("");
      setFilterStatus("");
      setKataKunci("");
      setPencarian("");
      setHalaman(1);
    } catch (err) {
      setTambahAsistenError(
        err.message || "Gagal membuat akun asisten."
      );
    } finally {
      setTambahAsistenLoading(false);
    }
  }

  // ==========================================
  // TINDAKAN AKUN
  // ==========================================

  function pilihAksi(pengguna, jenisAksi) {
    setMenuTerbukaId(null);
    setAksiError("");
    setHasilReset(null);
    setStatusError("");

    if (jenisAksi === "edit") {
      setFormEdit({
        nama_lengkap: pengguna.nama_lengkap || "",
        username: pengguna.username || "",
        nim: pengguna.nim || "",
        program_studi_id: pengguna.program_studi_id
          ? String(pengguna.program_studi_id)
          : "",
      });
    }

    setAksiTerpilih({
      pengguna,
      jenisAksi,
    });
  }

  function tutupDialogAksi() {
    if (statusLoading || aksiLoading) return;

    setAksiTerpilih(null);
    setStatusError("");
    setAksiError("");
    setHasilReset(null);
  }

  async function konfirmasiUbahStatus() {
    if (
      !aksiTerpilih ||
      aksiTerpilih.jenisAksi !== "status" ||
      statusLoading
    ) {
      return;
    }

    const pengguna = aksiTerpilih.pengguna;
    const statusBaru = !pengguna.aktif;

    setStatusLoading(true);
    setStatusError("");

    try {
      await ubahStatusPengguna({
        token,
        idPengguna: pengguna.id,
        aktif: statusBaru,
      });

      setAksiTerpilih(null);
      await ambilData();
    } catch (err) {
      setStatusError(
        err.message || "Gagal mengubah status akun."
      );
    } finally {
      setStatusLoading(false);
    }
  }

  async function simpanEditPengguna(event) {
    event.preventDefault();

    if (
      !aksiTerpilih ||
      aksiTerpilih.jenisAksi !== "edit" ||
      aksiLoading
    ) {
      return;
    }

    const pengguna = aksiTerpilih.pengguna;

    const data = {
      nama_lengkap: formEdit.nama_lengkap.trim(),
    };

    if (pengguna.role === "mahasiswa") {
      data.nim = formEdit.nim.trim();
      data.program_studi_id = Number(
        formEdit.program_studi_id
      );
    } else if (pengguna.role === "asisten_lab") {
      data.username = formEdit.username.trim();
    }

    setAksiLoading(true);
    setAksiError("");

    try {
      await editInformasiPengguna({
        token,
        idPengguna: pengguna.id,
        data,
      });

      setAksiTerpilih(null);
      await ambilData();
    } catch (err) {
      setAksiError(
        err.message || "Gagal menyimpan informasi akun."
      );
    } finally {
      setAksiLoading(false);
    }
  }

  async function konfirmasiResetPassword() {
    if (
      !aksiTerpilih ||
      aksiTerpilih.jenisAksi !== "reset" ||
      aksiLoading
    ) {
      return;
    }

    setAksiLoading(true);
    setAksiError("");
    setHasilReset(null);

    try {
      const hasil = await resetPasswordPengguna({
        token,
        idPengguna: aksiTerpilih.pengguna.id,
      });

      setHasilReset(hasil);
    } catch (err) {
      setAksiError(
        err.message || "Gagal mereset password."
      );
    } finally {
      setAksiLoading(false);
    }
  }

  const judulDialog = {
    detail: "Detail Akun",
    edit: "Edit Informasi Akun",
    reset: "Reset Password",
    status: aksiTerpilih?.pengguna?.aktif
      ? "Nonaktifkan Akun"
      : "Aktifkan Akun",
  };

  // ==========================================
  // TAMPILAN
  // ==========================================

  return (
    <div className="manajemen-pengguna-page">

      {/* INTRO */}

      <section className="pengguna-intro">
        <div>
          <span className="admin-eyebrow">
            <Users size={14} />
            USER MANAGEMENT
          </span>

          <h1>Manajemen Pengguna</h1>

          <p>
            Pantau dan telusuri akun mahasiswa serta asisten
            laboratorium yang terdaftar di LabAssess.
          </p>
        </div>

        <div className="pengguna-intro-icon">
          <Users size={34} />
        </div>
      </section>

      {/* RINGKASAN */}

      <section className="pengguna-summary-grid">
        <article className="pengguna-summary-card">
          <div className="pengguna-summary-icon total">
            <Users size={20} />
          </div>
          <div>
            <span>Total hasil pencarian</span>
            <strong>{loading ? "—" : total}</strong>
          </div>
        </article>

        <article className="pengguna-summary-card">
          <div className="pengguna-summary-icon student">
            <GraduationCap size={20} />
          </div>
          <div>
            <span>Mahasiswa di halaman ini</span>
            <strong>
              {loading ? "—" : ringkasan.mahasiswa}
            </strong>
          </div>
        </article>

        <article className="pengguna-summary-card">
          <div className="pengguna-summary-icon assistant">
            <UserRoundCheck size={20} />
          </div>
          <div>
            <span>Asisten di halaman ini</span>
            <strong>
              {loading ? "—" : ringkasan.asisten}
            </strong>
          </div>
        </article>

        <article className="pengguna-summary-card">
          <div className="pengguna-summary-icon active">
            <ShieldCheck size={20} />
          </div>
          <div>
            <span>Akun aktif di halaman ini</span>
            <strong>
              {loading ? "—" : ringkasan.aktif}
            </strong>
          </div>
        </article>
      </section>

      {/* DAFTAR PENGGUNA */}

      <section className="pengguna-list-panel">
        <div className="pengguna-list-heading">
          <div>
            <span className="admin-eyebrow">
              REGISTERED ACCOUNTS
            </span>

            <h2>Daftar pengguna</h2>

            <p>
              Data ditampilkan langsung dari database LabAssess.
            </p>
          </div>

          <div className="pengguna-heading-actions">
            <button
              className="pengguna-refresh-button"
              onClick={ambilData}
              disabled={loading}
              type="button"
            >
              <RefreshCw
                size={16}
                className={
                  loading ? "pengguna-spinning" : ""
                }
              />
              <span>Refresh</span>
            </button>

            <button
              type="button"
              className="pengguna-add-assistant-button"
              onClick={bukaModalTambahAsisten}
            >
              <UserPlus size={16} />
              <span>Tambah Asisten</span>
            </button>
          </div>
        </div>

        {/* PENCARIAN */}

        <form
          className="pengguna-toolbar"
          onSubmit={cariPengguna}
        >
          <div className="pengguna-search">
            <Search size={18} />

            <input
              type="search"
              value={kataKunci}
              onChange={(event) =>
                setKataKunci(event.target.value)
              }
              placeholder="Cari nama, NIM, atau username..."
            />

            {kataKunci && (
              <button
                type="button"
                onClick={() => {
                  setKataKunci("");
                  setPencarian("");
                  setHalaman(1);
                }}
                aria-label="Hapus pencarian"
              >
                <X size={16} />
              </button>
            )}

            <button
              className="pengguna-search-submit"
              type="submit"
            >
              Cari
            </button>
          </div>

          <button
            type="button"
            className={`pengguna-filter-toggle ${
              filterMobileTerbuka ? "selected" : ""
            }`}
            onClick={() =>
              setFilterMobileTerbuka(!filterMobileTerbuka)
            }
          >
            <SlidersHorizontal size={17} />
            Filter
          </button>
        </form>

        {/* FILTER */}

        <div
          className={`pengguna-filter-area ${
            filterMobileTerbuka ? "filter-open" : ""
          }`}
        >
          <div className="pengguna-filter-field">
            <label>Role pengguna</label>
            <select
              value={filterRole}
              onChange={(event) =>
                ubahFilter(setFilterRole, event.target.value)
              }
            >
              <option value="">Semua role</option>
              <option value="mahasiswa">Mahasiswa</option>
              <option value="asisten_lab">Asisten Lab</option>
            </select>
          </div>

          <div className="pengguna-filter-field">
            <label>Program studi</label>
            <select
              value={filterProgram}
              onChange={(event) =>
                ubahFilter(setFilterProgram, event.target.value)
              }
            >
              <option value="">Semua program studi</option>
              {PROGRAM_STUDI.map((program) => (
                <option key={program.id} value={program.id}>
                  {program.nama}
                </option>
              ))}
            </select>
          </div>

          <div className="pengguna-filter-field">
            <label>Status akun</label>
            <select
              value={filterStatus}
              onChange={(event) =>
                ubahFilter(setFilterStatus, event.target.value)
              }
            >
              <option value="">Semua status</option>
              <option value="true">Aktif</option>
              <option value="false">Nonaktif</option>
            </select>
          </div>

          <button
            type="button"
            className="pengguna-reset-filter"
            onClick={resetFilter}
          >
            <X size={15} />
            Reset filter
          </button>
        </div>

        {/* ERROR */}

        {error && (
          <div className="pengguna-error">
            <AlertCircle size={19} />
            <div>
              <strong>Data gagal dimuat</strong>
              <p>{error}</p>
            </div>
            <button type="button" onClick={ambilData}>
              Coba lagi
            </button>
          </div>
        )}

        {/* LOADING */}

        {!error && loading && (
          <div className="pengguna-loading">
            <span className="pengguna-loader" />
            <strong>Mengambil data pengguna...</strong>
            <p>Mohon tunggu sebentar.</p>
          </div>
        )}

        {/* DATA KOSONG */}

        {!error && !loading && daftarPengguna.length === 0 && (
          <div className="pengguna-empty">
            <div>
              <Users size={29} />
            </div>

            <strong>Pengguna tidak ditemukan</strong>

            <p>
              Belum ada pengguna yang sesuai dengan pencarian
              atau filter yang dipilih.
            </p>

            <button
              type="button"
              onClick={resetFilter}
            >
              Hapus semua filter
            </button>
          </div>
        )}

        {/* TABEL DESKTOP DAN MOBILE */}

        {!error && !loading && daftarPengguna.length > 0 && (
          <>
            <div className="pengguna-table-wrapper">
              <table className="pengguna-table">
                <thead>
                  <tr>
                    <th>Pengguna</th>
                    <th>Akun</th>
                    <th>Role</th>
                    <th>Program Studi</th>
                    <th>Status</th>
                    <th>Tanggal Daftar</th>
                    <th className="pengguna-action-column">
                      Aksi
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {daftarPengguna.map((item) => (
                    <tr key={item.id}>
                      <td>
                        <div className="pengguna-table-name">
                          <div className="pengguna-avatar">
                            {item.nama_lengkap
                              ?.charAt(0)
                              ?.toUpperCase() || "?"}
                          </div>
                          <div>
                            <strong>{item.nama_lengkap}</strong>
                          </div>
                        </div>
                      </td>

                      <td>
                        <div className="pengguna-identity">
                          <strong>
                            {item.nim ||
                              item.username ||
                              "Belum tersedia"}
                          </strong>
                        </div>
                      </td>

                      <td>
                        <LabelRole role={item.role} />
                      </td>

                      <td>
                        <span className="pengguna-program">
                          {item.program_studi || "—"}
                        </span>
                      </td>

                      <td>
                        <LabelStatus aktif={item.aktif} />
                      </td>

                      <td>
                        <span className="pengguna-date">
                          {formatTanggal(item.dibuat_pada)}
                        </span>
                      </td>

                      <td className="pengguna-action-cell">
                        <MenuAksiPengguna
                          pengguna={item}
                          terbuka={menuTerbukaId === item.id}
                          onToggle={() =>
                            setMenuTerbukaId((id) =>
                              id === item.id ? null : item.id
                            )
                          }
                          onPilih={(jenisAksi) =>
                            pilihAksi(item, jenisAksi)
                          }
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* MOBILE */}

            <div className="pengguna-mobile-list">
              {daftarPengguna.map((item) => (
                <KartuPengguna
                  key={item.id}
                  pengguna={item}
                  menuTerbuka={menuTerbukaId === item.id}
                  onToggleMenu={() =>
                    setMenuTerbukaId((id) =>
                      id === item.id ? null : item.id
                    )
                  }
                  onPilihAksi={(jenisAksi) =>
                    pilihAksi(item, jenisAksi)
                  }
                />
              ))}
            </div>

            {/* PAGINATION */}

            <div className="pengguna-pagination">
              <span>
                Menampilkan{" "}
                <strong>{nomorAwal}–{nomorAkhir}</strong>{" "}
                dari <strong>{total}</strong> pengguna
              </span>

              <div className="pengguna-pagination-controls">
                <button
                  type="button"
                  disabled={halaman <= 1}
                  onClick={() =>
                    setHalaman((nilai) => nilai - 1)
                  }
                  aria-label="Halaman sebelumnya"
                >
                  <ChevronLeft size={17} />
                </button>

                <span>
                  {halaman} / {jumlahHalaman}
                </span>

                <button
                  type="button"
                  disabled={halaman >= jumlahHalaman}
                  onClick={() =>
                    setHalaman((nilai) => nilai + 1)
                  }
                  aria-label="Halaman berikutnya"
                >
                  <ChevronRight size={17} />
                </button>
              </div>
            </div>
          </>
        )}
      </section>

      {/* MODAL TAMBAH ASISTEN */}

      {modalTambahAsisten && (
        <div
          className="pengguna-dialog-backdrop"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              tutupModalTambahAsisten();
            }
          }}
        >
          <section
            className="pengguna-action-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="tambah-asisten-title"
          >
            <div className="pengguna-action-dialog-header">
              <div>
                <span className="admin-eyebrow">
                  ASSISTANT ACCOUNT
                </span>

                <h2 id="tambah-asisten-title">
                  Tambah Asisten Lab
                </h2>
              </div>

              <button
                type="button"
                className="pengguna-dialog-close"
                onClick={tutupModalTambahAsisten}
                aria-label="Tutup dialog"
                disabled={tambahAsistenLoading}
              >
                <X size={18} />
              </button>
            </div>

            <div className="pengguna-dialog-content">
              {tambahAsistenBerhasil ? (
                <>
                  <div className="pengguna-action-notice">
                    <p>
                      <strong>Akun asisten berhasil dibuat!</strong>
                    </p>
                    <p>
                      Akun baru sudah tersimpan. Daftar pengguna
                      akan menampilkan akun dengan role Asisten Lab.
                    </p>
                  </div>

                  <div className="pengguna-dialog-footer">
                    <button
                      type="button"
                      onClick={tutupModalTambahAsisten}
                    >
                      Selesai
                    </button>
                  </div>
                </>
              ) : (
                <form
                  className="pengguna-edit-form"
                  onSubmit={simpanAkunAsisten}
                >
                  <label>
                    Nama lengkap
                    <input
                      type="text"
                      value={formAsisten.nama_lengkap}
                      onChange={(event) =>
                        setFormAsisten((nilai) => ({
                          ...nilai,
                          nama_lengkap: event.target.value,
                        }))
                      }
                      placeholder="Masukkan nama lengkap"
                      minLength={2}
                      maxLength={150}
                      required
                    />
                  </label>

                  <label>
                    Username
                    <input
                      type="text"
                      value={formAsisten.username}
                      onChange={(event) =>
                        setFormAsisten((nilai) => ({
                          ...nilai,
                          username: event.target.value,
                        }))
                      }
                      placeholder="Masukkan username"
                      minLength={3}
                      maxLength={50}
                      required
                    />
                  </label>

                  <label>
                    Password
                    <input
                      type="password"
                      value={formAsisten.password}
                      onChange={(event) =>
                        setFormAsisten((nilai) => ({
                          ...nilai,
                          password: event.target.value,
                        }))
                      }
                      placeholder="Minimal 8 karakter"
                      minLength={8}
                      required
                    />
                  </label>

                  <p className="pengguna-form-hint">
                    Password minimal 8 karakter dan maksimal
                    72 byte. Simpan password ini untuk diberikan
                    kepada asisten yang bersangkutan.
                  </p>

                  {tambahAsistenError && (
                    <p
                      className="pengguna-action-notice"
                      role="alert"
                    >
                      {tambahAsistenError}
                    </p>
                  )}

                  <div className="pengguna-dialog-footer">
                    <button
                      type="button"
                      onClick={tutupModalTambahAsisten}
                      disabled={tambahAsistenLoading}
                    >
                      Batal
                    </button>

                    <button
                      type="submit"
                      disabled={tambahAsistenLoading}
                    >
                      {tambahAsistenLoading
                        ? "Membuat akun..."
                        : "Buat Akun Asisten"}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </section>
        </div>
      )}

      {/* MODAL TINDAKAN AKUN */}

      {aksiTerpilih && (
        <div
          className="pengguna-dialog-backdrop"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              tutupDialogAksi();
            }
          }}
        >
          <section
            className="pengguna-action-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="pengguna-action-dialog-title"
          >
            <div className="pengguna-action-dialog-header">
              <div>
                <span className="admin-eyebrow">
                  ACCOUNT MANAGEMENT
                </span>

                <h2 id="pengguna-action-dialog-title">
                  {judulDialog[aksiTerpilih.jenisAksi]}
                </h2>
              </div>

              <button
                type="button"
                className="pengguna-dialog-close"
                onClick={tutupDialogAksi}
                aria-label="Tutup dialog"
                disabled={statusLoading || aksiLoading}
              >
                <X size={18} />
              </button>
            </div>

            <div className="pengguna-dialog-content">
              <div className="pengguna-dialog-user">
                <div className="pengguna-avatar">
                  {aksiTerpilih.pengguna.nama_lengkap
                    ?.charAt(0)
                    ?.toUpperCase() || "?"}
                </div>

                <div>
                  <strong>
                    {aksiTerpilih.pengguna.nama_lengkap}
                  </strong>
                  <span>
                    {aksiTerpilih.pengguna.nim ||
                      aksiTerpilih.pengguna.username ||
                      "Identitas belum tersedia"}
                  </span>
                </div>
              </div>

              {/* DETAIL AKUN */}

              {aksiTerpilih.jenisAksi === "detail" && (
                <div className="pengguna-detail-grid">
                  <div>
                    <span>Role</span>
                    <strong>
                      {aksiTerpilih.pengguna.role === "mahasiswa"
                        ? "Mahasiswa"
                        : "Asisten Lab"}
                    </strong>
                  </div>

                  <div>
                    <span>Program Studi</span>
                    <strong>
                      {aksiTerpilih.pengguna.program_studi ||
                        "Tidak tersedia"}
                    </strong>
                  </div>

                  <div>
                    <span>Status</span>
                    <strong>
                      {aksiTerpilih.pengguna.aktif
                        ? "Aktif"
                        : "Nonaktif"}
                    </strong>
                  </div>

                  <div>
                    <span>Tanggal Daftar</span>
                    <strong>
                      {formatTanggal(
                        aksiTerpilih.pengguna.dibuat_pada
                      )}
                    </strong>
                  </div>

                  <div>
                    <span>Username</span>
                    <strong>
                      {aksiTerpilih.pengguna.username ||
                        "Tidak tersedia"}
                    </strong>
                  </div>

                  <div>
                    <span>NIM</span>
                    <strong>
                      {aksiTerpilih.pengguna.nim ||
                        "Tidak berlaku"}
                    </strong>
                  </div>
                </div>
              )}

              {/* AKTIFKAN / NONAKTIFKAN */}

              {aksiTerpilih.jenisAksi === "status" && (
                <div className="pengguna-action-notice">
                  {statusError ? (
                    <p role="alert">{statusError}</p>
                  ) : (
                    <p>
                      Apakah kamu yakin ingin{" "}
                      <strong>
                        {aksiTerpilih.pengguna.aktif
                          ? "menonaktifkan"
                          : "mengaktifkan"}{" "}
                        akun ini
                      </strong>
                      ? Perubahan status akan langsung diterapkan
                      pada akun pengguna.
                    </p>
                  )}
                </div>
              )}

              {/* EDIT INFORMASI AKUN */}

              {aksiTerpilih.jenisAksi === "edit" && (
                <form
                  className="pengguna-edit-form"
                  onSubmit={simpanEditPengguna}
                >
                  <label>
                    Nama lengkap
                    <input
                      type="text"
                      value={formEdit.nama_lengkap}
                      onChange={(event) =>
                        setFormEdit((nilai) => ({
                          ...nilai,
                          nama_lengkap: event.target.value,
                        }))
                      }
                      required
                      minLength={1}
                    />
                  </label>

                  {aksiTerpilih.pengguna.role === "mahasiswa" ? (
                    <>
                      <label>
                        NIM
                        <input
                          type="text"
                          value={formEdit.nim}
                          onChange={(event) =>
                            setFormEdit((nilai) => ({
                              ...nilai,
                              nim: event.target.value,
                            }))
                          }
                          required
                        />
                      </label>

                      <label>
                        Program studi
                        <select
                          value={formEdit.program_studi_id}
                          onChange={(event) =>
                            setFormEdit((nilai) => ({
                              ...nilai,
                              program_studi_id: event.target.value,
                            }))
                          }
                          required
                        >
                          <option value="">
                            Pilih program studi
                          </option>

                          {PROGRAM_STUDI.map((program) => (
                            <option
                              key={program.id}
                              value={program.id}
                            >
                              {program.nama}
                            </option>
                          ))}
                        </select>
                      </label>
                    </>
                  ) : (
                    <label>
                      Username
                      <input
                        type="text"
                        value={formEdit.username}
                        onChange={(event) =>
                          setFormEdit((nilai) => ({
                            ...nilai,
                            username: event.target.value,
                          }))
                        }
                        required
                      />
                    </label>
                  )}

                  {aksiError && (
                    <p
                      className="pengguna-action-notice"
                      role="alert"
                    >
                      {aksiError}
                    </p>
                  )}

                  <div className="pengguna-dialog-footer">
                    <button
                      type="button"
                      onClick={tutupDialogAksi}
                      disabled={aksiLoading}
                    >
                      Batal
                    </button>

                    <button
                      type="submit"
                      disabled={aksiLoading}
                    >
                      {aksiLoading
                        ? "Menyimpan..."
                        : "Simpan Perubahan"}
                    </button>
                  </div>
                </form>
              )}

              {/* RESET PASSWORD */}

              {aksiTerpilih.jenisAksi === "reset" && (
                <div className="pengguna-reset-content">
                  {!hasilReset ? (
                    <>
                      <div className="pengguna-action-notice">
                        <p>
                          Reset password untuk akun{" "}
                          <strong>
                            {aksiTerpilih.pengguna.nama_lengkap}
                          </strong>
                          ?
                        </p>

                        <p>
                          Sistem akan membuat password sementara
                          yang berlaku selama 24 jam dan pengguna
                          diwajibkan menggantinya saat login berikutnya.
                        </p>
                      </div>

                      {aksiError && (
                        <p
                          className="pengguna-action-notice"
                          role="alert"
                        >
                          {aksiError}
                        </p>
                      )}

                      <div className="pengguna-dialog-footer">
                        <button
                          type="button"
                          onClick={tutupDialogAksi}
                          disabled={aksiLoading}
                        >
                          Batal
                        </button>

                        <button
                          type="button"
                          onClick={konfirmasiResetPassword}
                          disabled={aksiLoading}
                        >
                          {aksiLoading
                            ? "Memproses..."
                            : "Reset Password"}
                        </button>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="pengguna-action-notice">
                        <p>{hasilReset.pesan}</p>

                        <p>
                          <strong>Password sementara</strong>
                        </p>

                        <code className="pengguna-password-temporary">
                          {hasilReset.password_sementara}
                        </code>

                        <p>
                          Berlaku sampai:{" "}
                          {formatTanggal(hasilReset.berlaku_sampai)}
                        </p>

                        <p>
                          Salin dan berikan password ini kepada
                          pemilik akun. Password hanya ditampilkan
                          pada respons reset ini.
                        </p>
                      </div>

                      <div className="pengguna-dialog-footer">
                        <button
                          type="button"
                          onClick={tutupDialogAksi}
                        >
                          Selesai
                        </button>
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>

            {/* FOOTER DIALOG */}

            <div className="pengguna-dialog-footer">
              {aksiTerpilih.jenisAksi !== "edit" &&
                aksiTerpilih.jenisAksi !== "reset" && (
                  <button
                    type="button"
                    onClick={tutupDialogAksi}
                    disabled={statusLoading || aksiLoading}
                  >
                    Tutup
                  </button>
                )}

              {aksiTerpilih.jenisAksi === "status" && (
                <button
                  type="button"
                  onClick={konfirmasiUbahStatus}
                  disabled={statusLoading}
                >
                  {statusLoading
                    ? "Memproses..."
                    : aksiTerpilih.pengguna.aktif
                      ? "Ya, Nonaktifkan"
                      : "Ya, Aktifkan"}
                </button>
              )}
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
