
import { useEffect, useMemo, useState } from "react";

import {
  BookOpen,
  Plus,
  Search,
  RefreshCw,
  Pencil,
  Trash2,
  X,
  GraduationCap,
  Layers3,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";

import {
  ambilDaftarMataKuliah,
  tambahMataKuliah,
  ubahMataKuliah,
  hapusMataKuliah,
} from "../../services/academicService";

import "../../styles/mata_kuliah.css";

const PROGRAM_STUDI = [
  { id: 1, kode: "TI", nama: "Teknik Informatika" },
  { id: 2, kode: "SI", nama: "Sistem Informasi" },
  { id: 3, kode: "BD", nama: "Bisnis Digital" },
  { id: 4, kode: "TE", nama: "Teknik Elektro" },
  { id: 5, kode: "TL", nama: "Teknik Lingkungan" },
  { id: 6, kode: "TIND", nama: "Teknik Industri" },
];

const FORM_AWAL = {
  kode: "",
  nama: "",
  sks: 2,
  program_studi_ids: [],
};

export default function MataKuliah({ token }) {
  const [daftar, setDaftar] = useState([]);
  const [pencarian, setPencarian] = useState("");
  const [filterProdi, setFilterProdi] = useState("");

  const [loading, setLoading] = useState(true);
  const [menyimpan, setMenyimpan] = useState(false);
  const [menghapus, setMenghapus] = useState(null);

  const [modalTerbuka, setModalTerbuka] = useState(false);
  const [dataEdit, setDataEdit] = useState(null);

  const [form, setForm] = useState(FORM_AWAL);

  const [pesan, setPesan] = useState("");
  const [jenisPesan, setJenisPesan] = useState("error");

  // =====================================
  // MEMUAT DATA MATA KULIAH
  // =====================================

  async function muatData() {
    try {
      setLoading(true);
      setPesan("");

      const hasil = await ambilDaftarMataKuliah(token, {
        kataKunci: pencarian,
        programStudiId: filterProdi,
      });

      setDaftar(Array.isArray(hasil) ? hasil : []);
    } catch (error) {
      setPesan(error.message);
      setJenisPesan("error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (token) {
      muatData();
    }
  }, [token, pencarian, filterProdi]);

  // =====================================
  // STATISTIK
  // =====================================

  const totalSKS = useMemo(
    () => daftar.reduce((total, item) => total + item.sks, 0),
    [daftar]
  );

  const totalProgramTerpakai = useMemo(() => {
    const ids = new Set();

    daftar.forEach((item) => {
      item.program_studi?.forEach((prodi) => {
        ids.add(prodi.id);
      });
    });

    return ids.size;
  }, [daftar]);

  // =====================================
  // MODAL TAMBAH DAN EDIT
  // =====================================

  function bukaTambah() {
    setDataEdit(null);
    setForm(FORM_AWAL);
    setPesan("");
    setModalTerbuka(true);
  }

  function bukaEdit(item) {
    setDataEdit(item);

    setForm({
      kode: item.kode,
      nama: item.nama,
      sks: item.sks,
      program_studi_ids: item.program_studi.map(
        (prodi) => prodi.id
      ),
    });

    setPesan("");
    setModalTerbuka(true);
  }

  function tutupModal() {
    if (menyimpan) return;

    setModalTerbuka(false);
    setDataEdit(null);
    setForm(FORM_AWAL);
  }

  function ubahForm(event) {
    const { name, value } = event.target;

    setForm((sebelumnya) => ({
      ...sebelumnya,
      [name]: value,
    }));
  }

  function ubahProgramStudi(id) {
    setForm((sebelumnya) => ({
      ...sebelumnya,
      program_studi_ids:
        sebelumnya.program_studi_ids.includes(id)
          ? sebelumnya.program_studi_ids.filter(
              (item) => item !== id
            )
          : [...sebelumnya.program_studi_ids, id],
    }));
  }

  // =====================================
  // SIMPAN DATA
  // =====================================

  async function simpanData(event) {
    event.preventDefault();

    if (form.program_studi_ids.length === 0) {
      setPesan("Pilih minimal satu program studi.");
      setJenisPesan("error");
      return;
    }

    const payload = {
      kode: form.kode.trim(),
      nama: form.nama.trim(),
      sks: Number(form.sks),
      program_studi_ids: form.program_studi_ids,
    };

    try {
      setMenyimpan(true);
      setPesan("");

      if (dataEdit) {
        await ubahMataKuliah(
          token,
          dataEdit.id,
          payload
        );

        setPesan("Mata kuliah berhasil diperbarui.");
      } else {
        await tambahMataKuliah(token, payload);

        setPesan("Mata kuliah berhasil ditambahkan.");
      }

      setJenisPesan("success");
      setModalTerbuka(false);
      setDataEdit(null);
      setForm(FORM_AWAL);

      await muatData();
    } catch (error) {
      setPesan(error.message);
      setJenisPesan("error");
    } finally {
      setMenyimpan(false);
    }
  }

  // =====================================
  // HAPUS DATA
  // =====================================

  async function konfirmasiHapus(item) {
    const setuju = window.confirm(
      `Apakah kamu yakin ingin menghapus mata kuliah "${item.nama}"?`
    );

    if (!setuju) return;

    try {
      setMenghapus(item.id);
      setPesan("");

      await hapusMataKuliah(token, item.id);

      setPesan("Mata kuliah berhasil dihapus.");
      setJenisPesan("success");

      await muatData();
    } catch (error) {
      setPesan(error.message);
      setJenisPesan("error");
    } finally {
      setMenghapus(null);
    }
  }

  // =====================================
  // FORMAT PROGRAM STUDI
  // =====================================

  function namaProgramStudi(item) {
    if (!item.program_studi?.length) return "-";

    return item.program_studi
      .map((prodi) => prodi.kode)
      .join(", ");
  }

  // =====================================
  // TAMPILAN
  // =====================================

  return (
    <section className="mk-page">

      {/* HEADER */}
      <div className="mk-intro">
        <div className="mk-intro-icon">
          <BookOpen size={25} />
        </div>

        <div>
          <span className="mk-eyebrow">
            ACADEMIC MANAGEMENT
          </span>

          <h1>Manajemen Mata Kuliah</h1>

          <p>
            Kelola daftar mata kuliah dan program studi
            yang mengikuti perkuliahan di LabAssess.
          </p>
        </div>
      </div>

      {/* STATISTIK */}
      <div className="mk-stat-grid">

        <div className="mk-stat-card">
          <span className="mk-stat-icon">
            <BookOpen size={20} />
          </span>

          <div>
            <small>Total Mata Kuliah</small>
            <strong>{daftar.length}</strong>
          </div>
        </div>

        <div className="mk-stat-card">
          <span className="mk-stat-icon">
            <Layers3 size={20} />
          </span>

          <div>
            <small>Total SKS</small>
            <strong>{totalSKS}</strong>
          </div>
        </div>

        <div className="mk-stat-card">
          <span className="mk-stat-icon">
            <GraduationCap size={20} />
          </span>

          <div>
            <small>Program Studi Terdaftar</small>
            <strong>{totalProgramTerpakai}</strong>
          </div>
        </div>

      </div>

      {/* PESAN */}
      {pesan && (
        <div className={`mk-alert ${jenisPesan}`}>
          {jenisPesan === "success" ? (
            <CheckCircle2 size={18} />
          ) : (
            <AlertCircle size={18} />
          )}

          <span>{pesan}</span>

          <button
            type="button"
            onClick={() => setPesan("")}
          >
            <X size={16} />
          </button>
        </div>
      )}

      {/* KONTEN */}
      <div className="mk-content-card">

        <div className="mk-toolbar">
          <div>
            <h2>Daftar Mata Kuliah</h2>
            <p>
              Kelola informasi mata kuliah yang terdaftar.
            </p>
          </div>

          <button
            className="mk-add-button"
            onClick={bukaTambah}
            type="button"
          >
            <Plus size={18} />
            Tambah Mata Kuliah
          </button>
        </div>

        {/* FILTER */}
        <div className="mk-filter-row">

          <div className="mk-search">
            <Search size={18} />

            <input
              value={pencarian}
              onChange={(event) =>
                setPencarian(event.target.value)
              }
              placeholder="Cari kode atau nama mata kuliah..."
            />
          </div>

          <select
            value={filterProdi}
            onChange={(event) =>
              setFilterProdi(event.target.value)
            }
          >
            <option value="">Semua Program Studi</option>

            {PROGRAM_STUDI.map((prodi) => (
              <option key={prodi.id} value={prodi.id}>
                {prodi.kode}
              </option>
            ))}
          </select>

          <button
            className="mk-refresh-button"
            onClick={muatData}
            title="Muat ulang data"
            type="button"
          >
            <RefreshCw
              size={17}
              className={loading ? "mk-spin" : ""}
            />
          </button>

        </div>

        {/* TABEL */}
        {loading ? (
          <div className="mk-empty">
            <RefreshCw
              className="mk-spin"
              size={25}
            />
            <p>Memuat data mata kuliah...</p>
          </div>
        ) : daftar.length === 0 ? (
          <div className="mk-empty">
            <Layers3 size={34} />

            <strong>Belum ada mata kuliah</strong>

            <p>
              Tambahkan mata kuliah untuk mulai mengelola
              data akademik.
            </p>
          </div>
        ) : (
          <div className="mk-table-wrapper">
            <table className="mk-table">

              <thead>
                <tr>
                  <th>Kode</th>
                  <th>Nama Mata Kuliah</th>
                  <th>SKS</th>
                  <th>Program Studi</th>
                  <th>Aksi</th>
                </tr>
              </thead>

              <tbody>
                {daftar.map((item) => (
                  <tr key={item.id}>

                    <td>
                      <span className="mk-code">
                        {item.kode}
                      </span>
                    </td>

                    <td className="mk-course-name">
                      {item.nama}
                    </td>

                    <td>{item.sks} SKS</td>

                    <td>
                      {namaProgramStudi(item)}
                    </td>

                    <td>
                      <div className="mk-actions">

                        <button
                          type="button"
                          title="Edit mata kuliah"
                          onClick={() => bukaEdit(item)}
                        >
                          <Pencil size={16} />
                        </button>

                        <button
                          type="button"
                          className="delete"
                          title="Hapus mata kuliah"
                          disabled={menghapus === item.id}
                          onClick={() =>
                            konfirmasiHapus(item)
                          }
                        >
                          {menghapus === item.id ? (
                            <RefreshCw
                              size={16}
                              className="mk-spin"
                            />
                          ) : (
                            <Trash2 size={16} />
                          )}
                        </button>

                      </div>
                    </td>

                  </tr>
                ))}
              </tbody>

            </table>
          </div>
        )}

        <div className="mk-table-footer">
          Menampilkan {daftar.length} mata kuliah
        </div>

      </div>

      {/* MODAL TAMBAH / EDIT */}
      {modalTerbuka && (
        <div
          className="mk-modal-overlay"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              tutupModal();
            }
          }}
        >

          <form
            className="mk-modal"
            onSubmit={simpanData}
          >

            <div className="mk-modal-header">

              <div>
                <span className="mk-eyebrow">
                  COURSE INFORMATION
                </span>

                <h2>
                  {dataEdit
                    ? "Edit Mata Kuliah"
                    : "Tambah Mata Kuliah"}
                </h2>

                <p>
                  Lengkapi informasi mata kuliah berikut.
                </p>
              </div>

              <button
                type="button"
                onClick={tutupModal}
              >
                <X size={20} />
              </button>

            </div>

            {/* KODE */}
            <div className="mk-form-field">
              <label>Kode Mata Kuliah</label>

              <input
                name="kode"
                value={form.kode}
                onChange={ubahForm}
                placeholder="Contoh: IF101"
                minLength={2}
                maxLength={30}
                required
              />
            </div>

            {/* NAMA */}
            <div className="mk-form-field">
              <label>Nama Mata Kuliah</label>

              <input
                name="nama"
                value={form.nama}
                onChange={ubahForm}
                placeholder="Masukkan nama mata kuliah"
                minLength={2}
                maxLength={150}
                required
              />
            </div>

            {/* SKS */}
            <div className="mk-form-field">
              <label>Jumlah SKS</label>

              <select
                name="sks"
                value={form.sks}
                onChange={ubahForm}
                required
              >
                {[1, 2, 3, 4, 5, 6, 7, 8].map(
                  (sks) => (
                    <option key={sks} value={sks}>
                      {sks} SKS
                    </option>
                  )
                )}
              </select>
            </div>

            {/* PROGRAM STUDI */}
            <div className="mk-form-field">

              <label>Program Studi</label>

              <p className="mk-hint">
                Pilih minimal satu program studi.
              </p>

              <div className="mk-program-grid">

                {PROGRAM_STUDI.map((prodi) => (
                  <label
                    key={prodi.id}
                    className="mk-program-option"
                  >

                    <input
                      type="checkbox"
                      checked={form.program_studi_ids.includes(
                        prodi.id
                      )}
                      onChange={() =>
                        ubahProgramStudi(prodi.id)
                      }
                    />

                    <span>{prodi.kode}</span>

                    <small>{prodi.nama}</small>

                  </label>
                ))}

              </div>

            </div>

            {/* TOMBOL */}
            <div className="mk-modal-actions">

              <button
                type="button"
                className="mk-cancel-button"
                onClick={tutupModal}
                disabled={menyimpan}
              >
                Batal
              </button>

              <button
                type="submit"
                className="mk-save-button"
                disabled={menyimpan}
              >
                {menyimpan
                  ? "Menyimpan..."
                  : dataEdit
                    ? "Simpan Perubahan"
                    : "Simpan Mata Kuliah"}
              </button>

            </div>

          </form>
        </div>
      )}

    </section>
  );
}
