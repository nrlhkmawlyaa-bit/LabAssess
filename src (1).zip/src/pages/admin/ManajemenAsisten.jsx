
import { useCallback, useEffect, useMemo, useState } from "react";

import {
  UserRoundCheck,
  Search,
  RefreshCw,
  ShieldCheck,
  BookOpen,
  Users,
  CalendarDays,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  X,
  GraduationCap,
  Plus,
  Mail,
} from "lucide-react";

import { ambilDaftarPengguna } from "../../services/adminService";
import "../../styles/manajemen_asisten.css";

const BATAS_DATA = 10;

function formatTanggal(nilai) {
  if (!nilai) return "—";

  const tanggal = new Date(nilai);

  if (Number.isNaN(tanggal.getTime())) return "—";

  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  }).format(tanggal);
}

function StatusAsisten({ aktif }) {
  return (
    <span
      className={`asisten-status ${
        aktif ? "aktif" : "nonaktif"
      }`}
    >
      <span />
      {aktif ? "Aktif" : "Nonaktif"}
    </span>
  );
}

function KartuAsisten({ asisten }) {
  return (
    <article className="asisten-mobile-card">
      <div className="asisten-mobile-header">
        <div className="asisten-avatar">
          {asisten.nama_lengkap?.charAt(0)?.toUpperCase() || "A"}
        </div>

        <div className="asisten-mobile-identity">
          <strong>{asisten.nama_lengkap || "—"}</strong>
          <span>Asisten Laboratorium</span>
        </div>

        <StatusAsisten aktif={asisten.aktif} />
      </div>

      <div className="asisten-mobile-information">
        <div>
          <span>Username</span>
          <strong>{asisten.username || "—"}</strong>
        </div>

        <div>
          <span>ID Asisten</span>
          <strong>ASL-{String(asisten.id).padStart(3, "0")}</strong>
        </div>

        <div>
          <span>Tanggal Terdaftar</span>
          <strong>{formatTanggal(asisten.dibuat_pada)}</strong>
        </div>
      </div>
    </article>
  );
}

export default function ManajemenAsisten({ token }) {
  const [daftarAsisten, setDaftarAsisten] = useState([]);
  const [total, setTotal] = useState(0);

  const [halaman, setHalaman] = useState(1);
  const [kataKunci, setKataKunci] = useState("");
  const [pencarian, setPencarian] = useState("");
  const [filterStatus, setFilterStatus] = useState("");

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const muatAsisten = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const hasil = await ambilDaftarPengguna({
        token,
        role: "asisten_lab",
        statusAktif: filterStatus,
        kataKunci: pencarian,
        halaman,
        batas: BATAS_DATA,
      });

      setDaftarAsisten(hasil.data || []);
      setTotal(hasil.total || 0);
    } catch (err) {
      setDaftarAsisten([]);
      setTotal(0);
      setError(err.message || "Gagal memuat data asisten.");
    } finally {
      setLoading(false);
    }
  }, [token, filterStatus, pencarian, halaman]);

  useEffect(() => {
    muatAsisten();
  }, [muatAsisten]);

  const statistik = useMemo(() => ({
    aktif: daftarAsisten.filter((item) => item.aktif).length,
    nonaktif: daftarAsisten.filter((item) => !item.aktif).length,
  }), [daftarAsisten]);

  const jumlahHalaman = Math.max(
    1,
    Math.ceil(total / BATAS_DATA)
  );

  const nomorAwal = total === 0
    ? 0
    : (halaman - 1) * BATAS_DATA + 1;

  const nomorAkhir = Math.min(
    halaman * BATAS_DATA,
    total
  );

  function cariAsisten(event) {
    event.preventDefault();
    setHalaman(1);
    setPencarian(kataKunci.trim());
  }

  function resetFilter() {
    setKataKunci("");
    setPencarian("");
    setFilterStatus("");
    setHalaman(1);
  }

  return (
    <div className="manajemen-asisten-page">
      <section className="asisten-intro">
        <div>
          <span className="admin-eyebrow">
            <UserRoundCheck size={14} />
            LAB ASSISTANT MANAGEMENT
          </span>

          <h1>Manajemen Asisten</h1>

          <p>
            Kelola dan pantau akun asisten laboratorium
            yang bertugas mendampingi kegiatan praktikum
            mahasiswa.
          </p>
        </div>

        <div className="asisten-intro-art">
          <UserRoundCheck size={36} />
          <span>✦</span>
        </div>
      </section>

      <section className="asisten-summary-grid">
        <article className="asisten-summary-card">
          <div className="asisten-summary-icon total">
            <Users size={21} />
          </div>

          <div>
            <span>Total asisten</span>
            <strong>{loading ? "—" : total}</strong>
          </div>
        </article>

        <article className="asisten-summary-card">
          <div className="asisten-summary-icon active">
            <ShieldCheck size={21} />
          </div>

          <div>
            <span>Aktif di halaman ini</span>
            <strong>{loading ? "—" : statistik.aktif}</strong>
          </div>
        </article>

        <article className="asisten-summary-card">
          <div className="asisten-summary-icon inactive">
            <UserRoundCheck size={21} />
          </div>

          <div>
            <span>Nonaktif di halaman ini</span>
            <strong>{loading ? "—" : statistik.nonaktif}</strong>
          </div>
        </article>

        <article className="asisten-summary-card">
          <div className="asisten-summary-icon course">
            <BookOpen size={21} />
          </div>

          <div>
            <span>Mata kuliah diampu</span>
            <strong>—</strong>
          </div>
        </article>
      </section>

      <section className="asisten-list-panel">
        <div className="asisten-list-heading">
          <div>
            <span className="admin-eyebrow">
              REGISTERED LAB ASSISTANTS
            </span>

            <h2>Daftar asisten laboratorium</h2>

            <p>
              Data akun asisten yang terdaftar di LabAssess.
            </p>
          </div>

          <button
            type="button"
            className="asisten-refresh-button"
            onClick={muatAsisten}
            disabled={loading}
          >
            <RefreshCw
              size={16}
              className={loading ? "asisten-spin" : ""}
            />
            <span>Refresh</span>
          </button>
        </div>

        <div className="asisten-toolbar">
          <form
            className="asisten-search"
            onSubmit={cariAsisten}
          >
            <Search size={18} />

            <input
              type="search"
              value={kataKunci}
              onChange={(event) =>
                setKataKunci(event.target.value)
              }
              placeholder="Cari nama atau username asisten..."
            />

            {kataKunci && (
              <button
                type="button"
                aria-label="Hapus pencarian"
                onClick={() => {
                  setKataKunci("");
                  setPencarian("");
                  setHalaman(1);
                }}
              >
                <X size={16} />
              </button>
            )}

            <button type="submit" className="asisten-search-submit">
              Cari
            </button>
          </form>

          <select
            className="asisten-status-filter"
            value={filterStatus}
            onChange={(event) => {
              setFilterStatus(event.target.value);
              setHalaman(1);
            }}
            aria-label="Filter status asisten"
          >
            <option value="">Semua status</option>
            <option value="true">Aktif</option>
            <option value="false">Nonaktif</option>
          </select>
        </div>

        {error && (
          <div className="asisten-error">
            <AlertCircle size={19} />

            <div>
              <strong>Data asisten gagal dimuat</strong>
              <p>{error}</p>
            </div>

            <button type="button" onClick={muatAsisten}>
              Coba lagi
            </button>
          </div>
        )}

        {!error && loading && (
          <div className="asisten-loading">
            <span />
            <strong>Memuat data asisten...</strong>
            <p>Menghubungkan ke database LabAssess.</p>
          </div>
        )}

        {!error && !loading && daftarAsisten.length === 0 && (
          <div className="asisten-empty">
            <div>
              <UserRoundCheck size={30} />
            </div>

            <strong>Belum ada asisten ditemukan</strong>

            <p>
              Data asisten belum tersedia atau tidak sesuai
              dengan pencarian dan filter yang dipilih.
            </p>

            <button type="button" onClick={resetFilter}>
              Reset pencarian
            </button>
          </div>
        )}

        {!error && !loading && daftarAsisten.length > 0 && (
          <>
            <div className="asisten-table-wrapper">
              <table className="asisten-table">
                <thead>
                  <tr>
                    <th>Asisten</th>
                    <th>Username</th>
                    <th>ID Asisten</th>
                    <th>Status</th>
                    <th>Tanggal Terdaftar</th>
                  </tr>
                </thead>

                <tbody>
                  {daftarAsisten.map((item) => (
                    <tr key={item.id}>
                      <td>
                        <div className="asisten-table-person">
                          <div className="asisten-avatar">
                            {item.nama_lengkap
                              ?.charAt(0)
                              ?.toUpperCase() || "A"}
                          </div>

                          <div>
                            <strong>{item.nama_lengkap}</strong>
                            <small>Asisten Laboratorium</small>
                          </div>
                        </div>
                      </td>

                      <td>
                        <span className="asisten-username">
                          {item.username || "—"}
                        </span>
                      </td>

                      <td>
                        <span className="asisten-id">
                          ASL-{String(item.id).padStart(3, "0")}
                        </span>
                      </td>

                      <td>
                        <StatusAsisten aktif={item.aktif} />
                      </td>

                      <td>
                        <span className="asisten-date">
                          {formatTanggal(item.dibuat_pada)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="asisten-mobile-list">
              {daftarAsisten.map((item) => (
                <KartuAsisten
                  key={item.id}
                  asisten={item}
                />
              ))}
            </div>

            <div className="asisten-pagination">
              <span>
                Menampilkan <strong>{nomorAwal}–{nomorAkhir}</strong>
                {" "}dari <strong>{total}</strong> asisten
              </span>

              <div>
                <button
                  type="button"
                  disabled={halaman <= 1}
                  onClick={() => setHalaman((nilai) => nilai - 1)}
                  aria-label="Halaman sebelumnya"
                >
                  <ChevronLeft size={17} />
                </button>

                <strong>
                  {halaman} / {jumlahHalaman}
                </strong>

                <button
                  type="button"
                  disabled={halaman >= jumlahHalaman}
                  onClick={() => setHalaman((nilai) => nilai + 1)}
                  aria-label="Halaman berikutnya"
                >
                  <ChevronRight size={17} />
                </button>
              </div>
            </div>
          </>
        )}
      </section>

      <section className="asisten-info-panel">
        <div className="asisten-info-icon">
          <GraduationCap size={22} />
        </div>

        <div>
          <strong>Pengelolaan asisten laboratorium</strong>
          <p>
            Akun asisten digunakan untuk mengelola materi,
            soal, kuis, dan kegiatan praktikum sesuai
            penugasan yang diberikan Admin.
          </p>
        </div>
      </section>
    </div>
  );
}
