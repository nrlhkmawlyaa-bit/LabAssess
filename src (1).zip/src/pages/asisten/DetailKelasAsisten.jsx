
import {
  ArrowLeft,
  BookOpen,
  CalendarDays,
  GraduationCap,
  Users,
  Hash,
  CircleCheck,
  CircleAlert,
  UserRound,
} from "lucide-react";

import ModulPraktikumAsisten from "./ModulPraktikumAsisten";

export default function DetailKelasAsisten({
  detail,
  token,
  onKembali,
}) {
  if (!detail) return null;

  return (
    <div className="detail-kelas-page">
      {/* HEADER DETAIL KELAS */}
      <div className="detail-kelas-heading">
        <button
          type="button"
          className="detail-back-button"
          onClick={onKembali}
        >
          <ArrowLeft size={17} />
          Kembali ke Kelas Saya
        </button>

        <span className="asisten-eyebrow">
          CLASS INFORMATION
        </span>

        <h2>Detail Kelas</h2>

        <p>
          Informasi kelas dan mahasiswa yang terdaftar
          pada kelas ini.
        </p>
      </div>

      {/* INFORMASI UTAMA KELAS */}
      <section className="detail-kelas-hero">
        <div className="detail-kelas-hero-main">
          <div className="detail-kelas-icon">
            <BookOpen size={27} />
          </div>

          <div>
            <span className="detail-kelas-code">
              {detail.kode_mata_kuliah}
            </span>

            <h1>{detail.nama_mata_kuliah}</h1>

            <p>
              Kelas {detail.kode_kelas}
            </p>
          </div>
        </div>

        <span
          className={`asisten-status ${
            detail.is_active ? "active" : "inactive"
          }`}
        >
          {detail.is_active ? (
            <CircleCheck size={14} />
          ) : (
            <CircleAlert size={14} />
          )}

          {detail.is_active ? "Aktif" : "Tidak Aktif"}
        </span>
      </section>

      {/* RINGKASAN INFORMASI KELAS */}
      <section className="detail-kelas-info-grid">
        <article className="detail-info-card">
          <div className="detail-info-icon wine">
            <Hash size={20} />
          </div>

          <div>
            <span>Kode Kelas</span>
            <strong>{detail.kode_kelas}</strong>
          </div>
        </article>

        <article className="detail-info-card">
          <div className="detail-info-icon rose">
            <BookOpen size={20} />
          </div>

          <div>
            <span>Jumlah SKS</span>
            <strong>{detail.sks} SKS</strong>
          </div>
        </article>

        <article className="detail-info-card">
          <div className="detail-info-icon green">
            <CalendarDays size={20} />
          </div>

          <div>
            <span>Semester</span>
            <strong>{detail.semester || "-"}</strong>
          </div>
        </article>

        <article className="detail-info-card">
          <div className="detail-info-icon purple">
            <GraduationCap size={20} />
          </div>

          <div>
            <span>Tahun Akademik</span>
            <strong>
              {detail.tahun_akademik || "-"}
            </strong>
          </div>
        </article>
      </section>

      {/* MANAJEMEN MODUL PRAKTIKUM */}
      <ModulPraktikumAsisten
        token={token}
        kelasId={detail.id}
      />

      {/* DAFTAR MAHASISWA */}
      <section className="asisten-content-card detail-mahasiswa-card">
        <div className="asisten-section-heading">
          <div>
            <span className="asisten-eyebrow">
              STUDENT ENROLLMENT
            </span>

            <h2>Daftar Mahasiswa</h2>

            <p>
              Mahasiswa yang ditempatkan Administrator
              pada kelas ini.
            </p>
          </div>

          <span className="asisten-total-label">
            <Users size={14} />
            {" "}{detail.total_mahasiswa} Mahasiswa
          </span>
        </div>

        {detail.daftar_mahasiswa?.length > 0 ? (
          <div className="detail-table-wrapper">
            <table className="detail-mahasiswa-table">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Nama Mahasiswa</th>
                  <th>NIM</th>
                  <th>Program Studi</th>
                </tr>
              </thead>

              <tbody>
                {detail.daftar_mahasiswa.map(
                  (mahasiswa, index) => (
                    <tr key={mahasiswa.id}>
                      <td>
                        <span className="detail-row-number">
                          {String(index + 1).padStart(2, "0")}
                        </span>
                      </td>

                      <td>
                        <div className="detail-student-name">
                          <div className="detail-student-avatar">
                            <UserRound size={17} />
                          </div>

                          <strong>
                            {mahasiswa.nama_lengkap}
                          </strong>
                        </div>
                      </td>

                      <td>
                        {mahasiswa.nim || "-"}
                      </td>

                      <td>
                        <span className="detail-prodi-badge">
                          {mahasiswa.program_studi || "-"}
                        </span>
                      </td>
                    </tr>
                  )
                )}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="asisten-empty-state">
            <div className="asisten-empty-icon">
              <Users size={27} />
            </div>

            <h3>Belum Ada Mahasiswa</h3>

            <p>
              Belum ada mahasiswa yang ditempatkan
              pada kelas ini oleh Administrator.
            </p>
          </div>
        )}
      </section>
    </div>
  );
}
