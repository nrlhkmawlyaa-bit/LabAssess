
import { useEffect, useRef, useState } from "react";

import {
  BookOpen,
  Plus,
  RefreshCw,
  Pencil,
  Trash2,
  X,
  Save,
  Eye,
  EyeOff,
  FileText,
  CircleCheck,
  Clock3,
  AlertCircle,
  Paperclip,
  Upload,
  Download,
  File,
  FileImage,
  FileArchive,
  FileSpreadsheet,
  FileVideo,
  FileAudio,
  LoaderCircle,
} from "lucide-react";

import {
  ambilDaftarModulPraktikum,
  tambahModulPraktikum,
  ubahModulPraktikum,
  hapusModulPraktikum,
  publikasikanModulPraktikum,
  tarikPublikasiModulPraktikum,
  unggahFileModulPraktikum,
  ambilDaftarFileModulPraktikum,
  unduhFileModulPraktikum,
  hapusFileModulPraktikum,
} from "../../services/academicService";


export default function ModulPraktikumAsisten({
  token,
  kelasId,
}) {
  const [modul, setModul] = useState([]);
  const [lampiran, setLampiran] = useState({});

  const [loading, setLoading] = useState(true);
  const [menyimpan, setMenyimpan] = useState(false);
  const [uploadingId, setUploadingId] = useState(null);
  const [downloadingId, setDownloadingId] = useState(null);

  const [fileTerpilih, setFileTerpilih] = useState({});

  const inputFileRefs = useRef({});

  const [modalTerbuka, setModalTerbuka] = useState(false);
  const [modulDiedit, setModulDiedit] = useState(null);

  const [pesan, setPesan] = useState("");
  const [jenisPesan, setJenisPesan] = useState("error");

  const [form, setForm] = useState({
    module_number: "",
    title: "",
    description: "",
  });


  // =====================================================
  // FORMAT UKURAN FILE
  // =====================================================

  function formatUkuranFile(byte) {
    if (!byte) return "0 Byte";

    const satuan = ["Byte", "KB", "MB", "GB"];
    const indeks = Math.floor(
      Math.log(byte) / Math.log(1024)
    );

    const ukuran = byte / Math.pow(1024, indeks);

    return `${ukuran.toFixed(indeks === 0 ? 0 : 2)} ${
      satuan[indeks] || "GB"
    }`;
  }


  // =====================================================
  // FORMAT EKSTENSI FILE
  // =====================================================

  function formatEkstensi(namaFile) {
    const bagian = namaFile.split(".");
    return bagian.length > 1
      ? bagian.pop().toUpperCase()
      : "FILE";
  }


  // =====================================================
  // ICON BERDASARKAN JENIS FILE
  // =====================================================

  function iconFile(namaFile) {
    const ekstensi = formatEkstensi(namaFile);

    const gambar = ["PNG", "JPG", "JPEG", "WEBP", "GIF"];
    const arsip = ["ZIP", "RAR", "7Z", "TAR"];
    const spreadsheet = ["XLS", "XLSX", "CSV"];
    const video = ["MP4", "MKV", "AVI", "MOV"];
    const audio = ["MP3", "WAV", "AAC"];

    if (gambar.includes(ekstensi)) {
      return <FileImage size={19} />;
    }

    if (arsip.includes(ekstensi)) {
      return <FileArchive size={19} />;
    }

    if (spreadsheet.includes(ekstensi)) {
      return <FileSpreadsheet size={19} />;
    }

    if (video.includes(ekstensi)) {
      return <FileVideo size={19} />;
    }

    if (audio.includes(ekstensi)) {
      return <FileAudio size={19} />;
    }

    if (["PDF", "DOC", "DOCX", "TXT", "PPT", "PPTX"].includes(ekstensi)) {
      return <FileText size={19} />;
    }

    return <File size={19} />;
  }


  // =====================================================
  // MUAT DAFTAR MODUL
  // =====================================================

  async function muatModul() {
    setLoading(true);
    setPesan("");

    try {
      const hasil = await ambilDaftarModulPraktikum(
        token,
        kelasId
      );

      const daftar = Array.isArray(hasil) ? hasil : [];

      setModul(daftar);

      // Bersihkan pilihan file untuk modul yang sudah tidak ada.
      setFileTerpilih((sebelumnya) => {
        const terbaru = {};

        daftar.forEach((item) => {
          if (sebelumnya[item.id]) {
            terbaru[item.id] = sebelumnya[item.id];
          }
        });

        return terbaru;
      });

    } catch (error) {
      setPesan(error.message);
      setJenisPesan("error");
    } finally {
      setLoading(false);
    }
  }


  // =====================================================
  // MUAT DAFTAR LAMPIRAN PER MODUL
  // =====================================================

  async function muatLampiran(modulId) {
    try {
      const hasil = await ambilDaftarFileModulPraktikum(
        token,
        modulId
      );

      setLampiran((sebelumnya) => ({
        ...sebelumnya,
        [modulId]: Array.isArray(hasil) ? hasil : [],
      }));

    } catch (error) {
      setPesan(
        `Gagal memuat lampiran modul: ${error.message}`
      );
      setJenisPesan("error");
    }
  }


  // =====================================================
  // LOAD AWAL
  // =====================================================

  useEffect(() => {
    if (token && kelasId) {
      muatModul();
    }
  }, [token, kelasId]);


  // =====================================================
  // LOAD LAMPIRAN SETELAH MODUL TERSEDIA
  // =====================================================

  useEffect(() => {
    if (!token || modul.length === 0) return;

    modul.forEach((item) => {
      muatLampiran(item.id);
    });
  }, [modul, token]);


  // =====================================================
  // TAMBAH MODUL
  // =====================================================

  function bukaTambah() {
    setModulDiedit(null);

    setForm({
      module_number: "",
      title: "",
      description: "",
    });

    setPesan("");
    setModalTerbuka(true);
  }


  // =====================================================
  // EDIT MODUL
  // =====================================================

  function bukaEdit(item) {
    setModulDiedit(item);

    setForm({
      module_number: String(item.module_number),
      title: item.title,
      description: item.description || "",
    });

    setPesan("");
    setModalTerbuka(true);
  }


  function tutupModal() {
    if (menyimpan) return;

    setModalTerbuka(false);
    setModulDiedit(null);
  }


  function ubahForm(event) {
    const { name, value } = event.target;

    setForm((sebelumnya) => ({
      ...sebelumnya,
      [name]: value,
    }));
  }


  // =====================================================
  // SIMPAN MODUL
  // =====================================================

  async function simpanModul(event) {
    event.preventDefault();

    if (!form.module_number || !form.title.trim()) {
      setPesan("Nomor dan judul modul wajib diisi.");
      setJenisPesan("error");
      return;
    }

    const data = {
      module_number: Number(form.module_number),
      title: form.title.trim(),
      description: form.description.trim() || null,
    };

    setMenyimpan(true);
    setPesan("");

    try {
      if (modulDiedit) {
        await ubahModulPraktikum(
          token,
          modulDiedit.id,
          data
        );
      } else {
        await tambahModulPraktikum(
          token,
          kelasId,
          data
        );
      }

      const sedangEdit = Boolean(modulDiedit);

      setModalTerbuka(false);
      setModulDiedit(null);

      await muatModul();

      setPesan(
        sedangEdit
          ? "Modul berhasil diperbarui."
          : "Modul berhasil ditambahkan."
      );

      setJenisPesan("success");

    } catch (error) {
      setPesan(error.message);
      setJenisPesan("error");
    } finally {
      setMenyimpan(false);
    }
  }


  // =====================================================
  // PUBLIKASI MODUL
  // =====================================================

  async function ubahStatusPublikasi(item) {
    const konfirmasi = window.confirm(
      item.is_published
        ? `Tarik publikasi modul "${item.title}"?`
        : `Publikasikan modul "${item.title}"?`
    );

    if (!konfirmasi) return;

    try {
      setPesan("");

      if (item.is_published) {
        await tarikPublikasiModulPraktikum(
          token,
          item.id
        );
      } else {
        await publikasikanModulPraktikum(
          token,
          item.id
        );
      }

      await muatModul();

      setPesan(
        item.is_published
          ? "Publikasi modul berhasil ditarik."
          : "Modul berhasil dipublikasikan."
      );

      setJenisPesan("success");

    } catch (error) {
      setPesan(error.message);
      setJenisPesan("error");
    }
  }


  // =====================================================
  // HAPUS MODUL
  // =====================================================

  async function hapusModul(item) {
    const konfirmasi = window.confirm(
      `Yakin ingin menghapus modul "${item.title}"? Seluruh lampirannya juga akan terhapus.`
    );

    if (!konfirmasi) return;

    try {
      setPesan("");

      await hapusModulPraktikum(token, item.id);

      setLampiran((sebelumnya) => {
        const terbaru = { ...sebelumnya };
        delete terbaru[item.id];
        return terbaru;
      });

      await muatModul();

      setPesan("Modul berhasil dihapus.");
      setJenisPesan("success");

    } catch (error) {
      setPesan(error.message);
      setJenisPesan("error");
    }
  }


  // =====================================================
  // PILIH FILE
  // =====================================================

  function pilihFile(modulId, event) {
    const daftar = Array.from(event.target.files || []);

    setFileTerpilih((sebelumnya) => ({
      ...sebelumnya,
      [modulId]: daftar,
    }));
  }


  // =====================================================
  // UPLOAD FILE
  // =====================================================

  async function uploadLampiran(modulId) {
    const daftar = fileTerpilih[modulId] || [];

    if (daftar.length === 0) {
      setPesan("Pilih minimal satu file terlebih dahulu.");
      setJenisPesan("error");
      return;
    }

    setUploadingId(modulId);
    setPesan("");

    try {
      const hasil = await unggahFileModulPraktikum(
        token,
        modulId,
        daftar
      );

      setFileTerpilih((sebelumnya) => ({
        ...sebelumnya,
        [modulId]: [],
      }));

      if (inputFileRefs.current[modulId]) {
        inputFileRefs.current[modulId].value = "";
      }

      await muatLampiran(modulId);

      setPesan(
        `${hasil.length} file berhasil diunggah.`
      );

      setJenisPesan("success");

    } catch (error) {
      await muatLampiran(modulId);

      setPesan(error.message);
      setJenisPesan("error");
    } finally {
      setUploadingId(null);
    }
  }


  // =====================================================
  // DOWNLOAD FILE
  // =====================================================

  async function downloadLampiran(item, file) {
    setDownloadingId(file.id);
    setPesan("");

    try {
      await unduhFileModulPraktikum(
        token,
        item.id,
        file.id,
        file.original_filename
      );

    } catch (error) {
      setPesan(error.message);
      setJenisPesan("error");
    } finally {
      setDownloadingId(null);
    }
  }


  // =====================================================
  // HAPUS FILE
  // =====================================================

  async function hapusLampiran(item, file) {
    const konfirmasi = window.confirm(
      `Yakin ingin menghapus lampiran "${file.original_filename}"?`
    );

    if (!konfirmasi) return;

    try {
      setPesan("");

      await hapusFileModulPraktikum(
        token,
        item.id,
        file.id
      );

      await muatLampiran(item.id);

      setPesan("Lampiran berhasil dihapus.");
      setJenisPesan("success");

    } catch (error) {
      setPesan(error.message);
      setJenisPesan("error");
    }
  }


  // =====================================================
  // RENDER
  // =====================================================

  return (
    <section className="modul-praktikum-section">

      {/* HEADING */}

      <div className="modul-heading">
        <div>
          <span className="asisten-eyebrow">
            PRACTICUM MATERIALS
          </span>

          <h2>Modul Praktikum</h2>

          <p>
            Kelola materi dan lampiran praktikum
            untuk mahasiswa pada kelas ini.
          </p>
        </div>

        <button
          type="button"
          className="modul-add-button"
          onClick={bukaTambah}
        >
          <Plus size={17} />
          Tambah Modul
        </button>
      </div>


      {/* PESAN */}

      {pesan && (
        <div
          className={`modul-message ${jenisPesan}`}
          role="status"
        >
          {jenisPesan === "success" ? (
            <CircleCheck size={17} />
          ) : (
            <AlertCircle size={17} />
          )}

          <span>{pesan}</span>

          <button
            type="button"
            onClick={() => setPesan("")}
            aria-label="Tutup pesan"
          >
            <X size={15} />
          </button>
        </div>
      )}


      {/* LOADING */}

      {loading ? (
        <div className="modul-loading">
          <RefreshCw className="spinning" size={24} />
          <span>Memuat modul praktikum...</span>
        </div>

      ) : modul.length === 0 ? (

        /* EMPTY STATE */

        <div className="modul-empty">
          <div className="modul-empty-icon">
            <BookOpen size={29} />
          </div>

          <h3>Belum Ada Modul Praktikum</h3>

          <p>
            Mulai susun materi praktikum dengan
            menambahkan modul pertama untuk kelas ini.
          </p>

          <button
            type="button"
            className="modul-empty-button"
            onClick={bukaTambah}
          >
            <Plus size={16} />
            Tambah Modul Pertama
          </button>
        </div>

      ) : (

        /* DAFTAR MODUL */

        <div className="modul-list">

          {modul.map((item) => {
            const daftarLampiran = lampiran[item.id] || [];
            const daftarFile = fileTerpilih[item.id] || [];

            return (
              <article
                className="modul-card"
                key={item.id}
              >

                {/* INFORMASI MODUL */}

                <div className="modul-card-main">

                  <div className="modul-number">
                    {String(item.module_number).padStart(2, "0")}
                  </div>

                  <div className="modul-card-content">

                    <div className="modul-card-topline">

                      <span className="modul-label">
                        MODUL {item.module_number}
                      </span>

                      <span
                        className={`modul-status ${
                          item.is_published
                            ? "published"
                            : "draft"
                        }`}
                      >
                        {item.is_published ? (
                          <CircleCheck size={13} />
                        ) : (
                          <Clock3 size={13} />
                        )}

                        {item.is_published
                          ? "Dipublikasikan"
                          : "Draft"}
                      </span>

                    </div>

                    <h3>{item.title}</h3>

                    <p>
                      {item.description ||
                        "Belum ada deskripsi untuk modul ini."}
                    </p>

                  </div>
                </div>


                {/* AKSI MODUL */}

                <div className="modul-card-actions">

                  <button
                    type="button"
                    className="modul-action-button publish"
                    onClick={() => ubahStatusPublikasi(item)}
                  >
                    {item.is_published ? (
                      <EyeOff size={16} />
                    ) : (
                      <Eye size={16} />
                    )}

                    <span>
                      {item.is_published
                        ? "Tarik Publikasi"
                        : "Publikasikan"}
                    </span>
                  </button>

                  <button
                    type="button"
                    className="modul-action-button edit"
                    onClick={() => bukaEdit(item)}
                  >
                    <Pencil size={16} />
                    <span>Edit</span>
                  </button>

                  <button
                    type="button"
                    className="modul-action-button delete"
                    onClick={() => hapusModul(item)}
                  >
                    <Trash2 size={16} />
                    <span>Hapus</span>
                  </button>

                </div>


                {/* AREA LAMPIRAN */}

                <div className="modul-attachment-section">

                  <div className="modul-attachment-heading">

                    <div className="modul-attachment-title">
                      <Paperclip size={17} />

                      <h4>Lampiran Modul</h4>

                      <span className="modul-attachment-count">
                        {daftarLampiran.length}
                      </span>
                    </div>

                    <span className="modul-attachment-hint">
                      Materi dan file pendukung
                    </span>

                  </div>


                  {/* DAFTAR LAMPIRAN */}

                  {lampiran[item.id] === undefined ? (

                    <div className="modul-attachment-loading">
                      <LoaderCircle
                        size={16}
                        className="spinning"
                      />
                      Memuat lampiran...
                    </div>

                  ) : daftarLampiran.length === 0 ? (

                    <div className="modul-attachment-empty">
                      <FileText size={20} />

                      <span>
                        Belum ada lampiran pada modul ini.
                      </span>
                    </div>

                  ) : (

                    <div className="modul-file-list">

                      {daftarLampiran.map((file) => (

                        <div
                          className="modul-file-item"
                          key={file.id}
                        >

                          <div className="modul-file-icon">
                            {iconFile(file.original_filename)}
                          </div>

                          <div className="modul-file-info">

                            <strong title={file.original_filename}>
                              {file.original_filename}
                            </strong>

                            <span>
                              {formatEkstensi(file.original_filename)}
                              {" · "}
                              {formatUkuranFile(file.file_size)}
                            </span>

                          </div>

                          <div className="modul-file-actions">

                            <button
                              type="button"
                              className="modul-file-download"
                              onClick={() =>
                                downloadLampiran(item, file)
                              }
                              disabled={downloadingId === file.id}
                              title="Download lampiran"
                            >
                              {downloadingId === file.id ? (
                                <LoaderCircle
                                  size={16}
                                  className="spinning"
                                />
                              ) : (
                                <Download size={16} />
                              )}
                            </button>

                            <button
                              type="button"
                              className="modul-file-delete"
                              onClick={() =>
                                hapusLampiran(item, file)
                              }
                              title="Hapus lampiran"
                            >
                              <Trash2 size={16} />
                            </button>

                          </div>

                        </div>

                      ))}

                    </div>
                  )}


                  {/* FORM UPLOAD */}

                  <div className="modul-upload-area">

                    <input
                      ref={(element) => {
                        inputFileRefs.current[item.id] = element;
                      }}
                      type="file"
                      multiple
                      className="modul-file-input"
                      onChange={(event) =>
                        pilihFile(item.id, event)
                      }
                    />

                    <div className="modul-upload-controls">

                      <label
                        htmlFor={`file-modul-${item.id}`}
                        className="modul-file-picker"
                      >
                        <Paperclip size={16} />
                        Pilih File
                      </label>

                      <input
                        id={`file-modul-${item.id}`}
                        type="file"
                        multiple
                        className="modul-file-hidden"
                        onChange={(event) =>
                          pilihFile(item.id, event)
                        }
                        disabled={uploadingId === item.id}
                      />

                      <button
                        type="button"
                        className="modul-upload-button"
                        onClick={() => uploadLampiran(item.id)}
                        disabled={
                          daftarFile.length === 0 ||
                          uploadingId === item.id
                        }
                      >
                        {uploadingId === item.id ? (
                          <>
                            <LoaderCircle
                              size={16}
                              className="spinning"
                            />
                            Mengunggah...
                          </>
                        ) : (
                          <>
                            <Upload size={16} />
                            Upload
                          </>
                        )}
                      </button>

                    </div>


                    {daftarFile.length > 0 && (

                      <div className="modul-selected-files">

                        <div className="modul-selected-heading">
                          {daftarFile.length} file dipilih
                        </div>

                        {daftarFile.map((file, index) => (
                          <div
                            className="modul-selected-file"
                            key={`${file.name}-${index}`}
                          >
                            <File size={14} />

                            <span>{file.name}</span>

                            <small>
                              {formatUkuranFile(file.size)}
                            </small>
                          </div>
                        ))}

                      </div>
                    )}

                    <p className="modul-upload-note">
                      Pilih satu atau beberapa file sekaligus.
                      Ukuran maksimal 50 MB per file.
                    </p>

                  </div>

                </div>

              </article>
            );
          })}

        </div>
      )}


      {/* MODAL TAMBAH / EDIT MODUL */}

      {modalTerbuka && (

        <div
          className="modul-modal-overlay"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              tutupModal();
            }
          }}
        >

          <section
            className="modul-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="modul-modal-title"
          >

            <div className="modul-modal-heading">

              <div className="modul-modal-icon">
                <FileText size={22} />
              </div>

              <div>
                <span className="asisten-eyebrow">
                  PRACTICUM MATERIAL
                </span>

                <h2 id="modul-modal-title">
                  {modulDiedit
                    ? "Edit Modul"
                    : "Tambah Modul"}
                </h2>
              </div>

              <button
                type="button"
                className="modul-modal-close"
                onClick={tutupModal}
                disabled={menyimpan}
              >
                <X size={19} />
              </button>

            </div>


            <form onSubmit={simpanModul}>

              <div className="modul-form-field">

                <label htmlFor="module_number">
                  Nomor Modul
                </label>

                <input
                  id="module_number"
                  name="module_number"
                  type="number"
                  min="1"
                  step="1"
                  value={form.module_number}
                  onChange={ubahForm}
                  placeholder="Contoh: 1"
                  required
                />

              </div>


              <div className="modul-form-field">

                <label htmlFor="title">
                  Judul Modul
                </label>

                <input
                  id="title"
                  name="title"
                  type="text"
                  minLength="3"
                  maxLength="150"
                  value={form.title}
                  onChange={ubahForm}
                  placeholder="Masukkan judul modul praktikum"
                  required
                />

              </div>


              <div className="modul-form-field">

                <label htmlFor="description">
                  Deskripsi Modul
                  <span>Opsional</span>
                </label>

                <textarea
                  id="description"
                  name="description"
                  rows="4"
                  value={form.description}
                  onChange={ubahForm}
                  placeholder="Tuliskan ringkasan materi praktikum..."
                />

              </div>


              <div className="modul-modal-actions">

                <button
                  type="button"
                  className="modul-cancel-button"
                  onClick={tutupModal}
                  disabled={menyimpan}
                >
                  Batal
                </button>

                <button
                  type="submit"
                  className="modul-save-button"
                  disabled={menyimpan}
                >
                  {menyimpan ? (
                    <RefreshCw
                      size={16}
                      className="spinning"
                    />
                  ) : (
                    <Save size={16} />
                  )}

                  {menyimpan
                    ? "Menyimpan..."
                    : "Simpan Modul"}
                </button>

              </div>

            </form>

          </section>

        </div>
      )}

    </section>
  );
}
