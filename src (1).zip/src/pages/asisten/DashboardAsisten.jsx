
import { useEffect, useMemo, useState } from "react";

import {
  Monitor,
  LayoutDashboard,
  BookOpen,
  Users,
  Activity,
  LogOut,
  Menu,
  X,
  RefreshCw,
  CalendarDays,
  ArrowUpRight,
  CircleCheck,
  CircleAlert,
  ClipboardList,
  ChartNoAxesCombined,
  Plus, ArrowLeft, Pencil, Trash2, Copy, Save,
} from "lucide-react";

import {
  ambilDashboardAsisten,
  ambilDetailKelasAsisten,
  ambilDaftarKuisAsisten,
  buatKuisAsisten,
  ambilDaftarSoalKuisAsisten,
  tambahSoalKuisAsisten,
  ubahStatusKuisAsisten,
  ubahSoalKuisAsisten,
  ubahOpsiSoalKuisAsisten,
  hapusSoalKuisAsisten,
  resetPengerjaanMahasiswaAsisten,
} from "../../services/academicService";

import DetailKelasAsisten from "./DetailKelasAsisten";
import RekapNilaiAsisten from "./RekapNilaiAsisten";
import "../../styles/asisten.css";

// Endpoint pembaruan konfigurasi kuis yang sudah tersedia di backend.
async function perbaruiKuisAsisten(token, kuisId, data) {
  const response = await fetch(`/api/v1/asisten/kuis/${kuisId}`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(data),
  });
  const hasil = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = hasil.detail;
    const pesan = typeof detail === "string"
      ? detail
      : Array.isArray(detail)
        ? detail.map((item) => item.msg).join(", ")
        : "Gagal memperbarui pengaturan kuis.";
    throw new Error(pesan);
  }
  return hasil;
}

const MENU_ASISTEN = [
  {
    id: "overview",
    label: "Overview",
    icon: LayoutDashboard,
  },
  { id: "kelas", label: "Kelas Saya", icon: BookOpen },
  { id: "kuis", label: "Pre-Test & Post-Test", icon: ClipboardList },

  {
  id: "rekap-nilai",
  label: "Rekap Nilai",
  icon: ChartNoAxesCombined,
},

];


export default function DashboardAsisten({
  pengguna,
  token,
  onLogout,
}) {
  const [menuAktif, setMenuAktif] = useState("overview");

  const [menuMobileTerbuka, setMenuMobileTerbuka] =
    useState(false);

  const [dashboard, setDashboard] = useState(null);

  const [loading, setLoading] = useState(true);

  const [pesan, setPesan] = useState("");

  const [kelasTerpilih, setKelasTerpilih] = useState(null);

  const [detailKelas, setDetailKelas] = useState(null);

  const [loadingDetail, setLoadingDetail] = useState(false);

  const [pesanDetail, setPesanDetail] = useState("");
  const [kelasKuis, setKelasKuis] = useState(null);
  const [daftarKuis, setDaftarKuis] = useState([]);
  const [loadingKuis, setLoadingKuis] = useState(false);
  const [pesanKuis, setPesanKuis] = useState("");
  const [formKuis, setFormKuis] = useState(null);
  const [modeFormKuis, setModeFormKuis] = useState("create");
  const [kuisAktif, setKuisAktif] = useState(null);
  const [daftarSoal, setDaftarSoal] = useState([]);
  const [formSoal, setFormSoal] = useState(null);
  const [busyKuis, setBusyKuis] = useState(false);
  const [tampilanKuis, setTampilanKuis] = useState("daftar");
  const [editSoalId, setEditSoalId] = useState(null);
  const [daftarMahasiswaReset, setDaftarMahasiswaReset] = useState([]);
  const [mahasiswaResetId, setMahasiswaResetId] = useState("");
  const [pesanReset, setPesanReset] = useState("");


  async function muatDashboard() {
    setLoading(true);
    setPesan("");

    try {
      const hasil = await ambilDashboardAsisten(token);
      setDashboard(hasil);
    } catch (error) {
      setPesan(error.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    muatDashboard();
  }, [token]);

  const daftarKelas = useMemo(() => {
    return dashboard?.daftar_kelas || [];
  }, [dashboard]);

  const namaAsisten =
    dashboard?.nama_asisten ||
    pengguna?.nama_lengkap ||
    "Asisten Laboratorium";

  function pilihMenu(id) {
    setMenuAktif(id);
    setKelasTerpilih(null);
    setDetailKelas(null);
    setPesanDetail("");
    setKelasKuis(null); setKuisAktif(null); setTampilanKuis("daftar"); setFormKuis(null); setFormSoal(null);
    setMenuMobileTerbuka(false);
  }

  async function bukaDetailKelas(kelas) {
    setKelasTerpilih(kelas);
    setDetailKelas(null);
    setPesanDetail("");
    setLoadingDetail(true);

    try {
      const hasil = await ambilDetailKelasAsisten(
        token,
        kelas.id
      );

      setDetailKelas(hasil);
    } catch (error) {
      setPesanDetail(error.message);
    } finally {
      setLoadingDetail(false);
    }
  }

  function kembaliKeDaftarKelas() {
    setKelasTerpilih(null);
    setDetailKelas(null);
    setPesanDetail("");
  }

  async function muatKuis(kelas) {
    setKelasKuis(kelas);
    setKuisAktif(null);
    setTampilanKuis("daftar");
    setFormKuis(null);
    setFormSoal(null);
    setPesanKuis("");
    setPesanReset("");
    setMahasiswaResetId("");
    setDaftarMahasiswaReset([]);
    setLoadingKuis(true);

    try {
      const data = await ambilDaftarKuisAsisten(token, kelas.id);
      setDaftarKuis(Array.isArray(data) ? data : data?.data || []);
    } catch (error) {
      setPesanKuis(error.message);
      setDaftarKuis([]);
    }

    // Detail kelas sudah menyediakan daftar mahasiswa yang terdaftar.
    // Ambil data tersebut untuk mengisi pilihan pada fitur reset percobaan.
    try {
      const detail = await ambilDetailKelasAsisten(token, kelas.id);
      setDaftarMahasiswaReset(
        Array.isArray(detail?.daftar_mahasiswa) ? detail.daftar_mahasiswa : []
      );
    } catch (error) {
      setPesanReset(`Daftar mahasiswa gagal dimuat: ${error.message}`);
    } finally {
      setLoadingKuis(false);
    }
  }

  async function resetPengerjaanMahasiswa() {
    if (!kelasKuis || !kuisAktif || !mahasiswaResetId) return;

    const mahasiswa = daftarMahasiswaReset.find(
      (item) => String(item.id) === String(mahasiswaResetId)
    );
    const namaMahasiswa = mahasiswa?.nama_lengkap || "mahasiswa ini";

    const disetujui = window.confirm(
      `Reset pengerjaan ${namaMahasiswa} pada kuis "${kuisAktif.title}"? Riwayat pengerjaan, jawaban, dan nilai untuk kuis ini akan dihapus.`
    );
    if (!disetujui) return;

    setBusyKuis(true);
    setPesanKuis("");
    setPesanReset("");

    try {
      await resetPengerjaanMahasiswaAsisten(
        token,
        kuisAktif.id,
        mahasiswaResetId
      );
      setMahasiswaResetId("");
      setPesanReset(
        `Pengerjaan ${namaMahasiswa} berhasil direset. Mahasiswa dapat mengerjakan kuis ini kembali.`
      );
    } catch (error) {
      setPesanKuis(error.message || "Gagal mereset pengerjaan mahasiswa.");
    } finally {
      setBusyKuis(false);
    }
  }

  function keInputTanggalLokal(value) {
    if (!value) return "";
    const date = new Date(value);
    const offset = date.getTimezoneOffset() * 60000;
    return new Date(date.getTime() - offset).toISOString().slice(0, 16);
  }

  function mulaiEditPengaturanKuis(kuis) {
    if (kuis.status !== "draft") {
      setPesanKuis("Kembalikan kuis ke Draft terlebih dahulu sebelum mengubah jadwal.");
      return;
    }
    setModeFormKuis("edit");
    setFormKuis({
      id: kuis.id,
      quiz_type: kuis.quiz_type,
      title: kuis.title,
      description: kuis.description || "",
      start_at: keInputTanggalLokal(kuis.start_at),
      end_at: keInputTanggalLokal(kuis.end_at),
      duration_minutes: kuis.duration_minutes,
      shuffle_questions: kuis.shuffle_questions,
      shuffle_options: kuis.shuffle_options,
    });
    setPesanKuis("");
  }

  function ubahBagianWaktuKuis(field, bagian, value) {
    setFormKuis((sebelumnya) => {
      const [tanggalLama = "", jamLama = ""] = (sebelumnya[field] || "").split("T");
      const tanggal = bagian === "tanggal" ? value : tanggalLama;
      const jam = bagian === "jam" ? value : jamLama;

      // Simpan tanggal dan jam secara terpisah sampai keduanya terisi.
      // Ini mencegah input tanggal terhapus saat pengguna memilih jam, atau sebaliknya.
      return {
        ...sebelumnya,
        [field]: tanggal || jam ? `${tanggal}T${jam}` : "",
      };
    });
  }

  async function simpanKuis() {
    if (!formKuis?.start_at || !formKuis?.end_at) {
      setPesanKuis("Tanggal dan jam mulai serta selesai wajib diisi.");
      return;
    }

    const waktuMulai = new Date(formKuis.start_at);
    const waktuSelesai = new Date(formKuis.end_at);

    if (Number.isNaN(waktuMulai.getTime()) || Number.isNaN(waktuSelesai.getTime())) {
      setPesanKuis("Tanggal atau jam tidak valid. Periksa kembali jadwal kuis.");
      return;
    }

    if (waktuSelesai <= waktuMulai) {
      setPesanKuis("Waktu selesai harus setelah waktu mulai.");
      return;
    }

    setBusyKuis(true); setPesanKuis("");
    try {
      const payload = {
        ...formKuis,
        duration_minutes: Number(formKuis.duration_minutes),
        start_at: waktuMulai.toISOString(),
        end_at: waktuSelesai.toISOString(),
      };
      if (modeFormKuis === "edit") {
        delete payload.id;
        delete payload.quiz_type;
        await perbaruiKuisAsisten(token, formKuis.id, payload);
      } else {
        payload.class_id = Number(kelasKuis.id);
        await buatKuisAsisten(token, kelasKuis.id, payload);
      }
      setFormKuis(null);
      setModeFormKuis("create");
      await muatKuis(kelasKuis);
    } catch (error) { setPesanKuis(error.message); }
    finally { setBusyKuis(false); }
  }

  async function kelolaSoal(kuis) {
    setKuisAktif(kuis); setFormSoal(null); setEditSoalId(null); setTampilanKuis("editor"); setLoadingKuis(true);
    try { const data = await ambilDaftarSoalKuisAsisten(token, kuis.id); setDaftarSoal(Array.isArray(data) ? data : data?.data || []); }
    catch (error) { setPesanKuis(error.message); }
    finally { setLoadingKuis(false); }
  }

  async function setStatusKuis(kuis, status) {
    const labelStatus = status === "published" ? "mempublikasikan" : status === "draft" ? "mengembalikan kuis ke Draft" : "menutup";
    if (status === "draft" && !window.confirm("Kembalikan kuis ini ke Draft? Mahasiswa tidak dapat mengaksesnya selama status Draft.")) return;
    if (status === "closed" && !window.confirm("Tutup kuis ini? Mahasiswa tidak dapat mengakses kuis selama status Ditutup.")) return;
    if (status === "published" && kuis.status === "closed" && !window.confirm("Buka kembali kuis ini? Kuis akan berstatus Dipublikasikan dan mengikuti jadwal yang sudah diatur.")) return;

    setBusyKuis(true);
    setPesanKuis("");
    try {
      await ubahStatusKuisAsisten(token, kuis.id, status);
      const data = await ambilDaftarKuisAsisten(token, kelasKuis.id);
      const daftarTerbaru = Array.isArray(data) ? data : data?.data || [];
      setDaftarKuis(daftarTerbaru);
      const kuisTerbaru = daftarTerbaru.find((item) => item.id === kuis.id);
      if (kuisTerbaru && kuisAktif?.id === kuis.id) setKuisAktif(kuisTerbaru);
    } catch (error) {
      setPesanKuis(error.message || `Gagal ${labelStatus} kuis.`);
    } finally {
      setBusyKuis(false);
    }
  }

  function mulaiTambahSoal() {
    setEditSoalId(null);
    setFormSoal({ question_text: "", question_type: "multiple_choice", points: 10,
      options: [{ option_text: "", is_correct: true }, { option_text: "", is_correct: false }] });
  }

  function mulaiEditSoal(soal) {
    setEditSoalId(soal.id);
    setFormSoal({ question_text: soal.question_text, question_type: soal.question_type,
      points: soal.points, options: (soal.options || []).map(o => ({option_text:o.option_text,is_correct:o.is_correct})) });
  }

  async function hapusSoal(soal) {
    if (!window.confirm("Hapus pertanyaan ini?")) return;
    setBusyKuis(true);
    try {
      await hapusSoalKuisAsisten(token, kuisAktif.id, soal.id);
      const data = await ambilDaftarSoalKuisAsisten(token, kuisAktif.id);
      setDaftarSoal(Array.isArray(data) ? data : data?.data || []);
    } catch (error) { setPesanKuis(error.message); }
    finally { setBusyKuis(false); }
  }

  async function simpanSoal() {
    setBusyKuis(true); setPesanKuis("");
    try {
      const options = formSoal.question_type === "multiple_choice"
        ? formSoal.options.map((o,i)=>({option_text:o.option_text.trim(),is_correct:!!o.is_correct,option_order:i+1})) : [];
      const payload = { question_text:formSoal.question_text.trim(), question_type:formSoal.question_type,
        question_order:editSoalId ? (daftarSoal.find(x=>x.id===editSoalId)?.question_order || 1) : daftarSoal.length+1,
        points:Number(formSoal.points) };
      if (editSoalId) {
        await ubahSoalKuisAsisten(token,kuisAktif.id,editSoalId,payload);
        await ubahOpsiSoalKuisAsisten(token,kuisAktif.id,editSoalId,options);
      } else {
        await tambahSoalKuisAsisten(token,kuisAktif.id,{...payload,options});
      }
      const data=await ambilDaftarSoalKuisAsisten(token,kuisAktif.id);
      setDaftarSoal(Array.isArray(data)?data:data?.data||[]);
      setFormSoal(null); setEditSoalId(null);
    } catch(error) { setPesanKuis(error.message); }
    finally { setBusyKuis(false); }
  }

  async function duplikatSoal(soal) {
    setBusyKuis(true);
    try {
      await tambahSoalKuisAsisten(token,kuisAktif.id,{
        question_text:soal.question_text, question_type:soal.question_type,
        question_order:daftarSoal.length+1, points:Number(soal.points),
        options:(soal.options||[]).map((o,i)=>({option_text:o.option_text,is_correct:o.is_correct,option_order:i+1}))
      });
      const data=await ambilDaftarSoalKuisAsisten(token,kuisAktif.id);
      setDaftarSoal(Array.isArray(data)?data:data?.data||[]);
    } catch(error) { setPesanKuis(error.message); }
    finally { setBusyKuis(false); }
  }

  function renderEditorSoal() {
    const totalBobot=daftarSoal.reduce((a,q)=>a+Number(q.points||0),0);
    const kuisDraft = kuisAktif.status === "draft";
    const labelStatus = kuisAktif.status === "published" ? "Dipublikasikan" : kuisAktif.status === "closed" ? "Ditutup" : "Draft";
    return <section className="asisten-content-card asisten-quiz-editor-page">
      <button className="asisten-quiz-back" type="button" onClick={()=>{setTampilanKuis("daftar");setKuisAktif(null);setFormSoal(null);setPesanKuis("");}}><ArrowLeft size={16}/> Kembali ke daftar kuis</button>
      <div className="asisten-quiz-editor-heading"><div><span className="asisten-eyebrow">QUIZ BUILDER</span><h2>{kuisAktif.title}</h2><p>{kelasKuis.nama_mata_kuliah} · Kelas {kelasKuis.kode_kelas}</p></div>
        <div className="asisten-quiz-editor-stats"><div><strong>{daftarSoal.length}</strong><span>Soal</span></div><div><strong>{totalBobot}</strong><span>Total bobot</span></div><div><strong>{kuisAktif.duration_minutes}</strong><span>Menit</span></div></div>
      </div>
      <div className="asisten-quiz-publish-bar">
        <div className="asisten-quiz-publish-info"><span className={`asisten-quiz-status ${kuisAktif.status}`}>{labelStatus}</span><span>{kuisDraft ? "Kuis masih berupa draft dan belum dapat diakses mahasiswa." : kuisAktif.status === "published" ? "Kuis sudah dipublikasikan. Kembalikan ke Draft jika perlu mengubah soal." : "Kuis sedang ditutup. Kamu dapat membukanya kembali selama jadwal kuis masih berlaku."}</span></div>
        <div className="asisten-quiz-publish-actions">
          {kuisDraft && <button className="asisten-quiz-primary" type="button" disabled={busyKuis || daftarSoal.length === 0} onClick={()=>setStatusKuis(kuisAktif,"published")}>{busyKuis?"Memproses...":"Publikasikan Kuis"}</button>}
          {kuisAktif.status === "published" && <><button className="asisten-quiz-secondary" type="button" disabled={busyKuis} onClick={()=>setStatusKuis(kuisAktif,"closed")}>Tutup Kuis</button><button className="asisten-quiz-secondary" type="button" disabled={busyKuis} onClick={()=>setStatusKuis(kuisAktif,"draft")}>Kembalikan ke Draft</button></>}
          {kuisAktif.status === "closed" && <button className="asisten-quiz-primary" type="button" disabled={busyKuis} onClick={()=>setStatusKuis(kuisAktif,"published")}>Buka Kembali</button>}
        </div>
      </div>
      {pesanKuis&&<div className="asisten-quiz-error">{pesanKuis}</div>}
      {pesanReset&&<div role="status" style={{ marginTop: 12, padding: "11px 14px", borderRadius: 12, background: "rgba(55, 130, 92, 0.10)", color: "#286747", fontSize: 13 }}>{pesanReset}</div>}
      <div className="asisten-quiz-compose" style={{ marginTop: 18 }}>
        <div className="asisten-quiz-compose-title">
          <div><span className="asisten-eyebrow">RESET PERCOBAAN</span><h3>Izinkan Mahasiswa Mengerjakan Ulang</h3><p style={{ margin: "6px 0 0", color: "var(--asisten-muted)" }}>Pilih satu mahasiswa. Hanya riwayat, jawaban, dan nilai pada kuis ini yang akan dihapus.</p></div>
        </div>
        <div className="asisten-quiz-compose-grid" style={{ gridTemplateColumns: "minmax(0, 1fr) auto", alignItems: "end" }}>
          <label className="asisten-quiz-field">Pilih mahasiswa
            <select value={mahasiswaResetId} onChange={(event) => setMahasiswaResetId(event.target.value)} disabled={loadingKuis || busyKuis}>
              <option value="">{loadingKuis ? "Memuat mahasiswa..." : daftarMahasiswaReset.length ? "Pilih mahasiswa dari kelas ini" : "Tidak ada mahasiswa terdaftar"}</option>
              {daftarMahasiswaReset.map((mahasiswa) => <option key={mahasiswa.id} value={mahasiswa.id}>{mahasiswa.nama_lengkap}{mahasiswa.nim ? ` — ${mahasiswa.nim}` : ""}</option>)}
            </select>
          </label>
          <button className="asisten-quiz-secondary" type="button" disabled={!mahasiswaResetId || busyKuis || daftarMahasiswaReset.length === 0} onClick={resetPengerjaanMahasiswa}><RefreshCw size={15}/>{busyKuis ? "Memproses..." : "Reset Pengerjaan"}</button>
        </div>
      </div>
      <div className="asisten-quiz-question-toolbar"><div><h3>Daftar pertanyaan</h3><p>{kuisDraft ? "Tambah, edit, duplikat, atau hapus pertanyaan." : "Pertanyaan dikunci selama kuis tidak berstatus Draft."}</p></div>{kuisDraft&&!formSoal&&<button className="asisten-quiz-primary" type="button" onClick={mulaiTambahSoal}><Plus size={16}/> Tambah Soal</button>}</div>
      {formSoal&&kuisDraft&&<div className="asisten-quiz-compose">
        <div className="asisten-quiz-compose-title"><div><span className="asisten-eyebrow">{editSoalId?"EDIT SOAL":"SOAL BARU"}</span><h3>{editSoalId?"Ubah pertanyaan":"Tambah pertanyaan"}</h3></div><button className="asisten-quiz-icon-button" onClick={()=>{setFormSoal(null);setEditSoalId(null);}} type="button"><X size={17}/></button></div>
        <div className="asisten-quiz-compose-grid">
          <label className="asisten-quiz-field asisten-quiz-field-full">Pertanyaan<textarea value={formSoal.question_text} placeholder="Tulis pertanyaan di sini..." onChange={e=>setFormSoal({...formSoal,question_text:e.target.value})}/></label>
          <label className="asisten-quiz-field">Jenis soal<select value={formSoal.question_type} onChange={e=>setFormSoal({...formSoal,question_type:e.target.value,options:e.target.value==="multiple_choice"?[{option_text:"",is_correct:true},{option_text:"",is_correct:false}]:[]})}><option value="multiple_choice">Pilihan ganda</option><option value="essay">Esai</option></select></label>
          <label className="asisten-quiz-field">Bobot nilai<input type="number" min="0.01" step="0.01" value={formSoal.points} onChange={e=>setFormSoal({...formSoal,points:e.target.value})}/></label>
        </div>
        {formSoal.question_type==="multiple_choice"&&<div className="asisten-quiz-options-editor"><h4>Opsi jawaban</h4><p>Pilih satu opsi sebagai jawaban benar.</p>
          {formSoal.options.map((o,i)=><div className="asisten-quiz-option-row" key={i}><input value={o.option_text} placeholder={`Opsi ${i+1}`} onChange={e=>setFormSoal({...formSoal,options:formSoal.options.map((x,j)=>j===i?{...x,option_text:e.target.value}:x)})}/><label className="asisten-quiz-correct"><input type="radio" name="opsi-benar" checked={o.is_correct} onChange={()=>setFormSoal({...formSoal,options:formSoal.options.map((x,j)=>({...x,is_correct:i===j}))})}/> Benar</label>{formSoal.options.length>2&&<button className="asisten-quiz-icon-button danger" type="button" onClick={()=>setFormSoal({...formSoal,options:formSoal.options.filter((_,j)=>j!==i)})}><Trash2 size={15}/></button>}</div>)}
          <button className="asisten-quiz-add-option" type="button" onClick={()=>setFormSoal({...formSoal,options:[...formSoal.options,{option_text:"",is_correct:false}]})}><Plus size={14}/> Tambah opsi</button>
        </div>}
        <div className="asisten-quiz-compose-actions"><button className="asisten-quiz-primary" type="button" disabled={busyKuis||!formSoal.question_text.trim()||(formSoal.question_type==="multiple_choice"&&(formSoal.options.length<2||formSoal.options.some(o=>!o.option_text.trim())||formSoal.options.filter(o=>o.is_correct).length!==1))} onClick={simpanSoal}><Save size={15}/>{busyKuis?"Menyimpan...":"Simpan Pertanyaan"}</button><button className="asisten-quiz-secondary" type="button" onClick={()=>{setFormSoal(null);setEditSoalId(null);}}>Batal</button></div>
      </div>}
      {loadingKuis?<div className="asisten-loading">Memuat pertanyaan...</div>:<div className="asisten-quiz-question-list">
        {daftarSoal.map((q,i)=><article className="asisten-quiz-question-card" key={q.id}><div className="asisten-quiz-question-number">{String(i+1).padStart(2,"0")}</div><div className="asisten-quiz-question-body"><div className="asisten-quiz-question-meta"><span>{q.question_type==="essay"?"ESAI":"PILIHAN GANDA"}</span><span>{q.points} poin</span></div><h4>{q.question_text}</h4>{q.question_type==="multiple_choice"&&<div className="asisten-quiz-preview-options">{(q.options||[]).map((o,j)=><span className={o.is_correct?"correct":""} key={o.id||j}>{o.is_correct&&<CircleCheck size={13}/>} {o.option_text}</span>)}</div>}</div>{kuisDraft&&<div className="asisten-quiz-question-actions"><button className="asisten-quiz-icon-button" title="Duplikat" type="button" onClick={()=>duplikatSoal(q)}><Copy size={15}/></button><button className="asisten-quiz-icon-button" title="Edit" type="button" onClick={()=>mulaiEditSoal(q)}><Pencil size={15}/></button><button className="asisten-quiz-icon-button danger" title="Hapus" type="button" onClick={()=>hapusSoal(q)}><Trash2 size={15}/></button></div>}</article>)}
        {!daftarSoal.length&&<div className="asisten-quiz-empty"><ClipboardList size={30}/><h3>Belum ada pertanyaan</h3><p>{kuisDraft?"Tambahkan pertanyaan pertama untuk mulai menyusun kuis.":"Kuis ini belum memiliki pertanyaan."}</p>{kuisDraft&&<button className="asisten-quiz-primary" type="button" onClick={mulaiTambahSoal}><Plus size={15}/> Tambah Soal Pertama</button>}</div>}
      </div>}
    </section>;
  }

  function renderManajemenKuis() {
    if (!kelasKuis) return <section className="asisten-content-card"><div className="asisten-section-heading"><div><span className="asisten-eyebrow">QUIZ MANAGEMENT</span><h2>Pilih Kelas</h2><p>Pilih kelas untuk mengatur Pre-Test dan Post-Test.</p></div></div><div className="asisten-class-grid">{daftarKelas.map(k=><button key={k.id} className="asisten-class-card asisten-class-card-clickable" onClick={()=>muatKuis(k)} type="button"><div className="asisten-class-icon"><ClipboardList/></div><h3>{k.nama_mata_kuliah}</h3><p>Kelas {k.kode_kelas} · {k.kode_mata_kuliah}</p><div className="asisten-card-action">Kelola Kuis <ArrowUpRight size={15}/></div></button>)}</div></section>;
    if (tampilanKuis==="editor"&&kuisAktif) return renderEditorSoal();
    return <section className="asisten-content-card asisten-quiz-list-page">
      <button className="asisten-quiz-back" type="button" onClick={()=>{setKelasKuis(null);setKuisAktif(null);setFormKuis(null);setTampilanKuis("daftar");}}><ArrowLeft size={16}/> Kembali ke daftar kelas</button>
      <div className="asisten-quiz-list-heading"><div><span className="asisten-eyebrow">QUIZ MANAGEMENT</span><h2>{kelasKuis.nama_mata_kuliah} — Kelas {kelasKuis.kode_kelas}</h2><p>Kelola evaluasi praktikum melalui dua jenis kuis berikut.</p></div><div className="asisten-quiz-count"><ClipboardList size={17}/> 2 jenis evaluasi</div></div>
      {pesanKuis&&<div className="asisten-quiz-error">{pesanKuis}</div>}
      {formKuis&&<div className="asisten-quiz-compose asisten-quiz-create-form"><div className="asisten-quiz-compose-title"><div><span className="asisten-eyebrow">PENGATURAN KUIS</span><h3>{modeFormKuis === "edit" ? "Atur Jadwal & Detail Kuis" : `Buat ${formKuis.quiz_type==="pre_test"?"Pre-Test":"Post-Test"}`}</h3></div><button className="asisten-quiz-icon-button" onClick={()=>{setFormKuis(null);setModeFormKuis("create");}} type="button"><X size={17}/></button></div>
        <div className="asisten-quiz-compose-grid">
          <label className="asisten-quiz-field asisten-quiz-field-full">Judul kuis<input value={formKuis.title} onChange={e=>setFormKuis({...formKuis,title:e.target.value})}/></label>
          <label className="asisten-quiz-field asisten-quiz-field-full">Deskripsi<textarea value={formKuis.description} onChange={e=>setFormKuis({...formKuis,description:e.target.value})}/></label>
          <div className="asisten-quiz-field asisten-quiz-schedule-field" style={{display:"grid",gap:8,minWidth:0}}>
            <span className="asisten-quiz-field-label">Mulai</span>
            <div className="asisten-quiz-schedule-inputs" style={{display:"grid",gridTemplateColumns:"minmax(0,1.35fr) minmax(105px,0.8fr)",gap:8,minWidth:0}}>
              <label className="asisten-quiz-subfield" style={{display:"grid",gap:6,color:"var(--asisten-muted)",fontSize:10,fontWeight:600,minWidth:0}}><span>Tanggal</span><input type="date" value={(formKuis.start_at || "").split("T")[0]} onChange={e=>ubahBagianWaktuKuis("start_at","tanggal",e.target.value)}/></label>
              <label className="asisten-quiz-subfield" style={{display:"grid",gap:6,color:"var(--asisten-muted)",fontSize:10,fontWeight:600,minWidth:0}}><span>Jam (24 jam)</span><input type="time" step="60" value={(formKuis.start_at || "").split("T")[1] || ""} onChange={e=>ubahBagianWaktuKuis("start_at","jam",e.target.value)}/></label>
            </div>
          </div>
          <div className="asisten-quiz-field asisten-quiz-schedule-field" style={{display:"grid",gap:8,minWidth:0}}>
            <span className="asisten-quiz-field-label">Selesai</span>
            <div className="asisten-quiz-schedule-inputs" style={{display:"grid",gridTemplateColumns:"minmax(0,1.35fr) minmax(105px,0.8fr)",gap:8,minWidth:0}}>
              <label className="asisten-quiz-subfield" style={{display:"grid",gap:6,color:"var(--asisten-muted)",fontSize:10,fontWeight:600,minWidth:0}}><span>Tanggal</span><input type="date" value={(formKuis.end_at || "").split("T")[0]} onChange={e=>ubahBagianWaktuKuis("end_at","tanggal",e.target.value)}/></label>
              <label className="asisten-quiz-subfield" style={{display:"grid",gap:6,color:"var(--asisten-muted)",fontSize:10,fontWeight:600,minWidth:0}}><span>Jam (24 jam)</span><input type="time" step="60" value={(formKuis.end_at || "").split("T")[1] || ""} onChange={e=>ubahBagianWaktuKuis("end_at","jam",e.target.value)}/></label>
            </div>
          </div>
          <label className="asisten-quiz-field">Durasi (menit)<input type="number" min="1" value={formKuis.duration_minutes} onChange={e=>setFormKuis({...formKuis,duration_minutes:e.target.value})}/></label>
          <label className="asisten-quiz-field asisten-quiz-field-check"><input type="checkbox" checked={formKuis.shuffle_questions} onChange={e=>setFormKuis({...formKuis,shuffle_questions:e.target.checked})}/> Acak soal</label>
          <label className="asisten-quiz-field asisten-quiz-field-check"><input type="checkbox" checked={formKuis.shuffle_options} onChange={e=>setFormKuis({...formKuis,shuffle_options:e.target.checked})}/> Acak opsi</label>
        </div>
        <div className="asisten-quiz-compose-actions"><button className="asisten-quiz-primary" disabled={busyKuis||!formKuis.start_at||!formKuis.end_at} onClick={simpanKuis} type="button"><Save size={15}/>{busyKuis?"Menyimpan...":"Simpan Kuis"}</button><button className="asisten-quiz-secondary" onClick={()=>{setFormKuis(null);setModeFormKuis("create");}} type="button">Batal</button></div>
      </div>}
      <div className="asisten-quiz-cards-grid">{["pre_test","post_test"].map(jenis=>{const q=daftarKuis.find(x=>x.quiz_type===jenis);return <article className={`asisten-quiz-type-card ${q?"has-quiz":"empty"}`} key={jenis}>
        <div className="asisten-quiz-type-top"><span className={`asisten-quiz-type-icon ${jenis}`}>{jenis==="pre_test"?"01":"02"}</span><span className={`asisten-quiz-status ${q?.status||"not-created"}`}>{q?(q.status==="published"?"Dipublikasikan":q.status==="closed"?"Ditutup":"Draft"):"Belum dibuat"}</span></div>
        <span className="asisten-eyebrow">{jenis==="pre_test"?"PRE-TEST":"POST-TEST"}</span><h3>{q?.title||(jenis==="pre_test"?"Pre-Test Praktikum":"Post-Test Praktikum")}</h3><p>{q?.description||(q?"Evaluasi pemahaman praktikum mahasiswa.":"Buat evaluasi untuk mengukur pemahaman mahasiswa.")}</p>
        <div className="asisten-quiz-type-meta"><span><ClipboardList size={14}/>Kelola pertanyaan</span><span><Activity size={14}/>{q?`${q.duration_minutes} menit`:"Atur durasi"}</span></div>
        <div className="asisten-quiz-type-actions">{q?<><button className="asisten-quiz-primary" type="button" onClick={()=>kelolaSoal(q)}>Kelola Soal <ArrowUpRight size={15}/></button>{q.status==="draft"&&<button className="asisten-quiz-secondary" type="button" onClick={()=>mulaiEditPengaturanKuis(q)}>Pengaturan Kuis</button>}{q.status==="draft"?<button className="asisten-quiz-secondary" type="button" onClick={()=>setStatusKuis(q,"published")}>Publikasikan</button>:q.status==="published"?<><button className="asisten-quiz-secondary" type="button" onClick={()=>setStatusKuis(q,"closed")}>Tutup Kuis</button><button className="asisten-quiz-secondary" type="button" onClick={()=>setStatusKuis(q,"draft")}>Kembalikan ke Draft</button></>:<button className="asisten-quiz-primary" type="button" onClick={()=>setStatusKuis(q,"published")}>Buka Kembali</button>}</>:<button className="asisten-quiz-primary" type="button" onClick={()=>{setModeFormKuis("create");setFormKuis({quiz_type:jenis,title:jenis==="pre_test"?"Pre-Test Praktikum":"Post-Test Praktikum",description:"",start_at:"",end_at:"",duration_minutes:30,shuffle_questions:true,shuffle_options:true});}}><Plus size={15}/> Buat {jenis==="pre_test"?"Pre-Test":"Post-Test"}</button>}</div>
      </article>})}</div>
    </section>;
  }

  function renderOverview() {
    return (
      <>
        <section className="asisten-welcome">
          <div className="asisten-welcome-copy">
            <span className="asisten-eyebrow">
              LABORATORY WORKSPACE
            </span>

            <h1>
              Halo, {namaAsisten}!
            </h1>

            <p>
              Selamat datang di ruang kerja Asisten
              Laboratorium Komputer LabAssess.
            </p>
          </div>

          <div className="asisten-welcome-icon" aria-hidden="true">
            <Monitor size={42} strokeWidth={1.8} />
          </div>
        </section>

        <section className="asisten-stat-grid">
          <article className="asisten-stat-card">
            <div className="asisten-stat-icon wine">
              <BookOpen size={21} />
            </div>

            <div>
              <span>Total Kelas</span>
              <strong>
                {dashboard?.total_kelas ?? 0}
              </strong>
              <small>Kelas yang ditugaskan</small>
            </div>
          </article>

          <article className="asisten-stat-card">
            <div className="asisten-stat-icon green">
              <Activity size={21} />
            </div>

            <div>
              <span>Kelas Aktif</span>
              <strong>
                {dashboard?.total_kelas_aktif ?? 0}
              </strong>
              <small>Kelas yang sedang aktif</small>
            </div>
          </article>

          <article className="asisten-stat-card">
            <div className="asisten-stat-icon rose">
              <Users size={21} />
            </div>

            <div>
              <span>Total Mahasiswa</span>
              <strong>
                {dashboard?.total_mahasiswa ?? 0}
              </strong>
              <small>Mahasiswa pada kelasmu</small>
            </div>
          </article>
        </section>

        <section className="asisten-content-card">
          <div className="asisten-section-heading">
            <div>
              <span className="asisten-eyebrow">
                ACADEMIC ASSIGNMENT
              </span>

              <h2>Kelas yang Ditugaskan</h2>

              <p>
                Pilih kelas untuk melihat detail dan
                daftar mahasiswa.
              </p>
            </div>

            <button
              className="asisten-text-button"
              onClick={() => pilihMenu("kelas")}
              type="button"
            >
              Lihat Semua
              <ArrowUpRight size={16} />
            </button>
          </div>

          {renderDaftarKelas(3)}
        </section>
      </>
    );
  }

  function renderDaftarKelas(batas = daftarKelas.length) {
    if (daftarKelas.length === 0) {
      return (
        <div className="asisten-empty-state">
          <div className="asisten-empty-icon">
            <BookOpen size={28} />
          </div>

          <h3>Belum Ada Kelas</h3>

          <p>
            Saat ini belum ada kelas yang ditugaskan
            oleh Administrator ke akunmu.
          </p>
        </div>
      );
    }

    return (
      <div className="asisten-class-grid">
        {daftarKelas.slice(0, batas).map((kelas) => (
          <button
            className="asisten-class-card asisten-class-card-clickable"
            key={kelas.id}
            type="button"
            onClick={() => bukaDetailKelas(kelas)}
            aria-label={`Lihat detail kelas ${kelas.kode_kelas}`}
          >
            <div className="asisten-class-top">
              <div className="asisten-class-icon">
                <BookOpen size={21} />
              </div>

              <span
                className={`asisten-status ${
                  kelas.is_active ? "active" : "inactive"
                }`}
              >
                {kelas.is_active ? (
                  <CircleCheck size={13} />
                ) : (
                  <CircleAlert size={13} />
                )}

                {kelas.is_active ? "Aktif" : "Tidak Aktif"}
              </span>
            </div>

            <div className="asisten-class-info">
              <span className="asisten-class-code">
                {kelas.kode_mata_kuliah}
              </span>

              <h3>{kelas.nama_mata_kuliah}</h3>

              <p>Kelas {kelas.kode_kelas}</p>
            </div>

            <div className="asisten-class-divider" />

            <div className="asisten-class-meta">
              <span>
                <Users size={15} />
                {kelas.jumlah_mahasiswa} Mahasiswa
              </span>

              <span>
                <CalendarDays size={15} />
                {kelas.semester}
              </span>
            </div>

            <div className="asisten-class-year">
              Tahun Akademik {kelas.tahun_akademik}
            </div>

            <div className="asisten-card-action">
              Lihat Detail Kelas
              <ArrowUpRight size={15} />
            </div>
          </button>
        ))}
      </div>
    );
  }

  function renderHalaman() {
    if (kelasTerpilih) {
      if (loadingDetail) {
        return (
          <div className="asisten-loading">
            <RefreshCw
              size={25}
              className="spinning"
            />
            <span>Memuat detail kelas...</span>
          </div>
        );
      }

      if (pesanDetail) {
        return (
          <div className="asisten-content-card">
            <button
              type="button"
              className="detail-back-button"
              onClick={kembaliKeDaftarKelas}
            >
              <ArrowUpRight
                size={16}
                style={{ transform: "rotate(225deg)" }}
              />
              Kembali ke Kelas Saya
            </button>

            <div className="asisten-error-message">
              <CircleAlert size={18} />
              <span>{pesanDetail}</span>
              <button
                type="button"
                onClick={() => bukaDetailKelas(kelasTerpilih)}
              >
                Coba Lagi
              </button>
            </div>
          </div>
        );
      }

      return (
        <DetailKelasAsisten
          detail={detailKelas}
          token={token}
          onKembali={kembaliKeDaftarKelas}
        />
      );
    }

    if (menuAktif === "kuis") return renderManajemenKuis();

    // Tampilkan halaman Rekap Nilai tanpa mengubah fitur dashboard lainnya.
    if (menuAktif === "rekap-nilai") {
      return <RekapNilaiAsisten token={token} />;
    }

    if (menuAktif === "kelas") {
      return (
        <section className="asisten-content-card">
          <div className="asisten-section-heading">
            <div>
              <span className="asisten-eyebrow">
                MY ASSIGNMENTS
              </span>

              <h2>Kelas Saya</h2>

              <p>
                Semua kelas yang ditugaskan
                Administrator kepadamu.
              </p>
            </div>

            <span className="asisten-total-label">
              {daftarKelas.length} Kelas
            </span>
          </div>

          {renderDaftarKelas()}
        </section>
      );
    }

    return renderOverview();
  }

  const judulHalaman = kelasTerpilih
    ? "Detail Kelas"
    : menuAktif === "rekap-nilai"
      ? "Rekap Nilai"
      : menuAktif === "kuis"
        ? "Pre-Test & Post-Test"
        : menuAktif === "kelas"
          ? "Kelas Saya"
          : "Overview";

  return (
    <main className="asisten-dashboard">
      <div className="asisten-decoration one" />
      <div className="asisten-decoration two" />

      <header className="asisten-topbar">
        <a className="asisten-brand" href="#overview">
          <span className="asisten-brand-icon">
            <Monitor size={23} />
          </span>

          <span className="asisten-brand-name">
            LabAssess
            <small>LABORATORY SYSTEM</small>
          </span>
        </a>

        <div className="asisten-topbar-right">
          <div className="asisten-user-profile">
            <div className="asisten-avatar">
              {namaAsisten.charAt(0).toUpperCase()}
            </div>

            <div className="asisten-user-detail">
              <strong>{namaAsisten}</strong>
              <span>Asisten Laboratorium</span>
            </div>
          </div>

          <button
            className="asisten-logout-button"
            onClick={onLogout}
            type="button"
          >
            <LogOut size={17} />
            <span>Keluar</span>
          </button>

          <button
            className="asisten-mobile-menu-button"
            onClick={() =>
              setMenuMobileTerbuka((nilai) => !nilai)
            }
            type="button"
            aria-label="Buka navigasi"
          >
            {menuMobileTerbuka ? (
              <X size={21} />
            ) : (
              <Menu size={21} />
            )}
          </button>
        </div>
      </header>

      <div className="asisten-navigation-wrapper">
        <nav
          className={`asisten-navigation ${
            menuMobileTerbuka ? "mobile-open" : ""
          }`}
        >
          {MENU_ASISTEN.map((item) => {
            const Icon = item.icon;
            const aktif =
              menuAktif === item.id && !kelasTerpilih;

            return (
              <button
                key={item.id}
                className={`asisten-nav-item ${
                  aktif ? "active" : ""
                }`}
                onClick={() => pilihMenu(item.id)}
                type="button"
              >
                <Icon size={17} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      <div className="asisten-main-content">
        <div className="asisten-page-toolbar">
          <div>
            <span className="asisten-page-label">
              ASISTEN WORKSPACE
            </span>

            <h2>{judulHalaman}</h2>
          </div>

          <button
            className="asisten-refresh-button"
            onClick={muatDashboard}
            disabled={loading}
            type="button"
          >
            <RefreshCw
              size={16}
              className={loading ? "spinning" : ""}
            />
            <span>Perbarui Data</span>
          </button>
        </div>

        {pesan && (
          <div className="asisten-error-message">
            <CircleAlert size={18} />
            <span>{pesan}</span>

            <button
              onClick={muatDashboard}
              type="button"
            >
              Coba Lagi
            </button>
          </div>
        )}

        {loading ? (
          <div className="asisten-loading">
            <RefreshCw
              size={25}
              className="spinning"
            />
            <span>Memuat dashboard...</span>
          </div>
        ) : (
          renderHalaman()
        )}
      </div>

      <footer className="asisten-footer">
        <span>© 2026 LabAssess · STITEK Bontang</span>
        <span>Assistant Workspace</span>
      </footer>
    </main>
  );
}
