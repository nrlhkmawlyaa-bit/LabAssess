

import { useEffect, useState } from "react";

import {
  Download,
  RefreshCw,
  Filter,
  FileSpreadsheet,
  Users,
  ClipboardList,
  Award,
  AlertCircle,
  PencilLine,
  CheckCircle2,
  GraduationCap,
  ClipboardCheck,
  X,
} from "lucide-react";



import {
  ambilProgramStudiRekapNilai,
  ambilRekapNilaiPerKuis,
  eksporRekapNilai,
  ambilDaftarPengerjaanKuisAsisten,
  ambilDetailPengerjaanKuisAsisten,
} from "../../services/academicService";



const formatNilai = (nilai) => {

  if (nilai === null || nilai === undefined) return "—";

  return Number(nilai).toLocaleString("id-ID", {

    maximumFractionDigits: 2,

  });

};

const API_BASE_URL = "/api/v1";

async function kirimAksiPenilaian(path, token, body = null) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(
      typeof data.detail === "string"
        ? data.detail
        : "Permintaan penilaian gagal diproses."
    );
  }
  return data;
}



// Nama mata kuliah dikirim oleh endpoint rekap sebagai "mata_kuliah".
// Alias tambahan menjaga kompatibilitas jika bentuk respons API bervariasi.
const ambilNamaMataKuliah = (item) =>
  item?.mata_kuliah ||
  item?.nama_mata_kuliah ||
  item?.course_name ||
  item?.nama_matakuliah ||
  "";


const normalisasiJenisKuis = (item) => {
  const jenis = String(item?.jenis_kuis || item?.quiz_type || "").toLowerCase();
  if (jenis.includes("pre")) return "pre";
  if (jenis.includes("post")) return "post";
  return "";
};

const gayaBadgeKuis = (jenis) => ({
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: 7,
  padding: "7px 13px",
  borderRadius: 999,
  background: jenis === "pre" ? "#EEE5F3" : "#F7EBDD",
  color: jenis === "pre" ? "#80618F" : "#A47748",
  fontSize: 12,
  fontWeight: 700,
  whiteSpace: "nowrap",
});

export default function RekapNilaiAsisten({ token }) {

  const [programStudi, setProgramStudi] = useState([]);

  const [programTerpilih, setProgramTerpilih] = useState("");

  const [mataKuliahTerpilih, setMataKuliahTerpilih] = useState("");
  const [jenisTesTerpilih, setJenisTesTerpilih] = useState("semua");



  const [rekapPerKuis, setRekapPerKuis] = useState(null);





  const [loading, setLoading] = useState(true);

  const [loadingExport, setLoadingExport] = useState(false);

  const [pesan, setPesan] = useState("");

  const [detailAktif, setDetailAktif] = useState(null);
  const [memuatDetail, setMemuatDetail] = useState(false);
  const [menyimpanPenilaian, setMenyimpanPenilaian] = useState(false);
  const [nilaiEsai, setNilaiEsai] = useState({});
  const [feedbackEsai, setFeedbackEsai] = useState({});
  const [pesanAksi, setPesanAksi] = useState("");



  async function muatProgramStudi() {

    try {

      const hasil = await ambilProgramStudiRekapNilai(token);

      setProgramStudi(Array.isArray(hasil) ? hasil : []);

    } catch (error) {

      setPesan(error.message);

    }

  }



  async function muatRekap() {

    setLoading(true);

    setPesan("");



    try {

      const perKuis = await ambilRekapNilaiPerKuis(token, programTerpilih);
      setRekapPerKuis(perKuis);

    } catch (error) {

      setPesan(error.message);

    } finally {

      setLoading(false);

    }

  }



  useEffect(() => {

    if (!token) return;

    muatProgramStudi();

  }, [token]);



  useEffect(() => {

    if (!token) return;

    muatRekap();

  }, [token, programTerpilih]);



  async function handleExport(jenis) {

    setLoadingExport(true);

    setPesan("");



    try {

      await eksporRekapNilai(

        token,

        jenis,

        programTerpilih

      );

    } catch (error) {

      setPesan(error.message);

    } finally {

      setLoadingExport(false);

    }

  }



  async function bukaPemeriksaan(item) {
    const kuisId = item.kuis_id ?? item.quiz_id;
    const mahasiswaId = item.mahasiswa_id ?? item.student_id;

    if (!kuisId || !mahasiswaId) {
      setPesanAksi("ID kuis atau mahasiswa tidak ditemukan pada data rekap.");
      return;
    }

    setMemuatDetail(true);
    setPesanAksi("");
    try {
      // Rekap per kuis berisi identitas mahasiswa dan kuis.
      // ID pengerjaan diambil dari endpoint daftar pengerjaan resmi.
      const daftar = await ambilDaftarPengerjaanKuisAsisten(token, kuisId);
      const daftarData = Array.isArray(daftar) ? daftar : (daftar?.data || []);
      const pengerjaan = daftarData.find(
        (entry) => Number(entry.student_id) === Number(mahasiswaId)
      );

      if (!pengerjaan?.attempt_id) {
        throw new Error("Riwayat pengerjaan mahasiswa tidak ditemukan.");
      }

      const detail = await ambilDetailPengerjaanKuisAsisten(
        token,
        kuisId,
        pengerjaan.attempt_id
      );

      setDetailAktif({ ...detail, quiz_id: kuisId });
      setNilaiEsai(
        Object.fromEntries(
          (detail.answers || [])
            .filter((answer) => answer.question_type === "essay")
            .map((answer) => [answer.answer_id, answer.awarded_points ?? ""])
        )
      );
      setFeedbackEsai(
        Object.fromEntries(
          (detail.answers || [])
            .filter((answer) => answer.question_type === "essay")
            .map((answer) => [answer.answer_id, answer.feedback ?? ""])
        )
      );
    } catch (error) {
      setPesanAksi(error.message);
    } finally {
      setMemuatDetail(false);
    }
  }

  async function simpanNilaiEsai(answer) {
    const nilai = nilaiEsai[answer.answer_id];
    if (nilai === "" || nilai === null || nilai === undefined) {
      setPesanAksi("Isi nilai untuk jawaban esai terlebih dahulu.");
      return;
    }
    if (Number(nilai) < 0 || Number(nilai) > Number(answer.total_points)) {
      setPesanAksi(`Nilai harus antara 0 sampai ${answer.total_points}.`);
      return;
    }

    setMenyimpanPenilaian(true);
    setPesanAksi("");
    try {
      await kirimAksiPenilaian(
        `/asisten/kuis/${detailAktif.quiz_id}/pengerjaan/${detailAktif.attempt_id}/soal/${answer.question_id}/nilai`,
        token,
        {
          awarded_points: Number(nilai),
          feedback: feedbackEsai[answer.answer_id] || null,
        }
      );
      const terbaru = await ambilDetailPengerjaanKuisAsisten(
        token,
        detailAktif.quiz_id,
        detailAktif.attempt_id
      );
      setDetailAktif({ ...terbaru, quiz_id: detailAktif.quiz_id });
      setPesanAksi("Penilaian esai berhasil disimpan.");
      await muatRekap();
    } catch (error) {
      setPesanAksi(error.message);
    } finally {
      setMenyimpanPenilaian(false);
    }
  }

  async function publikasikanNilaiAktif() {
    if (!detailAktif) return;
    const belumDinilai = (detailAktif.answers || []).some(
      (answer) =>
        answer.question_type === "essay" &&
        answer.essay_answer?.trim() &&
        (answer.awarded_points === null || answer.awarded_points === undefined)
    );
    if (belumDinilai) {
      setPesanAksi("Masih ada jawaban esai yang belum dinilai.");
      return;
    }
    if (!window.confirm("Publikasikan nilai mahasiswa ini? Nilai akan dapat dilihat oleh mahasiswa.")) {
      return;
    }

    setMenyimpanPenilaian(true);
    setPesanAksi("");
    try {
      await kirimAksiPenilaian(
        `/asisten/kuis/${detailAktif.quiz_id}/pengerjaan/${detailAktif.attempt_id}/publikasikan-nilai`,
        token
      );
      setPesanAksi("Nilai berhasil dipublikasikan.");
      await muatRekap();
      setDetailAktif(null);
    } catch (error) {
      setPesanAksi(error.message);
    } finally {
      setMenyimpanPenilaian(false);
    }
  }

  const dataPerKuisAsli = rekapPerKuis?.data || [];

  const cocokMataKuliah = (item) =>
    !mataKuliahTerpilih ||
    ambilNamaMataKuliah(item) === mataKuliahTerpilih;

  const dataPerKuis = dataPerKuisAsli.filter((item) => {
    if (!cocokMataKuliah(item)) return false;
    const jenis = normalisasiJenisKuis(item);
    if (jenisTesTerpilih === "pre") return jenis === "pre";
    if (jenisTesTerpilih === "post") return jenis === "post";
    return true;
  });

  const dataStatistik = dataPerKuis;
  const totalMahasiswa = new Set(
    dataStatistik
      .map((item) => item.mahasiswa_id ?? item.student_id ?? item.nim)
      .filter((id) => id !== null && id !== undefined && id !== "")
  ).size;

  const totalData = dataStatistik.length;

  const nilaiTerpublikasi = dataStatistik.filter((item) =>
    (item.status_penilaian || item.grading_status) === "published"
  ).length;



  return (

    <section className="asisten-content-card rekap-nilai-page">

      <div className="rekap-heading">

        <div>

          <span className="asisten-eyebrow">

            ACADEMIC PERFORMANCE

          </span>

          <h2>Rekap Nilai Mahasiswa</h2>

          <p>

            Pantau hasil evaluasi Pre-Test dan Post-Test

            mahasiswa pada kelas yang kamu ampu.

          </p>

        </div>

      </div>



      <div className="rekap-filter" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", alignItems: "end", gap: 14 }}>
        <div className="rekap-filter-label" style={{ gridColumn: "1 / -1", marginBottom: 0 }}>
          <Filter size={17} />
          <span>Filter Data Rekap</span>
        </div>

        <label style={{ display: "grid", gap: 8, minWidth: 0 }}>
          <span style={{ fontSize: 12, fontWeight: 700, color: "#6f5362" }}>Program Studi</span>
          <select
            value={programTerpilih}
            onChange={(event) => {
              setProgramTerpilih(event.target.value);
              setMataKuliahTerpilih("");
            }}
            aria-label="Filter Program Studi"
            style={{ width: "100%", minWidth: 0 }}
          >
            <option value="">Semua Program Studi</option>
            {programStudi.map((prodi) => (
              <option key={prodi.id} value={prodi.id}>
                {prodi.kode} — {prodi.nama}
              </option>
            ))}
          </select>
        </label>

        <label style={{ display: "grid", gap: 8, minWidth: 0 }}>
          <span style={{ fontSize: 12, fontWeight: 700, color: "#6f5362" }}>Mata Kuliah</span>
          <select
            value={mataKuliahTerpilih}
            onChange={(event) => setMataKuliahTerpilih(event.target.value)}
            aria-label="Filter Mata Kuliah"
            disabled={loading}
            style={{ width: "100%", minWidth: 0 }}
          >
            <option value="">Semua Mata Kuliah</option>
            {Array.from(
              new Set(
                (rekapPerKuis?.data || [])
                  .map(ambilNamaMataKuliah)
                  .filter(Boolean)
              )
            )
              .sort((a, b) => String(a).localeCompare(String(b), "id"))
              .map((nama) => (
                <option key={nama} value={nama}>
                  {nama}
                </option>
              ))}
          </select>
        </label>

        <label style={{ display: "grid", gap: 8, minWidth: 0 }}>
          <span style={{ fontSize: 12, fontWeight: 700, color: "#6f5362" }}>Jenis Tes</span>
          <select
            value={jenisTesTerpilih}
            onChange={(event) => setJenisTesTerpilih(event.target.value)}
            aria-label="Filter Jenis Tes"
            disabled={loading}
            style={{ width: "100%", minWidth: 0 }}
          >
            <option value="semua">Semua Jenis Tes</option>
            <option value="pre">Pre-Test</option>
            <option value="post">Post-Test</option>
          </select>
        </label>
      </div>

      <div className="rekap-stat-grid">

        <article className="rekap-stat-card">

          <div className="rekap-stat-icon">

            <Users size={21} />

          </div>

          <div>

            <span>Total Mahasiswa</span>

            <strong>{totalMahasiswa}</strong>

          </div>

        </article>



        <article className="rekap-stat-card">

          <div className="rekap-stat-icon">

            <ClipboardList size={21} />

          </div>

          <div>

            <span>Total Data Evaluasi</span>

            <strong>{totalData}</strong>

          </div>

        </article>



        <article className="rekap-stat-card">

          <div className="rekap-stat-icon">

            <Award size={21} />

          </div>

          <div>

            <span>Nilai Dipublikasikan</span>

            <strong>{nilaiTerpublikasi}</strong>

          </div>

        </article>

      </div>



      {pesan && (

        <div className="rekap-error">

          <AlertCircle size={17} />

          <span>{pesan}</span>

        </div>

      )}



      <div className="rekap-table-heading">

        <div>

          <h3>Nilai Per Kuis</h3>

          <p>Daftar hasil evaluasi mahasiswa untuk setiap kuis.</p>

        </div>



        <button

          type="button"

          className="rekap-export-button"

          onClick={() => handleExport("per-kuis")}

          disabled={loadingExport || loading}

        >

          <FileSpreadsheet size={16} />

          {loadingExport ? "Menyiapkan..." : "Ekspor Excel"}

          <Download size={15} />

        </button>

      </div>



      {loading ? (

        <div className="rekap-empty">

          <RefreshCw className="spinning" size={25} />

          <p>Memuat rekap nilai...</p>

        </div>

      ) : (

        dataPerKuis.length > 0 ? (

          <div className="rekap-table-wrapper">
            <table className="rekap-table" style={{ width: "100%", minWidth: 1050, tableLayout: "auto" }}>
              <thead>
                <tr>
                  <th style={{ width: 52 }}>No.</th>
                  <th>NIM</th>
                  <th>Nama Mahasiswa</th>
                  <th>Program Studi</th>
                  <th>Mata Kuliah</th>
                  <th>Kelas</th>
                  <th>Jenis Tes</th>
                  <th style={{ textAlign: "center" }}>Nilai</th>
                </tr>
              </thead>
              <tbody>
                {dataPerKuis.map((item, index) => {
                  const jenis = normalisasiJenisKuis(item);
                  const statusPengerjaan = item.status_pengerjaan || item.completion_status;
                  const statusNilai = item.status_penilaian || item.grading_status;
                  const sudahDikumpulkan = statusPengerjaan === "submitted";
                  const sudahDipublikasi = statusNilai === "published";
                  const nilai = item.nilai ?? item.nilai_akhir;

                  return (
                    <tr key={`${item.kuis_id ?? item.quiz_id ?? "kuis"}-${item.mahasiswa_id ?? item.student_id ?? item.nim ?? index}-${index}`}>
                      <td>{index + 1}</td>
                      <td>{item.nim || "—"}</td>
                      <td style={{ fontWeight: 600, color: "#38323A" }}>{item.nama_mahasiswa || "—"}</td>
                      <td>{item.program_studi || "—"}</td>
                      <td>{ambilNamaMataKuliah(item) || "—"}</td>
                      <td>{item.kode_kelas || item.nama_kelas || "—"}</td>
                      <td>
                        {jenis === "pre" ? (
                          <span style={gayaBadgeKuis("pre")}>
                            <GraduationCap size={14} />
                            Pre-Test
                          </span>
                        ) : jenis === "post" ? (
                          <span style={gayaBadgeKuis("post")}>
                            <ClipboardCheck size={14} />
                            Post-Test
                          </span>
                        ) : (
                          <span style={{ color: "#9A9298" }}>—</span>
                        )}
                      </td>
                      <td style={{ textAlign: "center", verticalAlign: "middle" }}>
                        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 5 }}>
                          <strong style={{ color: "#482A38", fontSize: 14 }}>
                            {formatNilai(nilai)}
                          </strong>
                          {sudahDikumpulkan && !sudahDipublikasi ? (
                            <button
                              type="button"
                              className="rekap-export-button"
                              style={{ padding: "5px 9px", fontSize: 11 }}
                              onClick={() => bukaPemeriksaan(item)}
                              disabled={memuatDetail}
                            >
                              <PencilLine size={13} />
                              {memuatDetail ? "Memuat..." : "Periksa / Nilai"}
                            </button>
                          ) : sudahDipublikasi ? (
                            <span style={{ color: "#43866a", fontSize: 10, fontWeight: 600 }}>
                              <CheckCircle2 size={12} style={{ verticalAlign: "middle", marginRight: 3 }} />
                              Dipublikasikan
                            </span>
                          ) : (
                            <span style={{ color: "#9A9298", fontSize: 10 }}>
                              Belum mengerjakan
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

        ) : (

          <div className="rekap-empty">

            <ClipboardList size={30} />

            <h3>Belum Ada Data Evaluasi</h3>

            <p>Data nilai akan muncul setelah mahasiswa mengerjakan kuis.</p>

          </div>

        )

      )}

      {pesanAksi && (
        <div className="rekap-error" style={{ marginTop: 16 }}>
          <AlertCircle size={17} />
          <span>{pesanAksi}</span>
        </div>
      )}

      {detailAktif && (
        <div
          role="presentation"
          onClick={(event) => {
            if (event.target === event.currentTarget) setDetailAktif(null);
          }}
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 1000,
            background: "rgba(45, 27, 38, 0.48)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 20,
          }}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-label="Pemeriksaan jawaban mahasiswa"
            style={{
              width: "min(900px, 100%)",
              maxHeight: "90vh",
              overflowY: "auto",
              background: "#fff",
              borderRadius: 20,
              padding: 24,
              boxShadow: "0 20px 60px rgba(40, 20, 32, .25)",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", gap: 16, alignItems: "flex-start" }}>
              <div>
                <span className="asisten-eyebrow">PEMERIKSAAN HASIL KUIS</span>
                <h2 style={{ margin: "8px 0 4px" }}>{detailAktif.nama_mahasiswa}</h2>
                <p style={{ margin: 0, color: "#887b84" }}>
                  {detailAktif.nim} · {detailAktif.judul_kuis}
                </p>
              </div>
              <button type="button" onClick={() => setDetailAktif(null)} aria-label="Tutup pemeriksaan">
                <X size={20} />
              </button>
            </div>

            <div style={{ display: "grid", gap: 14, marginTop: 22 }}>
              {(detailAktif.answers || []).map((answer) => (
                <article
                  key={answer.answer_id}
                  style={{
                    border: "1px solid #eadfe5",
                    borderRadius: 14,
                    padding: 16,
                    background: "#fffdfd",
                  }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
                    <strong>Soal {answer.question_order}</strong>
                    <span style={{ color: "#887b84", fontSize: 13 }}>
                      {answer.question_type === "essay" ? "Esai" : "Pilihan Ganda"} · Bobot {formatNilai(answer.total_points)}
                    </span>
                  </div>
                  <p style={{ margin: "10px 0" }}>{answer.question_text}</p>
                  {answer.question_type === "essay" ? (
                    <>
                      <div style={{ padding: 12, background: "#f8f4f6", borderRadius: 10, whiteSpace: "pre-wrap" }}>
                        {answer.essay_answer || "Mahasiswa tidak mengisi jawaban."}
                      </div>
                      {answer.essay_answer?.trim() && (
                        <div style={{ display: "grid", gridTemplateColumns: "minmax(120px, 180px) 1fr", gap: 12, marginTop: 12 }}>
                          <label style={{ display: "grid", gap: 6, fontSize: 13 }}>
                            Nilai (maks. {formatNilai(answer.total_points)})
                            <input
                              type="number"
                              min="0"
                              max={Number(answer.total_points)}
                              step="0.01"
                              value={nilaiEsai[answer.answer_id] ?? ""}
                              disabled={detailAktif.status_penilaian === "published"}
                              onChange={(event) =>
                                setNilaiEsai((prev) => ({ ...prev, [answer.answer_id]: event.target.value }))
                              }
                              style={{ width: "100%", padding: 10, border: "1px solid #ddcbd5", borderRadius: 9 }}
                            />
                          </label>
                          <label style={{ display: "grid", gap: 6, fontSize: 13 }}>
                            Feedback (opsional)
                            <textarea
                              rows="2"
                              value={feedbackEsai[answer.answer_id] ?? ""}
                              disabled={detailAktif.status_penilaian === "published"}
                              onChange={(event) =>
                                setFeedbackEsai((prev) => ({ ...prev, [answer.answer_id]: event.target.value }))
                              }
                              style={{ width: "100%", padding: 10, border: "1px solid #ddcbd5", borderRadius: 9, resize: "vertical" }}
                            />
                          </label>
                          {detailAktif.status_penilaian !== "published" && (
                            <div style={{ gridColumn: "1 / -1" }}>
                              <button
                                type="button"
                                className="rekap-export-button"
                                onClick={() => simpanNilaiEsai(answer)}
                                disabled={menyimpanPenilaian}
                              >
                                Simpan Penilaian Esai
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </>
                  ) : (
                    <div style={{ padding: 12, background: "#f8f4f6", borderRadius: 10 }}>
                      <div>Jawaban mahasiswa: <strong>{answer.selected_option_text || "Belum dijawab"}</strong></div>
                      <div style={{ marginTop: 6, color: "#43866a" }}>
                        Jawaban benar: {answer.correct_options?.map((option) => option.option_text).join(", ") || "—"}
                      </div>
                      <div style={{ marginTop: 6 }}>Poin: {formatNilai(answer.awarded_points)} / {formatNilai(answer.total_points)}</div>
                    </div>
                  )}
                </article>
              ))}
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap", marginTop: 20, paddingTop: 16, borderTop: "1px solid #eadfe5" }}>
              <div>
                <span style={{ color: "#887b84", fontSize: 13 }}>Nilai saat ini</span>
                <div style={{ fontSize: 22, fontWeight: 700, color: "#482a38" }}>
                  {formatNilai(detailAktif.nilai_akhir)}
                </div>
                <small style={{ color: "#887b84" }}>Status: {detailAktif.status_penilaian || "belum_dinilai"}</small>
              </div>
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                <button type="button" onClick={() => setDetailAktif(null)}>Tutup</button>
                {detailAktif.status_penilaian !== "published" && (
                  <button
                    type="button"
                    className="rekap-export-button"
                    onClick={publikasikanNilaiAktif}
                    disabled={menyimpanPenilaian || detailAktif.status_penilaian === "pending_review"}
                    title={detailAktif.status_penilaian === "pending_review" ? "Nilai esai harus diselesaikan terlebih dahulu" : "Publikasikan nilai"}
                  >
                    <CheckCircle2 size={16} />
                    {menyimpanPenilaian ? "Memproses..." : "Publikasikan Nilai"}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

    </section>

  );

}
