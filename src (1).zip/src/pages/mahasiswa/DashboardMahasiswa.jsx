import { useEffect, useMemo, useState } from "react";

import {
  Monitor,
  LayoutDashboard,
  BookOpen,
  GraduationCap,
  Users,
  CalendarDays,

  LogOut,

  Menu,

  X,

  RefreshCw,

  ArrowUpRight,

  ArrowLeft,

  CircleCheck,

  CircleAlert,

  BookMarked,

  FileText,

  Download,

  Clock3,

  Layers3,

  Timer,

  Send,

  Check,

  AlertTriangle,

  History,
} from "lucide-react";

import {

  ambilDashboardMahasiswa,

  ambilDaftarModulMahasiswa,

  ambilDetailModulMahasiswa,

  unduhFileModulMahasiswa,

  ambilDaftarKuisMahasiswa,

  mulaiKuisMahasiswa,

  simpanJawabanKuisMahasiswa,

  kumpulkanKuisMahasiswa,

  ambilRiwayatNilaiMahasiswa,

} from "../../services/academicService";

import "../../styles/mahasiswa.css";

const MENU_MAHASISWA = [

  {

    id: "overview",

    label: "Overview",

    icon: LayoutDashboard,

  },

  {

    id: "kelas",

    label: "Kelas Saya",

    icon: BookOpen,

  },

  {

    id: "riwayat-nilai",

    label: "Riwayat Nilai",

    icon: History,

  },

];

function formatUkuranFile(bytes) {

  if (!bytes) return "0 KB";

  if (bytes < 1024 * 1024) {

    return `${(bytes / 1024).toFixed(1)} KB`;

  }

  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;

}

function formatTanggal(tanggal) {

  if (!tanggal) return "-";

  return new Date(tanggal).toLocaleDateString("id-ID", {

    day: "numeric",

    month: "long",

    year: "numeric",

  });

}


// Backend mengirim waktu percobaan dalam UTC. Timestamp tanpa penanda
// zona waktu diperlakukan sebagai UTC agar tidak bergeser mengikuti zona browser.
function parseWaktuServer(nilai) {
  if (!nilai) return NaN;

  if (typeof nilai === "number") {
    return nilai < 1e12 ? nilai * 1000 : nilai;
  }

  const teks = String(nilai).trim();
  const memilikiZonaWaktu = /(?:Z|[+-]\\d{2}:?\\d{2})$/i.test(teks);
  const iso = teks.includes("T") ? teks : teks.replace(" ", "T");

  return new Date(memilikiZonaWaktu ? iso : `${iso}Z`).getTime();
}

export default function DashboardMahasiswa({

  pengguna,

  token,

  onLogout,

}) {

  const [menuAktif, setMenuAktif] = useState("overview");

  const [menuMobileTerbuka, setMenuMobileTerbuka] =

    useState(false);

  const [dashboard, setDashboard] = useState(null);

  const [loading, setLoading] = useState(true);

  const [pesan, setPesan] = useState("");

  const [riwayatNilai, setRiwayatNilai] = useState([]);

  const [loadingRiwayatNilai, setLoadingRiwayatNilai] = useState(false);

  const [pesanRiwayatNilai, setPesanRiwayatNilai] = useState("");

  const [kelasTerpilih, setKelasTerpilih] = useState(null);

  const [daftarModul, setDaftarModul] = useState([]);

  const [loadingModul, setLoadingModul] = useState(false);

  const [pesanModul, setPesanModul] = useState("");

  const [daftarKuis, setDaftarKuis] = useState([]);

  const [loadingKuis, setLoadingKuis] = useState(false);

  const [pesanKuis, setPesanKuis] = useState("");

  const [kuisTerpilih, setKuisTerpilih] = useState(null);

  const [pengerjaanKuis, setPengerjaanKuis] = useState(null);

  const [jawabanKuis, setJawabanKuis] = useState({});

  const [loadingMulaiKuis, setLoadingMulaiKuis] = useState(false);

  const [menyimpanJawaban, setMenyimpanJawaban] = useState(false);

  const [mengumpulkanKuis, setMengumpulkanKuis] = useState(false);

  const [pesanPengerjaan, setPesanPengerjaan] = useState("");

  const [sisaWaktu, setSisaWaktu] = useState(0);

  const [modulTerpilih, setModulTerpilih] = useState(null);

  const [loadingDetail, setLoadingDetail] = useState(false);

  const [pesanDetail, setPesanDetail] = useState("");

  const [fileSedangDiunduh, setFileSedangDiunduh] =

    useState(null);

  const [pesanDownload, setPesanDownload] = useState("");
  // ==========================================*
  // MEMUAT DASHBOARD*
  // ==========================================*

  async function muatDashboard() {

    setLoading(true);

    setPesan("");

    try {

      const hasil = await ambilDashboardMahasiswa(token);

      setDashboard(hasil);

    } catch (error) {

      setPesan(error.message);

    } finally {

      setLoading(false);

    }

  }

  useEffect(() => {

    muatDashboard();

  }, [token]);
  // ==========================================*
  // MEMUAT RIWAYAT NILAI MAHASISWA*
  // ==========================================*

  async function muatRiwayatNilai() {

    setLoadingRiwayatNilai(true);

    setPesanRiwayatNilai("");

    try {

      const hasil = await ambilRiwayatNilaiMahasiswa(token);

      setRiwayatNilai(

        Array.isArray(hasil) ? hasil : hasil?.items || hasil?.data || []

      );

    } catch (error) {

      setPesanRiwayatNilai(error.message || "Riwayat nilai gagal dimuat.");

    } finally {

      setLoadingRiwayatNilai(false);

    }

  }

  const daftarKelas = useMemo(() => {

    return dashboard?.daftar_kelas || [];

  }, [dashboard]);

  const namaMahasiswa =

    dashboard?.nama_mahasiswa ||

    pengguna?.nama_lengkap ||

    "Mahasiswa";
  // ==========================================*
  // NAVIGASI*
  // ==========================================*

  function pilihMenu(id) {

    setMenuAktif(id);

    setKelasTerpilih(null);

    setDaftarModul([]);

    setModulTerpilih(null);

    setKuisTerpilih(null);

    setPengerjaanKuis(null);

    setJawabanKuis({});

    setKuisTerpilih(null);

    setPengerjaanKuis(null);

    setJawabanKuis({});

    setPesanModul("");

    setPesanDetail("");

    setPesanDownload("");

    setMenuMobileTerbuka(false);

    if (id === "riwayat-nilai") {

      muatRiwayatNilai();

    }

  }

  function kembaliKeDaftarKelas() {

    setKelasTerpilih(null);

    setDaftarModul([]);

    setModulTerpilih(null);

    setPesanModul("");

    setPesanDetail("");

  }

  function kembaliKeDaftarModul() {

    setModulTerpilih(null);

    setPesanDetail("");

    setPesanDownload("");

  }
  // ==========================================*
  // MEMBUKA DETAIL KELAS*
  // ==========================================*

  async function bukaDetailKelas(kelas) {

    setKelasTerpilih(kelas);

    setModulTerpilih(null);

    setDaftarModul([]);

    setDaftarKuis([]);

    setPesanModul("");

    setPesanKuis("");

    setLoadingModul(true);

    setLoadingKuis(true);

    try {

      const hasil = await ambilDaftarModulMahasiswa(

        token,

        kelas.id

      );

      setDaftarModul(hasil || []);

    } catch (error) {

      setPesanModul(error.message);

    } finally {

      setLoadingModul(false);

    }

    try {

      const hasilKuis = await ambilDaftarKuisMahasiswa(

        token,

        kelas.id

      );

      setDaftarKuis(

        Array.isArray(hasilKuis)

          ? hasilKuis

          : hasilKuis?.items || hasilKuis?.data || []

      );

    } catch (error) {

      setPesanKuis(error.message);

    } finally {

      setLoadingKuis(false);

    }

  }
  // ==========================================*
  // MEMULAI DAN MENGERJAKAN KUIS*
  // ==========================================*

  function bukaDetailKuis(kuis) {

    if (!kuis || kuis.status !== "published") return;

    setKuisTerpilih(kuis);

    setPengerjaanKuis(null);

    setJawabanKuis({});

    setPesanPengerjaan("");

  }

  async function mulaiPengerjaanKuis() {

    if (!kuisTerpilih || loadingMulaiKuis) return;

    setLoadingMulaiKuis(true);

    setPesanPengerjaan("");

    try {

      const hasil = await mulaiKuisMahasiswa(token, kuisTerpilih.id);

      setPengerjaanKuis(hasil);

      setJawabanKuis({});

    } catch (error) {

      setPesanPengerjaan(error.message || "Kuis tidak dapat dimulai.");

    } finally {

      setLoadingMulaiKuis(false);

    }

  }

  async function ubahJawabanKuis(soal, nilai) {

    if (!pengerjaanKuis || mengumpulkanKuis) return;

    const jawaban = soal.question_type === "multiple_choice"

      ? { question_id: soal.id, selected_option_id: nilai, essay_answer: null }

      : { question_id: soal.id, selected_option_id: null, essay_answer: nilai };

    setJawabanKuis((sebelumnya) => ({ ...sebelumnya, [soal.id]: nilai }));

    setMenyimpanJawaban(true);

    setPesanPengerjaan("");

    try {

      await simpanJawabanKuisMahasiswa(token, pengerjaanKuis.attempt_id, jawaban);

    } catch (error) {

      setPesanPengerjaan(`Jawaban belum tersimpan: ${error.message}`);

    } finally {

      setMenyimpanJawaban(false);

    }

  }

  async function kirimKuis(otomatis = false) {

    if (!pengerjaanKuis || mengumpulkanKuis) return;

    if (!otomatis && !window.confirm("Yakin ingin mengumpulkan jawaban? Setelah dikumpulkan, jawaban tidak dapat diubah.")) return;

    setMengumpulkanKuis(true);

    setPesanPengerjaan("");

    try {

      await kumpulkanKuisMahasiswa(token, pengerjaanKuis.attempt_id);

      setPengerjaanKuis((sebelumnya) => ({ ...sebelumnya, status: "submitted" }));

      setPesanPengerjaan(otomatis ? "Waktu habis. Kuis berhasil dikumpulkan otomatis." : "Kuis berhasil dikumpulkan.");

    } catch (error) {

      setPesanPengerjaan(error.message || "Kuis gagal dikumpulkan.");

    } finally {

      setMengumpulkanKuis(false);

    }

  }

  useEffect(() => {
    if (!pengerjaanKuis || pengerjaanKuis.status !== "in_progress") return;

    const deadline = parseWaktuServer(pengerjaanKuis.deadline_at);

    // Jangan menganggap kuis kedaluwarsa jika deadline dari API tidak valid.
    if (!Number.isFinite(deadline)) {
      setSisaWaktu(0);
      setPesanPengerjaan(
        "Batas waktu kuis tidak valid. Silakan hubungi Asisten Laboratorium."
      );
      return;
    }

    const hitung = () => {
      const sisa = Math.max(0, Math.floor((deadline - Date.now()) / 1000));
      setSisaWaktu(sisa);
    };

    hitung();
    const interval = window.setInterval(hitung, 1000);

    return () => window.clearInterval(interval);
  }, [pengerjaanKuis]);

  useEffect(() => {
    if (pengerjaanKuis?.status !== "in_progress") return;

    const deadline = parseWaktuServer(pengerjaanKuis.deadline_at);

    // Pengumpulan otomatis hanya berjalan jika deadline valid dan terlewati.
    if (
      Number.isFinite(deadline) &&
      deadline <= Date.now() &&
      sisaWaktu === 0 &&
      !mengumpulkanKuis
    ) {
      kirimKuis(true);
    }
  }, [sisaWaktu, pengerjaanKuis, mengumpulkanKuis]);

  function formatSisaWaktu(detik) {

    const jam = Math.floor(detik / 3600);

    const menit = Math.floor((detik % 3600) / 60);

    const sisa = detik % 60;

    return [jam, menit, sisa].map((angka) => String(angka).padStart(2, "0")).join(":");

  }
  // ==========================================*
  // MEMBUKA DETAIL MODUL*
  // ==========================================*

  async function bukaDetailModul(modul) {

    setModulTerpilih(null);

    setPesanDetail("");

    setPesanDownload("");

    setLoadingDetail(true);

    try {

      const hasil = await ambilDetailModulMahasiswa(

        token,

        modul.id

      );

      setModulTerpilih(hasil);

    } catch (error) {

      setPesanDetail(error.message);

    } finally {

      setLoadingDetail(false);

    }

  }
  // ==========================================*
  // DOWNLOAD LAMPIRAN*
  // ==========================================*

  async function unduhLampiran(file) {

    if (!modulTerpilih) return;

    setFileSedangDiunduh(file.id);

    setPesanDownload("");

    try {

      await unduhFileModulMahasiswa(

        token,

        modulTerpilih.id,

        file.id,

        file.original_filename

      );

    } catch (error) {

      setPesanDownload(error.message);

    } finally {

      setFileSedangDiunduh(null);

    }

  }
  // ==========================================*
  // KOMPONEN LOADING*
  // ==========================================*

  function renderLoading(teks = "Memuat data...") {

    return (

      <div className="mahasiswa-loading">

        <RefreshCw size={23} className="spinning" />

        <span>{teks}</span>

      </div>

    );

  }
  // ==========================================*
  // EMPTY STATE KELAS*
  // ==========================================*

  function renderKelasKosong() {

    return (

      <div className="mahasiswa-empty-state">

        <div className="mahasiswa-empty-icon">

          <BookOpen size={30} />

        </div>

        <h3>Belum Ada Kelas</h3>

        <p>

          Saat ini kamu belum ditempatkan ke kelas praktikum

          oleh Administrator.

        </p>

      </div>

    );

  }
  // ==========================================*
  // EMPTY STATE MODUL*
  // ==========================================*

  function renderModulKosong() {

    return (

      <div className="mahasiswa-empty-state">

        <div className="mahasiswa-empty-icon">

          <BookMarked size={30} />

        </div>

        <h3>Belum Ada Modul Praktikum</h3>

        <p>

          Belum ada modul yang dipublikasikan oleh Asisten

          Laboratorium untuk kelas ini.

        </p>

      </div>

    );

  }
  // ==========================================*
  // DAFTAR KELAS*
  // ==========================================*

  function renderDaftarKelas(batas = daftarKelas.length) {

    if (daftarKelas.length === 0) {

      return renderKelasKosong();

    }

    return (

      <div className="mahasiswa-class-grid">

        {daftarKelas.slice(0, batas).map((kelas) => (

          <button

            className="mahasiswa-class-card"

            key={kelas.id}

            type="button"

            onClick={() => bukaDetailKelas(kelas)}

          >

            <div className="mahasiswa-class-top">

              <div className="mahasiswa-class-icon">

                <BookOpen size={22} />

              </div>

              <span

                className={`mahasiswa-status ${

                  kelas.is_active ? "active" : "inactive"

                }`}

              >

                {kelas.is_active ? (

                  <CircleCheck size={13} />

                ) : (

                  <CircleAlert size={13} />

                )}

                {kelas.is_active ? "Aktif" : "Tidak Aktif"}

              </span>

            </div>

            <div className="mahasiswa-class-info">

              <span className="mahasiswa-class-code">

                {kelas.mata_kuliah?.code || "-"}

              </span>

              <h3>{kelas.mata_kuliah?.name || "Mata Kuliah"}</h3>

              <p>

                Kelas {kelas.class_code}

                {" · "}

                {kelas.mata_kuliah?.credits ?? 0} SKS

              </p>

            </div>

            <div className="mahasiswa-class-divider" />

            <div className="mahasiswa-class-footer">

              <div>

                <CalendarDays size={15} />

                <span>

                  {kelas.periode_akademik?.semester || "-"}

                  {" "}

                  {kelas.periode_akademik?.academic_year || ""}

                </span>

              </div>

              <span className="mahasiswa-card-arrow">

                <ArrowUpRight size={18} />

              </span>

            </div>

          </button>

        ))}

      </div>

    );

  }
  // ==========================================*
  // OVERVIEW*
  // ==========================================*

  function renderOverview() {

    return (

      <>

        <section className="mahasiswa-welcome">

          <div className="mahasiswa-welcome-content">

            <span className="mahasiswa-welcome-kicker">

              <span className="mahasiswa-welcome-kicker-dot" />

              STUDENT DIGITAL WORKSPACE

            </span>

            <h1>

              Halo, {namaMahasiswa}!

            </h1>

            <p>

              Siap melanjutkan perjalanan praktikum hari ini?

              Semua materi dan aktivitas belajarmu ada di sini.

            </p>

            <div className="mahasiswa-welcome-caption">

              <span className="mahasiswa-welcome-caption-line" />

              <span>Belajar, berproses, dan berkembang bersama LabAssess</span>

            </div>

          </div>

          <div className="mahasiswa-welcome-visual" aria-hidden="true">

            <div className="mahasiswa-welcome-orbit mahasiswa-welcome-orbit-one" />

            <div className="mahasiswa-welcome-orbit mahasiswa-welcome-orbit-two" />

            <div className="mahasiswa-welcome-device">

              <div className="mahasiswa-welcome-device-screen">

                <div className="mahasiswa-welcome-device-top">

                  <span />

                  <span />

                  <span />

                </div>

                <Monitor size={58} strokeWidth={1.45} />

                <span className="mahasiswa-welcome-device-label">LABASSESS</span>

              </div>

              <div className="mahasiswa-welcome-device-base" />

            </div>

            <span className="mahasiswa-welcome-float mahasiswa-welcome-float-one">

              <BookOpen size={17} />

            </span>

            <span className="mahasiswa-welcome-float mahasiswa-welcome-float-two">

              <CircleCheck size={17} />

            </span>

          </div>

        </section>

        <section className="mahasiswa-stat-grid">

          <article className="mahasiswa-stat-card">

            <div className="mahasiswa-stat-icon wine">

              <BookOpen size={21} />

            </div>

            <div>

              <span>Total Kelas</span>

              <strong>{dashboard?.total_kelas ?? 0}</strong>

              <small>Kelas yang kamu ikuti</small>

            </div>

          </article>

          <article className="mahasiswa-stat-card">

            <div className="mahasiswa-stat-icon rose">

              <GraduationCap size={21} />

            </div>

            <div>

              <span>Program Studi</span>

              <strong className="mahasiswa-stat-program">

                {pengguna?.program_studi || "Mahasiswa"}

              </strong>

              <small>Program studi terdaftar</small>

            </div>

          </article>

          <article className="mahasiswa-stat-card">

            <div className="mahasiswa-stat-icon green">

              <BookMarked size={21} />

            </div>

            <div>

              <span>Materi Tersedia</span>

              <strong>—</strong>

              <small>Modul dari kelasmu</small>

            </div>

          </article>

        </section>

        <section className="mahasiswa-content-card">

          <div className="mahasiswa-section-heading">

            <div>

              <span className="mahasiswa-eyebrow">

                MY ACADEMIC CLASSES

              </span>

              <h2>Kelas Saya</h2>

              <p>

                Daftar kelas praktikum yang telah ditetapkan

                untuk akunmu.

              </p>

            </div>

            <button

              className="mahasiswa-text-button"

              onClick={() => pilihMenu("kelas")}

              type="button"

            >

              Lihat Semua

              <ArrowUpRight size={16} />

            </button>

          </div>

          {loading

            ? renderLoading("Memuat kelas...")

            : renderDaftarKelas(3)}

        </section>

      </>

    );

  }
  // ==========================================*
  // HALAMAN KELAS SAYA*
  // ==========================================*

  function renderHalamanKelas() {

    return (

      <section className="mahasiswa-content-card">

        <div className="mahasiswa-section-heading">

          <div>

            <span className="mahasiswa-eyebrow">

              ACADEMIC ASSIGNMENT

            </span>

            <h2>Kelas Saya</h2>

            <p>

              Pilih kelas untuk melihat modul praktikum

              dan materi pembelajaran.

            </p>

          </div>

        </div>

        {loading

          ? renderLoading("Memuat daftar kelas...")

          : renderDaftarKelas()}

      </section>

    );

  }
  // ==========================================*
  // DETAIL KELAS DAN DAFTAR MODUL*
  // ==========================================*

  function renderDetailKelas() {

    if (!kelasTerpilih) return null;

    return (

      <>

        <button

          className="mahasiswa-back-button"

          onClick={kembaliKeDaftarKelas}

          type="button"

        >

          <ArrowLeft size={17} />

          Kembali ke Kelas Saya

        </button>

        <section className="mahasiswa-detail-hero">

          <div className="mahasiswa-detail-hero-icon">

            <BookOpen size={29} />

          </div>

          <div className="mahasiswa-detail-hero-content">

            <span className="mahasiswa-eyebrow">

              DETAIL KELAS

            </span>

            <h2>

              {kelasTerpilih.mata_kuliah?.name}

            </h2>

            <p>

              {kelasTerpilih.mata_kuliah?.code}

              {" · "}

              Kelas {kelasTerpilih.class_code}

              {" · "}

              {kelasTerpilih.mata_kuliah?.credits} SKS

            </p>

            <span

              className={`mahasiswa-status ${

                kelasTerpilih.is_active ? "active" : "inactive"

              }`}

            >

              {kelasTerpilih.is_active ? "Kelas Aktif" : "Tidak Aktif"}

            </span>

          </div>

        </section>

        <section className="mahasiswa-content-card">

          <div className="mahasiswa-section-heading">

            <div>

              <span className="mahasiswa-eyebrow">

                PRACTICUM MATERIALS

              </span>

              <h2>Modul Praktikum</h2>

              <p>

                Materi yang telah dipublikasikan oleh

                Asisten Laboratorium.

              </p>

            </div>

            <div className="mahasiswa-module-count">

              <BookMarked size={16} />

              {daftarModul.length} Modul

            </div>

          </div>

          {loadingModul ? (

            renderLoading("Memuat modul praktikum...")

          ) : pesanModul ? (

            <div className="mahasiswa-error-message">

              <CircleAlert size={18} />

              <span>{pesanModul}</span>

            </div>

          ) : daftarModul.length === 0 ? (

            renderModulKosong()

          ) : (

            <div className="mahasiswa-module-list">

              {daftarModul.map((modul) => (

                <button

                  className="mahasiswa-module-card"

                  key={modul.id}

                  type="button"

                  onClick={() => bukaDetailModul(modul)}

                >

                  <div className="mahasiswa-module-number">

                    {String(modul.module_number).padStart(2, "0")}

                  </div>

                  <div className="mahasiswa-module-info">

                    <span>MODUL {modul.module_number}</span>

                    <h3>{modul.title}</h3>

                    <p>

                      {modul.description ||

                        "Tidak ada deskripsi modul."}

                    </p>

                    <div className="mahasiswa-module-meta">

                      <span>

                        <FileText size={14} />

                        {modul.files?.length || 0} Lampiran

                      </span>

                      <span>

                        <Clock3 size={14} />

                        {formatTanggal(modul.created_at)}

                      </span>

                    </div>

                  </div>

                  <span className="mahasiswa-module-arrow">

                    <ArrowUpRight size={19} />

                  </span>

                </button>

              ))}

            </div>

          )}

        </section>

        {/* ========================================== */}

        {/* PRE-TEST DAN POST-TEST */}

        {/* ========================================== */}

        <section className="mahasiswa-content-card">

          <div className="mahasiswa-section-heading">

            <div>

              <span className="mahasiswa-eyebrow">

                LABORATORY ASSESSMENT

              </span>

              <h2>Evaluasi Praktikum</h2>

              <p>

                Kerjakan Pre-Test dan Post-Test untuk

                mengukur pemahamanmu selama praktikum.

              </p>

            </div>

          </div>

          {loadingKuis ? (

            renderLoading("Memuat daftar evaluasi...")

          ) : pesanKuis ? (

            <div className="mahasiswa-error-message">

              <CircleAlert size={18} />

              <span>{pesanKuis}</span>

            </div>

          ) : (

            <div className="mahasiswa-module-list">

              {["pre_test", "post_test"].map((jenis) => {

                const kuis = daftarKuis.find(

                  (item) => item.quiz_type === jenis

                );

                return (

                  <button

                    className="mahasiswa-module-card"

                    key={jenis}

                    type="button"

                    onClick={() => bukaDetailKuis(kuis)}

                    disabled={!kuis || kuis.status !== "published"}

                    aria-label={`Buka ${jenis === "pre_test" ? "Pre-Test" : "Post-Test"}`}

                  >

                    <div className="mahasiswa-module-number">

                      {jenis === "pre_test" ? "01" : "02"}

                    </div>

                    <div className="mahasiswa-module-info">

                      <span>

                        {jenis === "pre_test"

                          ? "PRE-TEST"

                          : "POST-TEST"}

                      </span>

                      <h3>

                        {kuis?.title ||

                          (jenis === "pre_test"

                            ? "Pre-Test Praktikum"

                            : "Post-Test Praktikum")}

                      </h3>

                      <p>

                        {kuis?.description ||

                          "Kuis belum tersedia untuk kelas ini."}

                      </p>

                      <div className="mahasiswa-module-meta">

                        <span>

                          <Clock3 size={14} />

                          {kuis

                            ? `${kuis.duration_minutes} menit`

                            : "Belum tersedia"}

                        </span>

                        <span>

                          <CircleCheck size={14} />

                          {kuis?.status === "published"

                            ? "Dipublikasikan"

                            : "Belum tersedia"}

                        </span>

                      </div>

                    </div>

                    <span className="mahasiswa-module-arrow">

                      <ArrowUpRight size={19} />

                    </span>

                  </button>

                );

              })}

            </div>

          )}

        </section>

      </>

    );

  }
  // ==========================================*
  // HALAMAN DETAIL / PENGERJAAN KUIS*
  // ==========================================*

  function renderHalamanKuis() {

    if (pengerjaanKuis) {

      const daftarSoal = pengerjaanKuis.questions || [];

      const sudahDikumpulkan = pengerjaanKuis.status !== "in_progress";

      return (

        <>

          <button className="mahasiswa-back-button" type="button" onClick={() => { setPengerjaanKuis(null); setJawabanKuis({}); }}>

            <ArrowLeft size={17} /> Kembali ke informasi kuis

          </button>

          <section className="mahasiswa-content-card quiz-work-card">

            <div className="quiz-work-header">

              <div><span className="mahasiswa-eyebrow">{pengerjaanKuis.quiz_type === "pre_test" ? "PRE-TEST" : "POST-TEST"}</span><h2>{pengerjaanKuis.title}</h2><p>Jawab seluruh pertanyaan dengan teliti.</p></div>

              <div className={`quiz-timer ${sisaWaktu <= 300 ? "warning" : ""}`}><Timer size={19}/><strong>{sudahDikumpulkan ? "Selesai" : formatSisaWaktu(sisaWaktu)}</strong></div>

            </div>

            {pesanPengerjaan && <div className="mahasiswa-error-message"><AlertTriangle size={17}/>{pesanPengerjaan}</div>}

            <div className="quiz-save-status">{menyimpanJawaban ? "Menyimpan jawaban..." : "Jawaban tersimpan otomatis"}</div>

            <div className="quiz-question-list">

              {daftarSoal.map((soal, index) => (

                <article className="quiz-question-card" key={soal.id}>

                  <div className="quiz-question-heading"><span>PERTANYAAN {index + 1}</span><small>{soal.question_type === "essay" ? "Esai" : "Pilihan Ganda"}</small></div>

                  <h3>{soal.question_text}</h3>

                  {soal.question_type === "multiple_choice" ? (

                    <div className="quiz-option-list">

                      {(soal.options || []).map((opsi) => (

                        <label className={`quiz-option ${jawabanKuis[soal.id] === opsi.id ? "selected" : ""}`} key={opsi.id}>

                          <input type="radio" name={`soal-${soal.id}`} value={opsi.id} checked={jawabanKuis[soal.id] === opsi.id} disabled={sudahDikumpulkan} onChange={() => ubahJawabanKuis(soal, opsi.id)}/>

                          <span>{opsi.option_text}</span>

                        </label>

                      ))}

                    </div>

                  ) : (

                    <textarea className="quiz-essay-input" rows={5} placeholder="Tuliskan jawabanmu di sini..." value={jawabanKuis[soal.id] || ""} disabled={sudahDikumpulkan} onChange={(event) => ubahJawabanKuis(soal, event.target.value)}/>

                  )}

                </article>

              ))}

            </div>

            {!sudahDikumpulkan ? (

              <div className="quiz-submit-row"><span>{daftarSoal.length} pertanyaan</span><button className="quiz-submit-button" type="button" onClick={() => kirimKuis(false)} disabled={mengumpulkanKuis || menyimpanJawaban}>{mengumpulkanKuis ? "Mengumpulkan..." : <><Send size={16}/> Kumpulkan Kuis</>}</button></div>

            ) : <div className="quiz-submitted-notice"><Check size={18}/> Kuis telah dikumpulkan. Terima kasih sudah mengerjakan.</div>}

          </section>

        </>

      );

    }

    return (

      <>

        <button className="mahasiswa-back-button" type="button" onClick={() => setKuisTerpilih(null)}><ArrowLeft size={17}/> Kembali ke Detail Kelas</button>

        <section className="mahasiswa-content-card quiz-intro-card">

          <span className="mahasiswa-eyebrow">{kuisTerpilih?.quiz_type === "pre_test" ? "PRE-TEST PRAKTIKUM" : "POST-TEST PRAKTIKUM"}</span>

          <h2>{kuisTerpilih?.title}</h2>

          <p>{kuisTerpilih?.description || "Kerjakan evaluasi praktikum sesuai waktu yang ditentukan."}</p>

          <div className="quiz-info-grid">

            <div><Clock3 size={20}/><span>Durasi</span><strong>{kuisTerpilih?.duration_minutes} menit</strong></div>

            <div><CalendarDays size={20}/><span>Mulai</span><strong>{formatTanggal(kuisTerpilih?.start_at)}</strong></div>

            <div><Timer size={20}/><span>Batas akhir</span><strong>{formatTanggal(kuisTerpilih?.end_at)}</strong></div>

          </div>

          <div className="quiz-instruction"><AlertTriangle size={19}/><div><strong>Perhatikan sebelum memulai</strong><p>Waktu pengerjaan mulai dihitung setelah kamu menekan tombol Mulai Kuis. Jawaban akan disimpan otomatis dan kuis dikumpulkan saat waktu habis.</p></div></div>

          {pesanPengerjaan && <div className="mahasiswa-error-message"><CircleAlert size={17}/>{pesanPengerjaan}</div>}

          <button className="quiz-start-button" type="button" onClick={mulaiPengerjaanKuis} disabled={loadingMulaiKuis}>{loadingMulaiKuis ? <><RefreshCw size={17} className="spinning"/> Menyiapkan kuis...</> : <>Mulai Kuis <ArrowUpRight size={18}/></>}</button>

        </section>

      </>

    );

  }
  // ==========================================*
  // DETAIL MODUL*
  // ==========================================*

  function renderDetailModul() {

    if (!modulTerpilih) return null;

    const daftarFile = modulTerpilih.files || [];

    return (

      <>

        <button

          className="mahasiswa-back-button"

          onClick={kembaliKeDaftarModul}

          type="button"

        >

          <ArrowLeft size={17} />

          Kembali ke Modul Praktikum

        </button>

        <section className="mahasiswa-content-card">

          <div className="mahasiswa-module-detail-heading">

            <div className="mahasiswa-module-number large">

              {String(modulTerpilih.module_number).padStart(2, "0")}

            </div>

            <div>

              <span className="mahasiswa-eyebrow">

                MODUL PRAKTIKUM {modulTerpilih.module_number}

              </span>

              <h2>{modulTerpilih.title}</h2>

              <p>

                Dipublikasikan untuk kelas praktikum

                yang kamu ikuti.

              </p>

            </div>

          </div>

          <div className="mahasiswa-module-description">

            <h3>Deskripsi Modul</h3>

            <p>

              {modulTerpilih.description ||

                "Tidak ada deskripsi untuk modul ini."}

            </p>

          </div>

          <div className="mahasiswa-attachment-heading">

            <div>

              <span className="mahasiswa-eyebrow">

                LEARNING MATERIALS

              </span>

              <h3>Lampiran Materi</h3>

              <p>

                Unduh file materi yang disediakan oleh

                Asisten Laboratorium.

              </p>

            </div>

            <span className="mahasiswa-module-count">

              <FileText size={15} />

              {daftarFile.length} File

            </span>

          </div>

          {pesanDetail && (

            <div className="mahasiswa-error-message">

              <CircleAlert size={18} />

              {pesanDetail}

            </div>

          )}

          {pesanDownload && (

            <div className="mahasiswa-error-message">

              <CircleAlert size={18} />

              {pesanDownload}

            </div>

          )}

          {daftarFile.length === 0 ? (

            <div className="mahasiswa-empty-files">

              <FileText size={25} />

              <p>

                Belum ada file lampiran pada modul ini.

              </p>

            </div>

          ) : (

            <div className="mahasiswa-file-list">

              {daftarFile.map((file) => (

                <div

                  className="mahasiswa-file-item"

                  key={file.id}

                >

                  <div className="mahasiswa-file-icon">

                    <FileText size={21} />

                  </div>

                  <div className="mahasiswa-file-info">

                    <strong>{file.original_filename}</strong>

                    <span>

                      {formatUkuranFile(file.file_size)}

                      {" · "}

                      {formatTanggal(file.uploaded_at)}

                    </span>

                  </div>

                  <button

                    className="mahasiswa-download-button"

                    type="button"

                    onClick={() => unduhLampiran(file)}

                    disabled={fileSedangDiunduh === file.id}

                    title="Unduh lampiran"

                  >

                    {fileSedangDiunduh === file.id ? (

                      <RefreshCw

                        size={17}

                        className="spinning"

                      />

                    ) : (

                      <Download size={18} />

                    )}

                    <span>

                      {fileSedangDiunduh === file.id

                        ? "Mengunduh..."

                        : "Unduh"}

                    </span>

                  </button>

                </div>

              ))}

            </div>

          )}

        </section>

      </>

    );

  }
  // ==========================================*
  // RIWAYAT NILAI MAHASISWA*
  // ==========================================*

  function renderRiwayatNilai() {
    const statusLabel = (statusPenilaian, statusPengerjaan) => {
      if (statusPenilaian === "published") return "Nilai telah dipublikasikan";
      if (statusPenilaian === "graded") return "Sudah dinilai · menunggu publikasi";
      if (statusPenilaian === "pending_review") return "Menunggu penilaian asisten";
      if (statusPengerjaan === "in_progress") return "Sedang dikerjakan";
      if (statusPengerjaan === "submitted") return "Sudah dikumpulkan";
      return "Belum dinilai";
    };

    const jumlahDipublikasikan = riwayatNilai.filter(
      (item) => item.status_penilaian === "published"
    ).length;
    const jumlahMenunggu = riwayatNilai.length - jumlahDipublikasikan;

    // Kelompokkan per penawaran mata kuliah/kelas agar hasil dari dua kelas
    // berbeda tidak tercampur meskipun nama mata kuliahnya sama.
    const kelompokMataKuliah = new Map();
    riwayatNilai.forEach((item) => {
      const kunciKelas = item.class_id ?? `tanpa-kelas-${item.course_id ?? "lainnya"}`;
      if (!kelompokMataKuliah.has(kunciKelas)) {
        kelompokMataKuliah.set(kunciKelas, {
          key: kunciKelas,
          courseName: item.course_name || "Mata Kuliah",
          courseCode: item.course_code || "-",
          classCode: item.class_code || "-",
          modules: new Map(),
        });
      }

      const kelompok = kelompokMataKuliah.get(kunciKelas);
      const kunciModul = item.module_id == null ? "legacy" : String(item.module_id);
      if (!kelompok.modules.has(kunciModul)) {
        kelompok.modules.set(kunciModul, {
          key: kunciModul,
          moduleId: item.module_id ?? null,
          moduleNumber: item.module_number,
          moduleTitle: item.module_title,
          items: [],
        });
      }
      kelompok.modules.get(kunciModul).items.push(item);
    });

    const daftarKelompok = Array.from(kelompokMataKuliah.values());

    return (
      <div className="mahasiswa-score-page">

        <section className="mahasiswa-score-summary" aria-label="Ringkasan riwayat nilai">
          <article className="mahasiswa-score-summary-card">
            <span className="mahasiswa-score-summary-icon total"><Layers3 size={20} /></span>
            <div><small>Total Evaluasi</small><strong>{riwayatNilai.length}</strong><span>Seluruh riwayat kuis</span></div>
          </article>
          <article className="mahasiswa-score-summary-card">
            <span className="mahasiswa-score-summary-icon published"><CircleCheck size={20} /></span>
            <div><small>Nilai Dipublikasikan</small><strong>{jumlahDipublikasikan}</strong><span>Hasil yang sudah dapat dilihat</span></div>
          </article>
          <article className="mahasiswa-score-summary-card">
            <span className="mahasiswa-score-summary-icon waiting"><Clock3 size={20} /></span>
            <div><small>Dalam Proses</small><strong>{jumlahMenunggu}</strong><span>Menunggu penilaian atau publikasi</span></div>
          </article>
        </section>

        <section className="mahasiswa-content-card mahasiswa-score-content">
          <div className="mahasiswa-section-heading mahasiswa-score-heading">
            <div>
              <span className="mahasiswa-eyebrow">ASSESSMENT RECORD</span>
              <h2>Daftar Hasil Evaluasi</h2>
              <p>Hasil evaluasi dikelompokkan berdasarkan mata kuliah, kemudian modul praktikum.</p>
            </div>
            <button className="mahasiswa-refresh-button" type="button" onClick={muatRiwayatNilai} disabled={loadingRiwayatNilai}>
              <RefreshCw size={16} className={loadingRiwayatNilai ? "spinning" : ""} />
              <span>{loadingRiwayatNilai ? "Memuat..." : "Perbarui"}</span>
            </button>
          </div>

          {pesanRiwayatNilai && <div className="mahasiswa-error-message"><CircleAlert size={18} /><span>{pesanRiwayatNilai}</span></div>}
          {loadingRiwayatNilai ? renderLoading("Memuat riwayat nilai...") : riwayatNilai.length === 0 ? (
            <div className="mahasiswa-empty-state mahasiswa-score-empty">
              <div className="mahasiswa-empty-icon"><History size={30} /></div>
              <h3>Belum Ada Riwayat Evaluasi</h3>
              <p>Riwayat Pre-Test dan Post-Test akan muncul di sini setelah kamu mengumpulkan kuis.</p>
            </div>
          ) : (
            <div className="mahasiswa-course-history-list">
              {daftarKelompok.map((kelompok) => (
                <article className="mahasiswa-course-history-card" key={kelompok.key}>
                  <header className="mahasiswa-course-history-header">
                    <div className="mahasiswa-course-history-icon"><BookOpen size={21} /></div>
                    <div className="mahasiswa-course-history-title">
                      <span>{kelompok.courseCode} · KELAS {kelompok.classCode}</span>
                      <h3>{kelompok.courseName}</h3>
                    </div>
                    <span className="mahasiswa-course-history-count">
                      {Array.from(kelompok.modules.values()).reduce((total, modul) => total + modul.items.length, 0)} Evaluasi
                    </span>
                  </header>

                  <div className="mahasiswa-course-history-modules">
                    {Array.from(kelompok.modules.values())
                      .sort((a, b) => {
                        if (a.moduleId == null) return 1;
                        if (b.moduleId == null) return -1;
                        return (a.moduleNumber ?? 9999) - (b.moduleNumber ?? 9999);
                      })
                      .map((modul) => (
                        <section className="mahasiswa-module-history" key={modul.key}>
                          <div className="mahasiswa-module-history-heading">
                            <div>
                              <span>{modul.moduleId == null ? "EVALUASI TANPA MODUL" : `MODUL ${modul.moduleNumber ?? "-"}`}</span>
                              <h4>{modul.moduleId == null ? "Evaluasi Lama" : (modul.moduleTitle || "Modul Praktikum")}</h4>
                            </div>
                            <span>{modul.items.length} Hasil</span>
                          </div>

                          <div className="mahasiswa-score-history-list">
                            {modul.items
                              .slice()
                              .sort((a, b) => {
                                const urutan = { pre_test: 0, post_test: 1 };
                                return (urutan[a.jenis_kuis] ?? 2) - (urutan[b.jenis_kuis] ?? 2);
                              })
                              .map((item, index) => {
                                const dipublikasikan = item.status_penilaian === "published" && item.nilai_akhir !== null && item.nilai_akhir !== undefined;
                                const jenisPreTest = item.jenis_kuis === "pre_test";
                                const status = item.status_penilaian || "ungraded";
                                const tanggal = item.submitted_at || item.submitted_at_utc || item.tanggal_pengumpulan || item.created_at;
                                const nilai = Number(item.nilai_akhir);
                                const judul = item.judul_kuis || (jenisPreTest ? "Pre-Test" : "Post-Test");
                                return (
                                  <article className="mahasiswa-score-history-item" key={item.attempt_id || item.id || `${item.quiz_id || "kuis"}-${index}`}>
                                    <div className={`mahasiswa-score-history-icon ${jenisPreTest ? "pre" : "post"}`}><GraduationCap size={22} /></div>
                                    <div className="mahasiswa-score-history-info">
                                      <div className="mahasiswa-score-title-row">
                                        <span className={`mahasiswa-score-history-type ${jenisPreTest ? "pre" : "post"}`}>{jenisPreTest ? "PRE-TEST" : "POST-TEST"}</span>
                                      </div>
                                      <h3>{judul}</h3>
                                      <p><CalendarDays size={13} /> Dikumpulkan: {formatTanggal(tanggal)}</p>
                                      <span className={`mahasiswa-score-status ${status}`}>{statusLabel(item.status_penilaian, item.status_pengerjaan || item.status)}</span>
                                    </div>
                                    <div className={`mahasiswa-score-history-result ${dipublikasikan ? "is-published" : ""}`}>
                                      <span>Nilai Akhir</span>
                                      <strong>{dipublikasikan && Number.isFinite(nilai) ? nilai.toFixed(2) : "—"}</strong>
                                      <small>{dipublikasikan ? "Sudah dipublikasikan" : "Belum tersedia"}</small>
                                    </div>
                                  </article>
                                );
                              })}
                          </div>
                        </section>
                      ))}
                  </div>
                </article>
              ))}
              <div className="mahasiswa-score-footnote"><CircleAlert size={15} /> Nilai yang belum dipublikasikan tidak akan ditampilkan. Periksa kembali setelah Asisten Laboratorium mengumumkan hasil penilaian.</div>
            </div>
          )}
        </section>
      </div>
    );
  }

  const judulHalaman = pengerjaanKuis

    ? "Pengerjaan Kuis"

    : kuisTerpilih

      ? "Detail Evaluasi"

      : modulTerpilih

        ? "Detail Modul"

        : kelasTerpilih

      ? "Detail Kelas"

      : menuAktif === "kelas"

        ? "Kelas Saya"

        : menuAktif === "riwayat-nilai"

          ? "Riwayat Nilai"

          : "Overview";
  // ==========================================*
  // TAMPILAN UTAMA*
  // ==========================================*

  return (

    <main className="mahasiswa-dashboard">

      <div className="mahasiswa-decoration one" />

      <div className="mahasiswa-decoration two" />

      {/* TOPBAR */}

      <header className="mahasiswa-topbar">

        <a className="mahasiswa-brand" href="#overview">

          <span className="mahasiswa-brand-icon">

            <Monitor size={23} strokeWidth={2} />

          </span>

          <span className="mahasiswa-brand-name">

            LabAssess

            <small>LABORATORY SYSTEM</small>

          </span>

        </a>

        <div className="mahasiswa-topbar-right">

          <div className="mahasiswa-user-profile">

            <div className="mahasiswa-avatar">

              {namaMahasiswa.charAt(0).toUpperCase()}

            </div>

            <div className="mahasiswa-user-detail">

              <strong>{namaMahasiswa}</strong>

              <span>Mahasiswa</span>

            </div>

          </div>

          <button

            className="mahasiswa-logout-button"

            onClick={onLogout}

            type="button"

          >

            <LogOut size={17} />

            <span>Keluar</span>

          </button>

          <button

            className="mahasiswa-mobile-menu-button"

            onClick={() =>

              setMenuMobileTerbuka((nilai) => !nilai)

            }

            type="button"

            aria-label="Buka navigasi"

          >

            {menuMobileTerbuka ? (

              <X size={21} />

            ) : (

              <Menu size={21} />

            )}

          </button>

        </div>

      </header>

      {/* NAVIGASI KAPSUL */}

      <div className="mahasiswa-navigation-wrapper">

        <nav

          className={`mahasiswa-navigation ${

            menuMobileTerbuka ? "mobile-open" : ""

          }`}

        >

          {MENU_MAHASISWA.map((item) => {

            const Icon = item.icon;

            const aktif =

              menuAktif === item.id &&

              !kelasTerpilih &&

              !modulTerpilih &&

              !kuisTerpilih &&

              !pengerjaanKuis;

            return (

              <button

                key={item.id}

                className={`mahasiswa-nav-item ${

                  aktif ? "active" : ""

                }`}

                onClick={() => pilihMenu(item.id)}

                type="button"

              >

                <Icon size={17} />

                <span>{item.label}</span>

              </button>

            );

          })}

        </nav>

      </div>

      {/* KONTEN */}

      <div className="mahasiswa-main-content">

        <div className="mahasiswa-page-toolbar">

          <div>

            <span className="mahasiswa-page-label">

              STUDENT WORKSPACE

            </span>

            <h2>{judulHalaman}</h2>

          </div>

          <button

            className="mahasiswa-refresh-button"

            onClick={muatDashboard}

            disabled={loading}

            type="button"

          >

            <RefreshCw

              size={16}

              className={(menuAktif === "riwayat-nilai" ? loadingRiwayatNilai : loading) ? "spinning" : ""}

            />

            <span>Perbarui Data</span>

          </button>

        </div>

        {pesan && (

          <div className="mahasiswa-error-message">

            <CircleAlert size={18} />

            <span>{pesan}</span>

            <button

              onClick={muatDashboard}

              type="button"

            >

              Coba Lagi

            </button>

          </div>

        )}

        {loading && !dashboard ? (

          renderLoading("Memuat dashboard mahasiswa...")

        ) : pengerjaanKuis || kuisTerpilih ? (

          renderHalamanKuis()

        ) : modulTerpilih ? (

          renderDetailModul()

        ) : loadingDetail ? (

          renderLoading("Memuat detail modul...")

        ) : kelasTerpilih ? (

          renderDetailKelas()

        ) : menuAktif === "kelas" ? (

          renderHalamanKelas()

        ) : menuAktif === "riwayat-nilai" ? (

          renderRiwayatNilai()

        ) : (

          renderOverview()

        )}

      </div>

      {/* FOOTER */}

      <footer className="mahasiswa-footer">

        <span>© {new Date().getFullYear()} LabAssess</span>

        <span>Laboratory Assessment System · STITEK Bontang</span>

      </footer>

    </main>

  );

}
