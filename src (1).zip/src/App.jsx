
import { useEffect, useState } from "react";

import {
  Monitor,
  ShieldCheck,
  GraduationCap,
  BookOpen,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Eye,
  EyeOff,
  LogOut,
  LockKeyhole,
  UserRound,
  KeyRound,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";

// ============================================
// IMPORT DASHBOARD
// ============================================

// Dashboard Admin
import DashboardAdmin from "./pages/admin/DashboardAdmin.jsx";

// Dashboard Asisten
import DashboardAsisten from "./pages/asisten/DashboardAsisten.jsx";

// Dashboard Mahasiswa
import DashboardMahasiswa from "./pages/mahasiswa/DashboardMahasiswa.jsx";


const API_BASE_URL = "/api/v1";


const ROLES = [
  {
    id: "admin_developer",
    title: "Administrator",
    description: "Kelola akun dan aktivitas laboratorium",
    icon: ShieldCheck,
  },
  {
    id: "asisten_lab",
    title: "Asisten Laboratorium",
    description: "Kelola modul, kuis, dan penilaian",
    icon: BookOpen,
  },
  {
    id: "mahasiswa",
    title: "Mahasiswa",
    description: "Ikuti praktikum dan kerjakan kuis",
    icon: GraduationCap,
  },
];


const PROGRAM_STUDI = [
  { id: 1, nama: "Teknik Informatika" },
  { id: 2, nama: "Sistem Informasi" },
  { id: 3, nama: "Bisnis Digital" },
  { id: 4, nama: "Teknik Elektro" },
  { id: 5, nama: "Teknik Lingkungan" },
  { id: 6, nama: "Teknik Industri" },
];


// ============================================
// API REQUEST
// ============================================

async function requestApi(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options.token
        ? { Authorization: `Bearer ${options.token}` }
        : {}),
      ...options.headers,
    },
    body: options.body
      ? JSON.stringify(options.body)
      : undefined,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const detail = data.detail;

    if (typeof detail === "string") {
      throw new Error(detail);
    }

    if (detail?.pesan) {
      throw new Error(detail.pesan);
    }

    if (Array.isArray(detail)) {
      throw new Error(
        detail.map((item) => item.msg).join(", ")
      );
    }

    throw new Error("Terjadi kesalahan pada server.");
  }

  return data;
}


// ============================================
// MAIN APP
// ============================================

function App() {

  // ------------------------------------------
  // STATE HALAMAN DAN AUTENTIKASI
  // ------------------------------------------

  const [halaman, setHalaman] = useState("splash");

  const [role, setRole] = useState(null);

  const [pengguna, setPengguna] = useState(null);

  const [token, setToken] = useState(
    () => localStorage.getItem("labassess_token")
  );


  // ------------------------------------------
  // STATE FORM LOGIN
  // ------------------------------------------

  const [form, setForm] = useState({
    identitas: "",
    password: "",
  });


  // ------------------------------------------
  // STATE FORM REGISTRASI
  // ------------------------------------------

  const [registrasi, setRegistrasi] = useState({
    nama_lengkap: "",
    nim: "",
    program_studi_id: "1",
    password: "",
    konfirmasi_password: "",
  });


  // ------------------------------------------
  // STATE GANTI PASSWORD
  // ------------------------------------------

  const [passwordBaru, setPasswordBaru] = useState("");

  const [konfirmasiPassword, setKonfirmasiPassword] =
    useState("");


  // ------------------------------------------
  // STATE UMUM
  // ------------------------------------------

  const [loading, setLoading] = useState(false);

  const [pesan, setPesan] = useState("");

  const [jenisPesan, setJenisPesan] = useState("error");

  const [tampilkanPassword, setTampilkanPassword] =
    useState(false);


  // ==========================================
  // MEMULIHKAN SESSION LOGIN
  // ==========================================

  useEffect(() => {
    if (!token) return;

    const dataPengguna = localStorage.getItem(
      "labassess_user"
    );

    if (!dataPengguna) {
      localStorage.removeItem("labassess_token");
      setToken(null);
      return;
    }

    try {
      const data = JSON.parse(dataPengguna);

      setPengguna(data);
      setRole(data.role);

      setHalaman(
        data.wajib_ganti_password
          ? "ganti-password"
          : "dashboard"
      );
    } catch {
      localStorage.removeItem("labassess_token");
      localStorage.removeItem("labassess_user");

      setToken(null);
      setPengguna(null);
      setRole(null);
      setHalaman("splash");
    }
  }, []);


  // ==========================================
  // FUNGSI PESAN
  // ==========================================

  function tampilkanPesan(teks, jenis = "error") {
    setPesan(teks);
    setJenisPesan(jenis);
  }


  // ==========================================
  // FUNGSI FORM
  // ==========================================

  function ubahForm(event) {
    const { name, value } = event.target;

    setForm((sebelumnya) => ({
      ...sebelumnya,
      [name]: value,
    }));
  }


  function ubahRegistrasi(event) {
    const { name, value } = event.target;

    setRegistrasi((sebelumnya) => ({
      ...sebelumnya,
      [name]: value,
    }));
  }


  // ==========================================
  // PEMILIHAN ROLE
  // ==========================================

  function pilihRole(roleTerpilih) {
    setRole(roleTerpilih);

    setForm({
      identitas: "",
      password: "",
    });

    setPesan("");
    setHalaman("login");
  }


  function kembaliKeRole() {
    setRole(null);
    setPesan("");
    setHalaman("role");
  }


  // ==========================================
  // PROSES LOGIN
  // ==========================================

  async function prosesLogin(event) {
    event.preventDefault();

    if (!role) return;

    setLoading(true);
    setPesan("");

    try {
      const hasil = await requestApi("/auth/login", {
        method: "POST",
        body: {
          role,
          identitas: form.identitas.trim(),
          password: form.password,
        },
      });

      localStorage.setItem(
        "labassess_token",
        hasil.access_token
      );

      localStorage.setItem(
        "labassess_user",
        JSON.stringify(hasil.pengguna)
      );

      setToken(hasil.access_token);
      setPengguna(hasil.pengguna);
      setRole(hasil.pengguna.role);

      if (hasil.pengguna.wajib_ganti_password) {
        setHalaman("ganti-password");
      } else {
        setHalaman("dashboard");
      }

      setForm({
        identitas: "",
        password: "",
      });

      tampilkanPesan("Login berhasil.", "success");

    } catch (error) {
      tampilkanPesan(error.message);

    } finally {
      setLoading(false);
    }
  }


  // ==========================================
  // PROSES REGISTRASI MAHASISWA
  // ==========================================

  async function prosesRegistrasi(event) {
    event.preventDefault();

    setLoading(true);
    setPesan("");

    if (
      registrasi.password !==
      registrasi.konfirmasi_password
    ) {
      tampilkanPesan(
        "Konfirmasi password tidak sesuai."
      );

      setLoading(false);
      return;
    }

    try {
      await requestApi("/auth/register", {
        method: "POST",
        body: {
          ...registrasi,
          program_studi_id: Number(
            registrasi.program_studi_id
          ),
        },
      });

      tampilkanPesan(
        "Registrasi berhasil. Silakan login menggunakan NIM dan password.",
        "success"
      );

      setForm({
        identitas: registrasi.nim,
        password: "",
      });

      setRole("mahasiswa");
      setHalaman("login");

      setRegistrasi({
        nama_lengkap: "",
        nim: "",
        program_studi_id: "1",
        password: "",
        konfirmasi_password: "",
      });

    } catch (error) {
      tampilkanPesan(error.message);

    } finally {
      setLoading(false);
    }
  }


  // ==========================================
  // PROSES GANTI PASSWORD
  // ==========================================

  async function prosesGantiPassword(event) {
    event.preventDefault();

    setLoading(true);
    setPesan("");

    if (passwordBaru !== konfirmasiPassword) {
      tampilkanPesan(
        "Konfirmasi password tidak sesuai."
      );

      setLoading(false);
      return;
    }

    if (passwordBaru.length < 8) {
      tampilkanPesan(
        "Password baru minimal terdiri dari 8 karakter."
      );

      setLoading(false);
      return;
    }

    try {
      await requestApi("/auth/ganti-password", {
        method: "POST",
        token,
        body: {
          password_baru: passwordBaru,
          konfirmasi_password: konfirmasiPassword,
        },
      });

      const penggunaBaru = {
        ...pengguna,
        wajib_ganti_password: false,
      };

      localStorage.setItem(
        "labassess_user",
        JSON.stringify(penggunaBaru)
      );

      setPengguna(penggunaBaru);

      setPasswordBaru("");
      setKonfirmasiPassword("");

      setHalaman("dashboard");

      tampilkanPesan(
        "Password berhasil diubah. Selamat datang di LabAssess!",
        "success"
      );

    } catch (error) {
      tampilkanPesan(error.message);

    } finally {
      setLoading(false);
    }
  }


  // ==========================================
  // LOGOUT
  // ==========================================

  function logout() {
    localStorage.removeItem("labassess_token");
    localStorage.removeItem("labassess_user");

    setToken(null);
    setPengguna(null);
    setRole(null);

    setPasswordBaru("");
    setKonfirmasiPassword("");

    setForm({
      identitas: "",
      password: "",
    });

    setPesan("");
    setJenisPesan("error");

    setHalaman("splash");
  }


  // ==========================================
  // ROLE AKTIF
  // ==========================================

  const roleAktif = ROLES.find(
    (item) => item.id === role
  );


  // ==========================================
  // DASHBOARD ADMIN
  // ==========================================

  if (
    halaman === "dashboard" &&
    pengguna?.role === "admin_developer"
  ) {
    return (
      <DashboardAdmin
        key={`${pengguna.id}-${token}`}
        pengguna={pengguna}
        token={token}
        onLogout={logout}
      />
    );
  }


  // ==========================================
  // DASHBOARD ASISTEN LABORATORIUM
  // ==========================================

  if (
    halaman === "dashboard" &&
    pengguna?.role === "asisten_lab"
  ) {
    return (
      <DashboardAsisten
        pengguna={pengguna}
        token={token}
        onLogout={logout}
      />
    );
  }


  // ==========================================
  // DASHBOARD MAHASISWA
  // ==========================================

  if (
    halaman === "dashboard" &&
    pengguna?.role === "mahasiswa"
  ) {
    return (
      <DashboardMahasiswa
        pengguna={pengguna}
        token={token}
        onLogout={logout}
      />
    );
  }


  // ==========================================
  // TAMPILAN UTAMA
  // ==========================================

  return (
    <main className="app-shell">

      <style>{`
        .role-selection-layout {
          position: relative;
          isolation: isolate;
          overflow: hidden;
          width: min(100% - 32px, 760px);
          margin: clamp(24px, 5vh, 64px) auto;
          padding: clamp(30px, 5vw, 58px);
          border: 1px solid rgba(130, 78, 101, .13);
          border-radius: 32px;
          background:
            radial-gradient(circle at 92% 8%, rgba(201, 158, 173, .20), transparent 27%),
            radial-gradient(circle at 4% 92%, rgba(130, 78, 101, .10), transparent 30%),
            rgba(255, 255, 255, .78);
          box-shadow: 0 24px 70px rgba(72, 42, 56, .10), inset 0 1px 0 rgba(255,255,255,.9);
          backdrop-filter: blur(22px);
          animation: rolePanelEnter .75s cubic-bezier(.2,.75,.25,1) both;
        }

        .role-selection-layout::before,
        .role-selection-layout::after {
          content: "";
          position: absolute;
          z-index: -1;
          pointer-events: none;
          border: 1px solid rgba(130, 78, 101, .13);
          border-radius: 50%;
        }
        .role-selection-layout::before {
          width: 310px; height: 310px; right: -145px; top: -175px;
          box-shadow: 0 0 0 22px rgba(201,158,173,.045), 0 0 0 48px rgba(201,158,173,.035);
          animation: roleOrbit 18s linear infinite;
        }
        .role-selection-layout::after {
          width: 190px; height: 190px; left: -112px; bottom: -118px;
          background: radial-gradient(circle, rgba(201,158,173,.15), transparent 70%);
          animation: roleFloat 8s ease-in-out infinite;
        }

        .role-selection-heading,
        .role-selection-list,
        .role-selection-layout .auth-footer {
          position: relative;
          z-index: 1;
        }

        .role-selection-brand {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 28px;
          color: #482A38;
          font-weight: 800;
          letter-spacing: -.03em;
        }
        .role-selection-brand svg {
          color: #824E65;
          filter: drop-shadow(0 4px 8px rgba(130,78,101,.18));
        }

        .role-selection-heading .eyebrow {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 8px 12px;
          margin-top: 8px;
          border: 1px solid rgba(130,78,101,.12);
          border-radius: 999px;
          background: rgba(248,244,246,.9);
          color: #824E65;
          letter-spacing: .13em;
          font-size: 11px;
          font-weight: 800;
        }
        .role-selection-heading h1 {
          margin-top: 16px;
          color: #482A38;
          letter-spacing: -.055em;
          animation: roleTextEnter .7s .12s both;
        }
        .role-selection-heading p {
          max-width: 560px;
          line-height: 1.75;
          animation: roleTextEnter .7s .2s both;
        }

        .role-selection-list {
          display: grid;
          gap: 14px;
          margin-top: 34px;
        }
        .role-selection-card {
          position: relative;
          display: flex;
          align-items: center;
          gap: 18px;
          min-height: 104px;
          padding: 19px 21px;
          overflow: hidden;
          border: 1px solid rgba(130,78,101,.15);
          border-radius: 23px;
          background: linear-gradient(115deg, rgba(255,255,255,.96), rgba(250,246,248,.88));
          box-shadow: 0 5px 16px rgba(72,42,56,.035);
          text-align: left;
          transform: translateY(18px);
          opacity: 0;
          animation: roleCardEnter .65s cubic-bezier(.2,.75,.25,1) forwards;
          transition: transform .28s ease, box-shadow .28s ease, border-color .28s ease, background .28s ease;
        }
        .role-selection-card:nth-child(1) { animation-delay: .18s; }
        .role-selection-card:nth-child(2) { animation-delay: .31s; }
        .role-selection-card:nth-child(3) { animation-delay: .44s; }
        .role-selection-card::before {
          content: "";
          position: absolute;
          inset: 0 auto 0 0;
          width: 4px;
          background: linear-gradient(180deg, #C99EAD, #824E65);
          transform: scaleY(0);
          transform-origin: bottom;
          transition: transform .28s ease;
        }
        .role-selection-card::after {
          content: "";
          position: absolute;
          top: -80%; left: -35%;
          width: 28%; height: 260%;
          transform: rotate(24deg);
          background: linear-gradient(90deg, transparent, rgba(255,255,255,.72), transparent);
          transition: left .65s ease;
          pointer-events: none;
        }
        .role-selection-card:hover {
          transform: translateY(-5px);
          border-color: rgba(130,78,101,.34);
          background: #fff;
          box-shadow: 0 18px 34px rgba(72,42,56,.11);
        }
        .role-selection-card:hover::before { transform: scaleY(1); }
        .role-selection-card:hover::after { left: 115%; }
        .role-selection-card:focus-visible {
          outline: 3px solid rgba(130,78,101,.28);
          outline-offset: 4px;
        }
        .role-selection-icon {
          flex: 0 0 62px;
          width: 62px; height: 62px;
          display: grid; place-items: center;
          border: 1px solid rgba(130,78,101,.08);
          border-radius: 19px;
          background: linear-gradient(145deg, #F7EDF2, #F0E2E9);
          color: #824E65;
          transition: transform .3s ease, border-radius .3s ease, background .3s ease;
        }
        .role-selection-card:nth-child(2) .role-selection-icon {
          background: linear-gradient(145deg, #FBF2E7, #F5E8D8);
          color: #A47748;
        }
        .role-selection-card:nth-child(3) .role-selection-icon {
          background: linear-gradient(145deg, #F2EBF6, #EAE1F0);
          color: #80618F;
        }
        .role-selection-card:hover .role-selection-icon {
          transform: translateY(-3px) rotate(-4deg) scale(1.06);
          border-radius: 22px;
        }
        .role-selection-card .role-description {
          display: grid;
          gap: 6px;
          flex: 1;
          min-width: 0;
        }
        .role-selection-card .role-description strong {
          color: #482A38;
          font-size: 16px;
          font-weight: 800;
          letter-spacing: -.02em;
        }
        .role-selection-card .role-description small {
          color: #8B7D85;
          font-size: 13px;
          line-height: 1.5;
        }
        .role-selection-arrow {
          flex: 0 0 44px;
          width: 44px; height: 44px;
          display: grid; place-items: center;
          border-radius: 15px;
          background: #F8F2F5;
          color: #824E65;
          transition: transform .28s ease, background .28s ease, color .28s ease;
        }
        .role-selection-card:hover .role-selection-arrow {
          transform: translateX(4px);
          background: #824E65;
          color: #fff;
        }
        .role-selection-layout .auth-footer {
          margin-top: 28px;
        }

        @keyframes rolePanelEnter {
          from { opacity: 0; transform: translateY(22px) scale(.985); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
        @keyframes roleTextEnter {
          from { opacity: 0; transform: translateY(12px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes roleCardEnter {
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes roleOrbit { to { transform: rotate(360deg); } }
        @keyframes roleFloat {
          0%,100% { transform: translate(0,0); }
          50% { transform: translate(12px,-15px); }
        }

        @media (max-width: 640px) {
          .role-selection-layout {
            width: min(100% - 20px, 520px);
            margin: 12px auto;
            padding: 26px 18px;
            border-radius: 25px;
          }
          .role-selection-brand { margin-bottom: 22px; }
          .role-selection-heading h1 { font-size: clamp(32px, 9vw, 42px); }
          .role-selection-list { gap: 11px; margin-top: 25px; }
          .role-selection-card { min-height: 88px; padding: 14px; gap: 12px; border-radius: 19px; }
          .role-selection-icon { flex-basis: 52px; width: 52px; height: 52px; border-radius: 16px; }
          .role-selection-card .role-description strong { font-size: 14px; }
          .role-selection-card .role-description small { font-size: 11px; }
          .role-selection-arrow { flex-basis: 38px; width: 38px; height: 38px; border-radius: 13px; }
        }
        @media (prefers-reduced-motion: reduce) {
          .role-selection-layout, .role-selection-layout *,
          .role-selection-layout::before, .role-selection-layout::after {
            animation: none !important;
            transition: none !important;
            opacity: 1 !important;
            transform: none !important;
          }
        }
      `}</style>

      <div className="background-decoration decoration-one" />
      <div className="background-decoration decoration-two" />
      <div className="background-decoration decoration-three" />


      {/* =====================================
          SPLASH SCREEN
      ===================================== */}

      {halaman === "splash" && (
        <section className="splash-screen">

          <div className="splash-logo">
            <Monitor size={32} />
          </div>

          <div className="splash-content">

            <span className="eyebrow">
              <Sparkles size={15} />
              LABORATORY ASSESSMENT SYSTEM
            </span>

            <h1>
              Welcome to
              <br />
              <span>LabAssess.</span>
            </h1>

            <p>
              Satu ruang terintegrasi untuk pengelolaan
              praktikum dan penilaian laboratorium.
            </p>

            <button
              className="primary-button"
              onClick={() => setHalaman("role")}
            >
              Mulai Sekarang
              <ArrowRight size={18} />
            </button>

          </div>

          <span className="splash-footer">
            STITEK Bontang · Laboratory Assessment System
          </span>

        </section>
      )}


      {/* =====================================
          PILIH ROLE
      ===================================== */}

      {halaman === "role" && (
        <section className="auth-layout role-selection-layout">

          <div className="auth-heading role-selection-heading">

            <button
              className="back-button"
              onClick={() => setHalaman("splash")}
            >
              <ArrowLeft size={19} />
            </button>

            <div className="small-brand role-selection-brand">
              <Monitor size={21} />
              <span>LabAssess</span>
            </div>

            <span className="eyebrow">
              <Sparkles size={14} />
              WELCOME BACK
            </span>

            <h1>Pilih peranmu.</h1>

            <p>
              Silakan pilih jenis akun untuk melanjutkan
              ke halaman masuk LabAssess.
            </p>

          </div>


          <div className="role-list role-selection-list">

            {ROLES.map((item) => {
              const Icon = item.icon;

              return (
                <button
                  className="role-card role-selection-card"
                  key={item.id}
                  onClick={() => pilihRole(item.id)}
                >

                  <span className="role-icon role-selection-icon">
                    <Icon size={25} />
                  </span>

                  <span className="role-description">
                    <strong>{item.title}</strong>
                    <small>{item.description}</small>
                  </span>

                  <span className="role-arrow role-selection-arrow">
                    <ArrowRight size={19} />
                  </span>

                </button>
              );
            })}

          </div>


          <p className="auth-footer">
            Belum mempunyai akun mahasiswa?{" "}

            <button
              onClick={() => {
                setRole("mahasiswa");
                setHalaman("register");
                setPesan("");
              }}
            >
              Daftar sekarang
            </button>

          </p>

        </section>
      )}


      {/* =====================================
          LOGIN
      ===================================== */}

      {halaman === "login" && roleAktif && (
        <section className="auth-layout">

          <div className="auth-heading">

            <button
              className="back-button"
              onClick={kembaliKeRole}
            >
              <ArrowLeft size={19} />
            </button>

            <div className="small-brand">
              <Monitor size={21} />
              <span>LabAssess</span>
            </div>

            <div className="role-icon large-role-icon">
              <roleAktif.icon size={29} />
            </div>

            <span className="eyebrow">
              SIGN IN TO YOUR ACCOUNT
            </span>

            <h1>Selamat datang!</h1>

            <p>
              Masuk sebagai {roleAktif.title} untuk
              melanjutkan aktivitasmu.
            </p>

          </div>


          <form
            className="auth-form"
            onSubmit={prosesLogin}
          >

            <div className="form-field">

              <label>
                {role === "mahasiswa" ? "NIM" : "Username"}
              </label>

              <div className="input-wrapper">

                <UserRound size={18} />

                <input
                  name="identitas"
                  value={form.identitas}
                  onChange={ubahForm}
                  placeholder={
                    role === "mahasiswa"
                      ? "Masukkan NIM"
                      : "Masukkan username"
                  }
                  autoComplete="username"
                  required
                />

              </div>

            </div>


            <div className="form-field">

              <label>Password</label>

              <div className="input-wrapper">

                <LockKeyhole size={18} />

                <input
                  name="password"
                  type={
                    tampilkanPassword
                      ? "text"
                      : "password"
                  }
                  value={form.password}
                  onChange={ubahForm}
                  placeholder="Masukkan password"
                  autoComplete="current-password"
                  required
                />

                <button
                  type="button"
                  className="password-toggle"
                  onClick={() =>
                    setTampilkanPassword(
                      !tampilkanPassword
                    )
                  }
                >
                  {tampilkanPassword ? (
                    <EyeOff size={18} />
                  ) : (
                    <Eye size={18} />
                  )}
                </button>

              </div>

            </div>


            {pesan && (
              <div className={`message-box ${jenisPesan}`}>

                {jenisPesan === "success" ? (
                  <CheckCircle2 size={18} />
                ) : (
                  <AlertCircle size={18} />
                )}

                <span>{pesan}</span>

              </div>
            )}


            <button
              className="primary-button full-button"
              type="submit"
              disabled={loading}
            >
              {loading ? "Memproses..." : "Masuk"}

              {!loading && <ArrowRight size={18} />}

            </button>


            <p className="form-bottom">
              Login sebagai {roleAktif.title}
            </p>

          </form>

        </section>
      )}


      {/* =====================================
          REGISTRASI MAHASISWA
      ===================================== */}

      {halaman === "register" && (
        <section className="auth-layout">

          <div className="auth-heading">

            <button
              className="back-button"
              onClick={() => setHalaman("role")}
            >
              <ArrowLeft size={19} />
            </button>

            <div className="small-brand">
              <Monitor size={21} />
              <span>LabAssess</span>
            </div>

            <span className="eyebrow">
              STUDENT REGISTRATION
            </span>

            <h1>Buat akunmu.</h1>

            <p>
              Lengkapi data diri untuk mendaftar sebagai
              mahasiswa LabAssess.
            </p>

          </div>


          <form
            className="auth-form"
            onSubmit={prosesRegistrasi}
          >

            <div className="form-field">

              <label>Nama lengkap</label>

              <input
                className="simple-input"
                name="nama_lengkap"
                value={registrasi.nama_lengkap}
                onChange={ubahRegistrasi}
                placeholder="Masukkan nama lengkap"
                required
              />

            </div>


            <div className="form-field">

              <label>NIM</label>

              <input
                className="simple-input"
                name="nim"
                value={registrasi.nim}
                onChange={ubahRegistrasi}
                placeholder="Masukkan NIM"
                required
              />

            </div>


            <div className="form-field">

              <label>Program studi</label>

              <select
                className="simple-input"
                name="program_studi_id"
                value={registrasi.program_studi_id}
                onChange={ubahRegistrasi}
                required
              >

                {PROGRAM_STUDI.map((program) => (
                  <option
                    key={program.id}
                    value={program.id}
                  >
                    {program.nama}
                  </option>
                ))}

              </select>

            </div>


            <div className="form-field">

              <label>Password</label>

              <input
                className="simple-input"
                type="password"
                name="password"
                value={registrasi.password}
                onChange={ubahRegistrasi}
                placeholder="Minimal 8 karakter"
                minLength={8}
                required
              />

            </div>


            <div className="form-field">

              <label>Konfirmasi password</label>

              <input
                className="simple-input"
                type="password"
                name="konfirmasi_password"
                value={registrasi.konfirmasi_password}
                onChange={ubahRegistrasi}
                placeholder="Ulangi password"
                minLength={8}
                required
              />

            </div>


            {pesan && (
              <div className={`message-box ${jenisPesan}`}>
                <AlertCircle size={18} />
                <span>{pesan}</span>
              </div>
            )}


            <button
              className="primary-button full-button"
              type="submit"
              disabled={loading}
            >
              {loading ? "Memproses..." : "Daftar"}

              {!loading && <ArrowRight size={18} />}

            </button>

          </form>

        </section>
      )}


      {/* =====================================
          GANTI PASSWORD
      ===================================== */}

      {halaman === "ganti-password" && (
        <section className="auth-layout">

          <div className="auth-heading">

            <div className="small-brand">
              <Monitor size={21} />
              <span>LabAssess</span>
            </div>

            <div className="role-icon large-role-icon">
              <KeyRound size={29} />
            </div>

            <span className="eyebrow">
              ACCOUNT SECURITY
            </span>

            <h1>Amankan akunmu.</h1>

            <p>
              Kamu sedang menggunakan password sementara.
              Buat password baru untuk melanjutkan ke
              dashboard.
            </p>

          </div>


          <form
            className="auth-form"
            onSubmit={prosesGantiPassword}
          >

            <div className="security-notice">
              <LockKeyhole size={20} />

              <span>
                Password sementara hanya dapat digunakan
                untuk proses penggantian password.
              </span>
            </div>


            <div className="form-field">

              <label>Password baru</label>

              <input
                className="simple-input"
                type="password"
                value={passwordBaru}
                onChange={(event) =>
                  setPasswordBaru(event.target.value)
                }
                placeholder="Minimal 8 karakter"
                minLength={8}
                autoComplete="new-password"
                required
              />

            </div>


            <div className="form-field">

              <label>Konfirmasi password baru</label>

              <input
                className="simple-input"
                type="password"
                value={konfirmasiPassword}
                onChange={(event) =>
                  setKonfirmasiPassword(event.target.value)
                }
                placeholder="Ulangi password baru"
                minLength={8}
                autoComplete="new-password"
                required
              />

            </div>


            {pesan && (
              <div className={`message-box ${jenisPesan}`}>
                <AlertCircle size={18} />
                <span>{pesan}</span>
              </div>
            )}


            <button
              className="primary-button full-button"
              type="submit"
              disabled={loading}
            >
              {loading
                ? "Menyimpan..."
                : "Simpan Password Baru"}

              {!loading && <ArrowRight size={18} />}

            </button>


            <p className="form-bottom">
              Perubahan password wajib dilakukan sebelum
              mengakses dashboard.
            </p>

          </form>

        </section>
      )}

    </main>
  );
}


export default App;
